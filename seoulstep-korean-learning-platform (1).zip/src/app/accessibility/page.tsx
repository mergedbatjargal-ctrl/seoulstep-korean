import type { Metadata } from "next";
import Link from "next/link";
import { LegalPage } from "@/components/legal/LegalPage";

export const metadata: Metadata = {
  title: "Accessibility statement",
  description: "How SeoulStep aims to be accessible, known limitations, and how to request help.",
  alternates: { canonical: "/accessibility" },
};

export default function AccessibilityPage() {
  return (
    <LegalPage title="Accessibility statement" updated="2026">
      <p>SeoulStep aims to meet the WCAG 2.2 AA guidelines. We design mobile-first and test with keyboards and screen readers as part of development.</p>

      <h2>What we do</h2>
      <ul>
        <li>Semantic HTML, a skip link, labelled form fields and landmark regions.</li>
        <li>Visible focus indicators and full keyboard navigation for menus, lessons and quizzes.</li>
        <li>Text contrast designed for at least 4.5:1 for body text.</li>
        <li>Animations respect the “reduce motion” system setting. Scroll reveals show content immediately.</li>
        <li>Touch targets sized for phones (at least 44 px).</li>
        <li>Alt text for meaningful images, and decorative graphics hidden from assistive technology.</li>
        <li>Camera status is announced in text, not by colour alone.</li>
      </ul>

      <h2>Known limitations</h2>
      <ul>
        <li>Some Korean pronunciation audio depends on your device’s text-to-speech voices. If none is available, the written text still works.</li>
        <li>Flashcard and quiz content is currently available in English explanations only.</li>
      </ul>

      <h2>Feedback and help</h2>
      <p>If you can’t use part of this site, tell us and we’ll try to provide the information another way. Send feedback through the <Link href="/contact?plan=general">contact form</Link> and choose “Accessibility feedback”. We aim to reply within five business days.</p>

      <h2>Last review</h2>
      <p>This statement was prepared for the current release. Re-check before each major launch, because automated tests catch only part of accessibility problems.</p>
    </LegalPage>
  );
}
