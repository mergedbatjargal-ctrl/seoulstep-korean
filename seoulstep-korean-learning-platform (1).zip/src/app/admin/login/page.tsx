import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { adminConfigured, getAdminSession } from "@/lib/auth";
import { AdminLoginForm } from "@/components/admin/AdminLoginForm";

export const metadata: Metadata = {
  title: "Admin sign-in",
  robots: { index: false, follow: false, nocache: true },
};
export const dynamic = "force-dynamic";

export default async function AdminLoginPage() {
  if (await getAdminSession()) redirect("/admin");
  const configured = adminConfigured();

  return (
    <main id="main" className="grid min-h-dvh place-items-center bg-ink px-5 py-16 text-white">
      <div aria-hidden="true" className="pointer-events-none fixed inset-0 grid-bg opacity-20" />
      <div className="relative w-full max-w-md">
        <p className="text-center text-xs font-semibold uppercase tracking-[0.25em] text-mint">Instructor console</p>
        <h1 className="mt-3 text-center text-3xl font-extrabold">Admin sign-in</h1>
        <p className="mt-3 text-center text-sm text-indigo-200">
          Restricted to authorized instructors. Requires your password and a 6-digit authenticator code.
        </p>

        <div className="glass-dark mt-8 rounded-3xl p-7">
          {configured ? (
            <AdminLoginForm />
          ) : (
            <p role="alert" className="rounded-2xl bg-amber-400/10 p-4 text-sm text-amber-100 ring-1 ring-amber-300/30">
              Admin sign-in is not configured for this deployment. The site owner must set the server environment variables described in the README (ADMIN_EMAIL, ADMIN_PASSWORD_HASH, ADMIN_TOTP_SECRET, SESSION_SECRET).
            </p>
          )}
        </div>
        <p className="mt-6 text-center text-xs text-indigo-300">Invitation links never grant admin access. This page is not linked from the public site.</p>
      </div>
    </main>
  );
}
