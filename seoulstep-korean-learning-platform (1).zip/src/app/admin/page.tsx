import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getAdminSession } from "@/lib/auth";
import { getClassroomSnapshot, getRecentAudit, listInvitations, writeAudit, DEMO_SESSION } from "@/lib/data";
import { InvitationManager } from "@/components/admin/InvitationManager";

export const metadata: Metadata = {
  title: "Instructor dashboard",
  robots: { index: false, follow: false, nocache: true, googleBot: { index: false, follow: false } },
};
export const dynamic = "force-dynamic";

const time = (d: Date | string | null) => (d ? new Date(d).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "—");

export default async function AdminPage() {
  const admin = await getAdminSession();
  if (!admin) redirect("/admin/login");

  const [learners, invitations, audit] = await Promise.all([getClassroomSnapshot(), listInvitations(), getRecentAudit(40)]);
  await writeAudit("admin_viewed_classroom", admin.sub, `session=${DEMO_SESSION} learners=${learners.length}`);

  const cameraOn = learners.filter((l) => l.cameraOn);
  const consented = learners.filter((l) => l.consentGiven).length;
  // No live relay is configured, so no learner video is ever shared with this dashboard.
  const sharedStreams: typeof cameraOn = [];

  return (
    <main id="main" className="min-h-dvh bg-[#0b1020] text-white">
      <header className="sticky top-0 z-30 border-b border-white/10 bg-[#0b1020]/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-5 py-4">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-mint">Private · Instructor console</p>
            <h1 className="text-xl font-bold">Classroom dashboard</h1>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <span className="hidden text-indigo-200 sm:inline">Signed in as {admin.sub}</span>
            <form action="/api/admin/logout" method="post">
              <button type="submit" className="rounded-xl px-4 py-2 font-semibold text-white ring-1 ring-white/20 hover:bg-white/10">Sign out</button>
            </form>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl space-y-8 px-5 py-8">
        <section aria-labelledby="kpi-title">
          <h2 id="kpi-title" className="sr-only">Summary</h2>
          <dl className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {[
              ["Active class", "Beginner Hangul (demo)"],
              ["Learners in last 30 min", String(learners.length)],
              ["Consent recorded", `${consented} of ${learners.length || 0}`],
              ["Cameras on now", String(cameraOn.length)],
            ].map(([k, v]) => (
              <div key={k} className="rounded-2xl bg-white/5 p-5 ring-1 ring-white/10">
                <dt className="text-xs text-indigo-300">{k}</dt>
                <dd className="mt-2 text-lg font-bold sm:text-2xl">{v}</dd>
              </div>
            ))}
          </dl>
        </section>

        <div className="grid gap-8 lg:grid-cols-[1.2fr_1fr]">
          <section aria-labelledby="attendance-title" className="rounded-3xl bg-white/5 p-6 ring-1 ring-white/10">
            <h2 id="attendance-title" className="text-lg font-semibold">Learner attendance</h2>
            <p className="mt-1 text-xs text-indigo-300">Anonymous IDs only. No names, no video, no recordings.</p>
            <div className="mt-4 overflow-x-auto">
              <table className="w-full min-w-[480px] text-left text-sm">
                <caption className="sr-only">Learners seen in the last 30 minutes</caption>
                <thead className="text-xs uppercase tracking-wider text-indigo-300">
                  <tr>
                    <th scope="col" className="py-2 pr-3">Learner</th>
                    <th scope="col" className="py-2 pr-3">Joined</th>
                    <th scope="col" className="py-2 pr-3">Last seen</th>
                    <th scope="col" className="py-2 pr-3">Camera consent</th>
                    <th scope="col" className="py-2">Camera</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/10">
                  {learners.length === 0 && (
                    <tr><td colSpan={5} className="py-6 text-center text-indigo-300">No learners in the last 30 minutes.</td></tr>
                  )}
                  {learners.map((l) => (
                    <tr key={l.learnerId}>
                      <td className="py-3 pr-3 font-mono text-xs">{l.learnerId}</td>
                      <td className="py-3 pr-3">{time(l.joinedAt)}</td>
                      <td className="py-3 pr-3">{time(l.lastSeen)}</td>
                      <td className="py-3 pr-3">{l.consentGiven ? <span className="text-emerald-300">Given</span> : <span className="text-indigo-300">Not given</span>}</td>
                      <td className="py-3">
                        {l.cameraOn ? <span className="rounded-full bg-rose-500/20 px-2 py-0.5 text-xs font-semibold text-rose-200">On</span> : <span className="text-indigo-300">Off</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section aria-labelledby="streams-title" className="rounded-3xl bg-white/5 p-6 ring-1 ring-white/10">
            <h2 id="streams-title" className="text-lg font-semibold">Shared video streams</h2>
            <p className="mt-1 text-xs text-indigo-300">Only learners who joined and turned on their camera appear here.</p>
            {sharedStreams.length === 0 ? (
              <div className="mt-4 rounded-2xl border border-dashed border-white/20 p-8 text-center">
                <p className="font-semibold">No video is being shared</p>
                <p className="mt-2 text-sm text-indigo-200">
                  Live video relay (SFU) is not configured for this deployment. When it is, learners who enable their camera will appear here, and nobody else will see their video.
                </p>
                <p className="mt-3 text-xs text-indigo-300">Camera-on learners right now: {cameraOn.length}</p>
              </div>
            ) : (
              <div className="mt-4 grid grid-cols-2 gap-3" />
            )}
          </section>
        </div>

        <section aria-labelledby="invites-title" className="rounded-3xl bg-white/5 p-6 ring-1 ring-white/10">
          <h2 id="invites-title" className="text-lg font-semibold">Lesson invitations</h2>
          <p className="mt-1 text-xs text-indigo-300">Learner-only links. Expiring and revocable.</p>
          <div className="mt-5">
            <InvitationManager
              initial={invitations.map((i) => ({
                id: i.id,
                label: i.label,
                createdAt: i.createdAt.toISOString(),
                expiresAt: i.expiresAt.toISOString(),
                revokedAt: i.revokedAt ? i.revokedAt.toISOString() : null,
                useCount: i.useCount,
                lastUsedAt: i.lastUsedAt ? i.lastUsedAt.toISOString() : null,
              }))}
            />
          </div>
        </section>

        <section aria-labelledby="audit-title" className="rounded-3xl bg-white/5 p-6 ring-1 ring-white/10">
          <h2 id="audit-title" className="text-lg font-semibold">Audit log</h2>
          <p className="mt-1 text-xs text-indigo-300">Admin sign-ins, invitation changes and classroom access. Most recent first.</p>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[560px] text-left text-sm">
              <caption className="sr-only">Audit events</caption>
              <thead className="text-xs uppercase tracking-wider text-indigo-300">
                <tr>
                  <th scope="col" className="py-2 pr-3">When</th>
                  <th scope="col" className="py-2 pr-3">Event</th>
                  <th scope="col" className="py-2 pr-3">Actor</th>
                  <th scope="col" className="py-2">Detail</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {audit.length === 0 && <tr><td colSpan={4} className="py-6 text-center text-indigo-300">No events yet.</td></tr>}
                {audit.map((a) => (
                  <tr key={a.id}>
                    <td className="py-2.5 pr-3 whitespace-nowrap text-indigo-200">{new Date(a.createdAt).toLocaleString()}</td>
                    <td className="py-2.5 pr-3 font-mono text-xs">{a.event}</td>
                    <td className="py-2.5 pr-3 text-indigo-200">{a.actor}</td>
                    <td className="py-2.5 text-indigo-200">{a.detail ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </main>
  );
}
