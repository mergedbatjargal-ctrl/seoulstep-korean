import { NextResponse } from "next/server";
import { getAdminSession } from "@/lib/auth";
import { createInvitation, listInvitations, revokeInvitation, writeAudit } from "@/lib/data";

export const dynamic = "force-dynamic";

const EXPIRY_OPTIONS = [1, 24, 24 * 7];

export async function GET() {
  const admin = await getAdminSession();
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const rows = await listInvitations();
  return NextResponse.json({
    invitations: rows.map((r) => ({
      id: r.id,
      label: r.label,
      createdAt: r.createdAt,
      expiresAt: r.expiresAt,
      revokedAt: r.revokedAt,
      useCount: r.useCount,
      lastUsedAt: r.lastUsedAt,
    })),
  });
}

/** Creates a LEARNER-only invitation link. Admin rights are never granted by invitations. */
export async function POST(req: Request) {
  const admin = await getAdminSession();
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  let body: { label?: unknown; hours?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const label = typeof body.label === "string" ? body.label.trim() : "";
  const hours = typeof body.hours === "number" && EXPIRY_OPTIONS.includes(body.hours) ? body.hours : 24;

  const created = await createInvitation(label, hours, admin.sub);
  await writeAudit("invitation_created", admin.sub, `id=${created.id} expires=${created.expiresAt.toISOString()} role=learner`);
  const origin = new URL(req.url).origin;
  return NextResponse.json({
    id: created.id,
    expiresAt: created.expiresAt,
    url: `${origin}/join/${created.token}`,
  });
}

export async function DELETE(req: Request) {
  const admin = await getAdminSession();
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!Number.isInteger(id) || id <= 0) return NextResponse.json({ error: "Invalid id." }, { status: 400 });
  const row = await revokeInvitation(id);
  if (!row) return NextResponse.json({ error: "Not found or already revoked." }, { status: 404 });
  await writeAudit("invitation_revoked", admin.sub, `id=${id}`);
  return NextResponse.json({ ok: true });
}
