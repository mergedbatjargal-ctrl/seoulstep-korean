import { NextResponse } from "next/server";
import {
  ADMIN_COOKIE,
  ADMIN_TTL_SEC,
  adminConfigured,
  clearRateLimit,
  cookieOptions,
  emailMatches,
  rateLimit,
  signToken,
  verifyPasswordHash,
  verifyTotp,
} from "@/lib/auth";
import { writeAudit } from "@/lib/data";

export const dynamic = "force-dynamic";

function clientKey(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || req.headers.get("x-real-ip") || "unknown";
  return `admin-login:${ip}`;
}

export async function POST(req: Request) {
  if (!adminConfigured()) {
    return NextResponse.json({ error: "Admin sign-in is not available." }, { status: 503 });
  }
  const key = clientKey(req);
  if (!rateLimit(key)) {
    return NextResponse.json({ error: "Too many attempts. Please wait 15 minutes and try again." }, { status: 429 });
  }

  let body: { email?: unknown; password?: unknown; code?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const email = typeof body.email === "string" ? body.email.slice(0, 200) : "";
  const password = typeof body.password === "string" ? body.password.slice(0, 500) : "";
  const code = typeof body.code === "string" ? body.code.replace(/\s/g, "") : "";

  // Check every factor, but return one generic message so the form reveals nothing.
  const emailOk = emailMatches(email);
  const passOk = verifyPasswordHash(password, process.env.ADMIN_PASSWORD_HASH);
  const totpOk = verifyTotp(process.env.ADMIN_TOTP_SECRET, code);

  if (!(emailOk && passOk && totpOk)) {
    await writeAudit("admin_sign_in_failed", "unknown", `factor check failed`);
    return NextResponse.json({ error: "Sign-in failed. Check your email, password and code." }, { status: 401 });
  }

  clearRateLimit(key);
  const token = signToken({ sub: process.env.ADMIN_EMAIL, typ: "admin", mfa: true, exp: Math.floor(Date.now() / 1000) + ADMIN_TTL_SEC });
  if (!token) return NextResponse.json({ error: "Admin sign-in is not available." }, { status: 503 });

  await writeAudit("admin_sign_in", process.env.ADMIN_EMAIL ?? "admin", "password + TOTP verified");
  const res = NextResponse.json({ ok: true });
  res.cookies.set(ADMIN_COOKIE, token, cookieOptions(ADMIN_TTL_SEC));
  return res;
}
