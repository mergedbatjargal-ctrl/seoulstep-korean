import { NextResponse } from "next/server";
import { ADMIN_COOKIE, cookieOptions, getAdminSession } from "@/lib/auth";
import { writeAudit } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const admin = await getAdminSession();
  if (admin) await writeAudit("admin_sign_out", admin.sub);
  const res = NextResponse.redirect(new URL("/admin/login", req.url), { status: 303 });
  res.cookies.set(ADMIN_COOKIE, "", { ...cookieOptions(0), maxAge: 0 });
  return res;
}
