import { NextResponse } from "next/server";
import { CLASSROOM_EVENTS, type ClassroomEvent, getActiveLearner, logClassroomEvent } from "@/lib/data";

export const dynamic = "force-dynamic";

/**
 * Records a learner's consent/camera state change for the instructor's attendance view.
 * Only allowlisted events are accepted. No video or media ever reaches this endpoint.
 * Anonymous visitors (no valid invitation session) are not logged.
 */
export async function POST(req: Request) {
  let body: { event?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const event = body.event;
  if (typeof event !== "string" || !(CLASSROOM_EVENTS as readonly string[]).includes(event)) {
    return NextResponse.json({ error: "Unsupported event." }, { status: 400 });
  }
  const learner = await getActiveLearner();
  if (!learner) return NextResponse.json({ logged: false }, { status: 200 });
  await logClassroomEvent(learner.learnerId, learner.invitationId, event as ClassroomEvent);
  return NextResponse.json({ logged: true });
}
