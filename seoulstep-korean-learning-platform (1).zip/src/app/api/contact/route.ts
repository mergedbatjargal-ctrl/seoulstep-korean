import { NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { rateLimit } from "@/lib/auth";

export const dynamic = "force-dynamic";

const TOPICS = ["general", "plus", "live", "privacy", "accessibility", "legal", "bug"];
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  if (!rateLimit(`contact:${ip}`, 5, 60 * 60_000)) {
    return NextResponse.json({ error: "You’ve sent several messages recently. Please try again later." }, { status: 429 });
  }
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const name = String(body.name ?? "").trim().slice(0, 120);
  const email = String(body.email ?? "").trim().slice(0, 200);
  const message = String(body.message ?? "").trim().slice(0, 4000);
  const topic = TOPICS.includes(String(body.topic)) ? String(body.topic) : "general";
  // Honeypot field: bots fill it, people don't.
  if (body.website) return NextResponse.json({ ok: true });

  if (!name || !EMAIL.test(email) || message.length < 10) {
    return NextResponse.json({ error: "Please add your name, a valid email, and a message of at least 10 characters." }, { status: 400 });
  }
  await db.insert(contactMessages).values({ name, email, topic, message });
  return NextResponse.json({ ok: true });
}
