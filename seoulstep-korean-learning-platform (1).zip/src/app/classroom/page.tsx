import type { Metadata } from "next";
import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Classroom } from "@/components/classroom/Classroom";
import { getActiveLearner } from "@/lib/data";

export const metadata: Metadata = {
  title: "Join a lesson",
  description: "Join a SeoulStep lesson with an invitation link. Your camera stays off unless you choose to turn it on.",
  robots: { index: false, follow: true },
};
export const dynamic = "force-dynamic";

export default async function ClassroomPage({ searchParams }: { searchParams: Promise<{ invite?: string; welcome?: string }> }) {
  const sp = await searchParams;
  const learner = await getActiveLearner();
  const inviteStatus = sp.invite === "invalid" ? "invalid" : sp.invite === "unavailable" ? "unavailable" : null;

  return (
    <>
      <SiteHeader />
      <main id="main" className="mx-auto max-w-6xl px-5 pb-24 pt-8 sm:pt-12">
        <header data-reveal className="max-w-3xl">
          <p className="text-sm font-semibold uppercase tracking-widest text-brand">Live classroom</p>
          <h1 className="mt-3 text-balance text-4xl font-extrabold tracking-tight text-ink sm:text-5xl">Join a lesson</h1>
          <p className="mt-4 text-lg text-slate-600">
            Lessons are shared with an invitation link from your instructor. Your camera and microphone stay off until you decide otherwise.
          </p>
        </header>

        {inviteStatus && (
          <div role="alert" className="mt-8 rounded-2xl bg-amber-50 p-5 text-amber-900 ring-1 ring-amber-200">
            <p className="font-semibold">
              {inviteStatus === "invalid" ? "This invitation link isn’t active." : "We couldn’t open the lesson right now."}
            </p>
            <p className="mt-1 text-sm">
              {inviteStatus === "invalid"
                ? "It may have expired or been revoked. Ask your instructor for a new link. You can still study on your own below."
                : "Please try the link again in a moment."}
            </p>
          </div>
        )}
        {sp.welcome === "1" && learner && (
          <div role="status" className="mt-8 rounded-2xl bg-emerald-50 p-5 text-emerald-900 ring-1 ring-emerald-200">
            <p className="font-semibold">You’re in. Welcome to the lesson.</p>
            <p className="mt-1 text-sm">This invitation gives learner access only. Your camera is off.</p>
          </div>
        )}

        <div className="mt-10">
          <Classroom hasInvite={Boolean(learner)} />
        </div>

        <p className="mt-10 text-sm text-slate-600">
          No invitation yet? <Link href="/learn" className="font-semibold text-brand underline-offset-4 hover:underline">Start learning on your own</Link>. Read our{" "}
          <Link href="/privacy" className="font-semibold text-brand underline-offset-4 hover:underline">privacy policy</Link>.
        </p>
      </main>
      <SiteFooter />
    </>
  );
}
