import type { Metadata } from "next";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { ContactForm } from "@/components/ContactForm";

export const metadata: Metadata = {
  title: "Contact the site owner",
  description: "Send a question, privacy request, accessibility feedback or plan inquiry to the SeoulStep site owner.",
  alternates: { canonical: "/contact" },
};

export default async function ContactPage({ searchParams }: { searchParams: Promise<{ plan?: string }> }) {
  const sp = await searchParams;
  const topic = sp.plan === "live" ? "live" : sp.plan === "plus" ? "plus" : "general";
  return (
    <>
      <SiteHeader />
      <main id="main" className="mx-auto grid max-w-6xl gap-12 px-5 pb-24 pt-10 sm:pt-14 lg:grid-cols-[0.9fr_1.1fr]">
        <section>
          <p className="text-sm font-semibold uppercase tracking-widest text-brand">Contact</p>
          <h1 className="mt-3 text-4xl font-extrabold tracking-tight text-ink">Talk to the SeoulStep team</h1>
          <p className="mt-4 leading-relaxed text-slate-700">
            Questions about lessons, plans, privacy requests (access, correction or deletion of your data), or accessibility barriers are all welcome. We reply within a few business days.
          </p>
          <ul className="mt-6 space-y-3 text-sm text-slate-700">
            <li><strong className="text-ink">Privacy requests:</strong> choose “Privacy” in the form.</li>
            <li><strong className="text-ink">Accessibility feedback:</strong> choose “Accessibility”.</li>
            <li><strong className="text-ink">Instructors:</strong> lesson invitations are issued from the private instructor console only.</li>
          </ul>
        </section>
        <ContactForm defaultTopic={topic} />
      </main>
      <SiteFooter />
    </>
  );
}
