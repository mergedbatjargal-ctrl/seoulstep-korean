import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { LEARNER_COOKIE, LEARNER_TTL_SEC, cookieOptions, signToken } from "@/lib/auth";
import { findActiveInvitation, logClassroomEvent, markInvitationUsed } from "@/lib/data";

export const dynamic = "force-dynamic";

/**
 * Opens a learner invitation. Grants a LEARNER session only (typ=learner).
 * Expired, revoked or unknown links redirect to a neutral message.
 * Opening a link never touches the camera or microphone.
 */
export async function GET(req: Request, ctx: { params: Promise<{ token: string }> }) {
  const { token } = await ctx.params;
  const url = new URL(req.url);
  const invitation = await findActiveInvitation(token);

  if (!invitation) {
    return NextResponse.redirect(new URL("/classroom?invite=invalid", url.origin), { status: 303 });
  }

  const learnerId = randomUUID();
  const exp = Math.min(Math.floor(invitation.expiresAt.getTime() / 1000), Math.floor(Date.now() / 1000) + LEARNER_TTL_SEC);
  const cookieValue = signToken({ lid: learnerId, inv: invitation.id, typ: "learner", exp });
  if (!cookieValue) {
    return NextResponse.redirect(new URL("/classroom?invite=unavailable", url.origin), { status: 303 });
  }

  await markInvitationUsed(invitation.id);
  await logClassroomEvent(learnerId, invitation.id, "joined");

  const res = NextResponse.redirect(new URL("/classroom?welcome=1", url.origin), { status: 303 });
  res.cookies.set(LEARNER_COOKIE, cookieValue, cookieOptions(Math.max(0, exp - Math.floor(Date.now() / 1000))));
  res.headers.set("Referrer-Policy", "no-referrer");
  res.headers.set("Cache-Control", "no-store");
  return res;
}
