import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Inter } from "next/font/google";
import "./globals.css";
import { RevealProvider } from "@/components/RevealProvider";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "SeoulStep — Learn Korean one clear step at a time",
    template: "%s · SeoulStep",
  },
  description:
    "Learn Hangul, pronunciation, vocabulary, grammar, listening, and real conversation with structured Korean lessons that adapt to your pace. Start free.",
  keywords: ["learn Korean", "Hangul", "Korean pronunciation", "Korean grammar", "spaced repetition", "Korean for beginners", "TOPIK"],
  applicationName: "SeoulStep",
  authors: [{ name: "SeoulStep" }],
  alternates: { canonical: "/" },
  icons: {
    icon: [{ url: "/icon.svg", type: "image/svg+xml" }],
    apple: [{ url: "/icon.svg" }],
  },
  openGraph: {
    type: "website",
    siteName: "SeoulStep",
    title: "SeoulStep — Speak Korean with confidence, one clear step at a time",
    description:
      "Structured Korean lessons for Hangul, pronunciation, vocabulary, grammar, listening and conversation. Start learning free.",
    url: "/",
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: "SeoulStep — Learn Korean one clear step at a time",
    description: "Structured Korean lessons with spaced-repetition flashcards and consent-first live classes.",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#3b5bff",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="min-h-dvh antialiased">
        <a href="#main" className="skip-link">
          Skip to content
        </a>
        <RevealProvider />
        {children}
      </body>
    </html>
  );
}
