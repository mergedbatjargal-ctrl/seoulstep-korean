import type { Metadata } from "next";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { LearnHub } from "@/components/learn/LearnHub";

export const metadata: Metadata = {
  title: "Start learning",
  description: "Free Korean lessons: Hangul, pronunciation, vocabulary, grammar, listening and conversation, with flashcards and quizzes.",
  alternates: { canonical: "/learn" },
};

export default function LearnPage() {
  return (
    <>
      <SiteHeader />
      <main id="main">
        <header className="mx-auto max-w-6xl px-5 pt-10 sm:pt-14">
          <p className="text-sm font-semibold uppercase tracking-widest text-brand">Start learning · free</p>
          <h1 className="mt-3 max-w-3xl text-balance text-4xl font-extrabold tracking-tight text-ink sm:text-5xl">
            Pick a path. Take one small step today.
          </h1>
          <p className="mt-4 max-w-2xl text-lg text-slate-600">
            No account needed. Your progress, badges and review schedule are saved in this browser.
          </p>
        </header>
        <LearnHub />
      </main>
      <SiteFooter />
    </>
  );
}
