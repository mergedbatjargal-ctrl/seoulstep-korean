import type { Metadata } from "next";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Hero } from "@/components/landing/Hero";
import {
  AudienceStrip,
  Benefits,
  FAQ,
  Features,
  FinalCTA,
  Pricing,
  Showcase,
  Stats,
  Testimonials,
} from "@/components/landing/Sections";

export const metadata: Metadata = {
  title: "Learn Korean one clear step at a time",
  description:
    "Structured Korean lessons for Hangul, pronunciation, vocabulary, grammar, listening and conversation, with spaced-repetition flashcards and consent-first live classes.",
  alternates: { canonical: "/" },
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Course",
  name: "SeoulStep Korean for Beginners",
  description: "Structured Korean lessons: Hangul, pronunciation, vocabulary, grammar, listening and conversation.",
  provider: { "@type": "Organization", name: "SeoulStep" },
  inLanguage: "en",
  isAccessibleForFree: true,
  offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
};

export default function HomePage() {
  return (
    <>
      <a id="top" className="sr-only" href="#top">Top of page</a>
      <SiteHeader />
      <main id="main">
        <Hero />
        <AudienceStrip />
        <Stats />
        <Features />
        <Showcase />
        <Benefits />
        <Testimonials />
        <Pricing />
        <FAQ />
        <FinalCTA />
      </main>
      <SiteFooter />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </>
  );
}
