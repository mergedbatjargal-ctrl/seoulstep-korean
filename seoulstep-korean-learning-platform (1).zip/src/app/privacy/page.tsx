import type { Metadata } from "next";
import Link from "next/link";
import { LegalPage } from "@/components/legal/LegalPage";

export const metadata: Metadata = {
  title: "Privacy policy",
  description: "How SeoulStep collects, uses and protects your data, including live classroom camera consent.",
  alternates: { canonical: "/privacy" },
};

export default function PrivacyPage() {
  return (
    <LegalPage title="Privacy policy" updated="2026">
      <p>SeoulStep is a Korean-learning website. This policy explains what we collect, why, and the choices you have. We collect the minimum needed to run lessons.</p>

      <h2>What we collect</h2>
      <ul>
        <li><strong>Learning progress on your device:</strong> completed lessons, flashcard review schedule and your last lesson are stored in your browser’s local storage. We do not upload them.</li>
        <li><strong>Lesson invitations:</strong> when you open an invitation link, we create a random anonymous learner ID stored in an httpOnly cookie, plus event records such as “joined”, “camera on” and “left”. We do not store your name for invitations.</li>
        <li><strong>Contact messages:</strong> the name, email address, topic and message you send us, used only to reply.</li>
        <li><strong>Security logs:</strong> admin sign-in attempts and admin actions, kept in an audit log, plus a temporary rate-limit counter by IP address.</li>
      </ul>

      <h2>Camera and microphone</h2>
      <p>
        Camera and microphone are <strong>off by default</strong>. We never request them when you open the site or an invitation link. The browser asks for camera permission only after you tick the consent box and press “Enable camera”. We do not request your microphone on the classroom screen.
      </p>
      <ul>
        <li><strong>Who can see your live video:</strong> only your instructor or an authorized administrator for that session.</li>
        <li><strong>Other learners:</strong> cannot see your video.</li>
        <li><strong>Recording and storage:</strong> video is not recorded or stored by default. If we ever add recording, it will require separate, explicit consent and show a clear recording indicator.</li>
        <li><strong>Your control:</strong> turning the camera off or leaving the session immediately stops all camera and microphone tracks.</li>
        <li><strong>Current status:</strong> the live video relay is not configured in this deployment. Camera previews stay on your device and are not transmitted.</li>
      </ul>

      <h2>How we use data</h2>
      <p>To deliver lessons, show instructors who joined and consented, keep the site secure, and answer your messages. We do not sell personal data or use it for advertising.</p>

      <h2>Retention</h2>
      <p>Invitation learner sessions end when the invitation expires or is revoked, or after 12 hours. Presence events are kept for operational review and are removed on request. Contact messages are kept until your request is resolved.</p>

      <h2>Your rights</h2>
      <p>You can ask us to access, correct or delete your data, and you can clear your local progress at any time from your browser’s site data settings. To make a request, use the <Link href="/contact?plan=general">contact form</Link> and choose “Privacy request”.</p>

      <h2>Security</h2>
      <p>All traffic is served over HTTPS. Sessions use signed, httpOnly, same-site cookies. Admin access requires a password and a time-based one-time code (MFA). Invitation links are stored only as hashes, so the database cannot reveal a working link.</p>

      <h2>Children</h2>
      <p>SeoulStep is not directed at children under 13. If you believe a child has sent us personal data, contact us and we will delete it.</p>

      <h2>Changes</h2>
      <p>We will update this page when our practices change and show the new date at the top.</p>
    </LegalPage>
  );
}
