import type { Metadata } from "next";
import Link from "next/link";
import { LegalPage } from "@/components/legal/LegalPage";

export const metadata: Metadata = {
  title: "Terms of use",
  description: "The rules for using the SeoulStep website, lessons and live classroom.",
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <LegalPage title="Terms of use" updated="2026">
      <p>By using SeoulStep you agree to these terms. If you don’t agree, please don’t use the site.</p>

      <h2>Educational service</h2>
      <p>SeoulStep provides Korean-language lessons for personal learning. It is not an official TOPIK or government certification, and it doesn’t guarantee specific results.</p>

      <h2>Free access and plans</h2>
      <p>The marketing site, Hangul lessons and demo content are free and available without an account. Paid plans are shown for information. Billing is not active in this preview, and any future charges will be shown clearly before you pay.</p>

      <h2>Lesson invitations</h2>
      <ul>
        <li>An invitation link is for the person it was issued to. Don’t share it publicly.</li>
        <li>Invitations give learner access only. They never give administrator access.</li>
        <li>Instructors may revoke an invitation at any time, and links expire automatically.</li>
      </ul>

      <h2>Live classroom conduct</h2>
      <p>Live sessions are for respectful learning. Don’t record others, share another learner’s content, or use a session for harassment. Your camera is always optional, and you may turn it off or leave at any time.</p>

      <h2>Acceptable use</h2>
      <p>Don’t attempt to access restricted areas, probe the service, scrape it at high volume, or interfere with other users. Accounts and protected areas are for authorized people only.</p>

      <h2>Content</h2>
      <p>Lesson content is owned by SeoulStep and may be used for personal learning only. Don’t copy or redistribute it without written permission.</p>

      <h2>Disclaimers and liability</h2>
      <p>The service is provided “as is”. To the fullest extent permitted by law, SeoulStep is not liable for indirect or consequential losses. Nothing in these terms limits rights that you cannot waive under applicable consumer law.</p>

      <h2>Changes and contact</h2>
      <p>We may update these terms. Continued use after an update means you accept the new terms. Questions? <Link href="/contact?plan=general">Contact the site owner</Link>.</p>
    </LegalPage>
  );
}
