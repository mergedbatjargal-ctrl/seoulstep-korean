"use client";

import { useState, type FormEvent } from "react";

const topics = [
  ["general", "General question"],
  ["plus", "Plus plan"],
  ["live", "Live Class plan"],
  ["privacy", "Privacy request"],
  ["accessibility", "Accessibility feedback"],
  ["legal", "Terms or legal"],
  ["bug", "Report a problem"],
];

export function ContactForm({ defaultTopic }: { defaultTopic: string }) {
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setStatus("sending");
    setError(null);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(Object.fromEntries(fd.entries())),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error ?? "Something went wrong.");
      setStatus("sent");
      e.currentTarget.reset();
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Something went wrong.");
    }
  };

  const input = "mt-2 w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-ink focus:border-brand focus:outline-none focus-visible:ring-2 focus-visible:ring-brand";

  if (status === "sent") {
    return (
      <div role="status" className="rounded-3xl bg-emerald-50 p-8 ring-1 ring-emerald-200">
        <p className="text-xl font-bold text-ink">Thanks, your message was received.</p>
        <p className="mt-2 text-slate-700">We’ll reply to the email address you gave.</p>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 sm:p-8" noValidate>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="c-name" className="text-sm font-semibold text-ink">Name</label>
          <input id="c-name" name="name" required maxLength={120} autoComplete="name" className={input} />
        </div>
        <div>
          <label htmlFor="c-email" className="text-sm font-semibold text-ink">Email</label>
          <input id="c-email" name="email" type="email" required maxLength={200} autoComplete="email" className={input} />
        </div>
      </div>
      <div className="mt-5">
        <label htmlFor="c-topic" className="text-sm font-semibold text-ink">Topic</label>
        <select id="c-topic" name="topic" defaultValue={defaultTopic} className={input}>
          {topics.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
      </div>
      <div className="mt-5">
        <label htmlFor="c-msg" className="text-sm font-semibold text-ink">Message</label>
        <textarea id="c-msg" name="message" required minLength={10} maxLength={4000} rows={6} className={input} aria-describedby="c-help" />
        <p id="c-help" className="mt-2 text-xs text-slate-500">Please don’t include passwords or sensitive health information.</p>
      </div>
      {/* Honeypot: hidden from people and assistive technology */}
      <div className="absolute -left-[9999px]" aria-hidden="true">
        <label htmlFor="c-web">Website</label>
        <input id="c-web" name="website" tabIndex={-1} autoComplete="off" />
      </div>
      {error && <p role="alert" className="mt-4 rounded-xl bg-rose-50 p-3 text-sm text-rose-800 ring-1 ring-rose-200">{error}</p>}
      <button type="submit" disabled={status === "sending"} className="btn-primary mt-6 w-full rounded-2xl px-6 py-3.5 font-semibold disabled:opacity-60 sm:w-auto">
        {status === "sending" ? "Sending…" : "Send message"}
      </button>
    </form>
  );
}
