import Link from "next/link";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link href="/" className={`group inline-flex items-center gap-2.5 rounded-xl ${className}`} aria-label="SeoulStep home">
      <span
        aria-hidden="true"
        className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-[#3b5bff] via-[#8b5cf6] to-[#14b8a6] shadow-lg shadow-indigo-500/30 transition-transform duration-500 group-hover:rotate-[-6deg] group-hover:scale-105"
      >
        <svg viewBox="0 0 64 64" className="h-6 w-6" fill="none">
          <path d="M14 46 L14 40 L32 40 L32 46 Z M32 40 L32 22 M18 30 L46 30" stroke="#fff" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
          <circle cx="48" cy="18" r="3.5" fill="#f5c542" />
        </svg>
      </span>
      <span className="text-lg font-bold tracking-tight text-ink">
        Seoul<span className="text-brand">Step</span>
      </span>
    </Link>
  );
}
