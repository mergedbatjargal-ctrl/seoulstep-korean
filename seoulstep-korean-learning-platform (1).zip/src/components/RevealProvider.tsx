"use client";

import { useEffect } from "react";

/**
 * Adds scroll-reveal behaviour to every [data-reveal] element.
 * Marks <html> with .js-reveal so content stays visible without JavaScript.
 * Respects prefers-reduced-motion by revealing everything immediately.
 */
export function RevealProvider() {
  useEffect(() => {
    const root = document.documentElement;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const els = Array.from(document.querySelectorAll<HTMLElement>("[data-reveal]"));

    if (reduce || !("IntersectionObserver" in window)) {
      els.forEach((el) => el.classList.add("is-visible"));
      return;
    }

    root.classList.add("js-reveal");
    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            io.unobserve(entry.target);
          }
        }
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.08 },
    );
    els.forEach((el) => io.observe(el));

    // Reveal anything already in view synchronously (avoids a flash on first paint).
    els.forEach((el) => {
      const r = el.getBoundingClientRect();
      if (r.top < window.innerHeight && r.bottom > 0) el.classList.add("is-visible");
    });

    return () => io.disconnect();
  }, []);

  return null;
}
