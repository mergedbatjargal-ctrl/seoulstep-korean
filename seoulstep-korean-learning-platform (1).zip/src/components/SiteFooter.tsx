import Link from "next/link";
import { Logo } from "@/components/Logo";

export function SiteFooter() {
  return (
    <footer className="border-t border-slate-200 bg-white">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Logo />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-slate-600">
            Structured Korean lessons for beginners, travelers, students and professionals. Learn at your own pace, one clear step at a time.
          </p>
        </div>

        <nav aria-label="Product">
          <h2 className="text-sm font-semibold text-ink">Product</h2>
          <ul className="mt-4 space-y-2.5 text-sm text-slate-600">
            <li><a className="hover:text-brand" href="/#features">Features</a></li>
            <li><a className="hover:text-brand" href="/#pricing">Pricing</a></li>
            <li><Link className="hover:text-brand" href="/learn">Start learning</Link></li>
            <li><Link className="hover:text-brand" href="/classroom">Join a lesson</Link></li>
          </ul>
        </nav>

        <nav aria-label="Legal and support">
          <h2 className="text-sm font-semibold text-ink">Legal &amp; support</h2>
          <ul className="mt-4 space-y-2.5 text-sm text-slate-600">
            <li><Link className="hover:text-brand" href="/privacy">Privacy policy</Link></li>
            <li><Link className="hover:text-brand" href="/terms">Terms of use</Link></li>
            <li><Link className="hover:text-brand" href="/accessibility">Accessibility statement</Link></li>
            <li><Link className="hover:text-brand" href="/contact">Contact the site owner</Link></li>
          </ul>
        </nav>
      </div>
      <div className="border-t border-slate-100">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-6 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} SeoulStep. All rights reserved.</p>
          <p>Korean lessons are educational and not an official TOPIK or government certification.</p>
        </div>
      </div>
    </footer>
  );
}
