"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

export function AdminLoginForm() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, code }),
      });
      if (res.ok) {
        router.replace("/admin");
        router.refresh();
        return;
      }
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      setError(data.error ?? "Sign-in failed. Please try again.");
      setPassword("");
      setCode("");
    } catch {
      setError("Network problem. Check your connection and try again.");
    } finally {
      setLoading(false);
    }
  };

  const field = "mt-2 w-full rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-white placeholder:text-indigo-300/60 focus:border-mint focus:outline-none focus-visible:ring-2 focus-visible:ring-mint";

  return (
    <form onSubmit={submit} className="space-y-5" noValidate>
      <div>
        <label htmlFor="admin-email" className="text-sm font-semibold text-indigo-100">Work email</label>
        <input id="admin-email" name="email" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} className={field} />
      </div>
      <div>
        <label htmlFor="admin-password" className="text-sm font-semibold text-indigo-100">Password</label>
        <input id="admin-password" name="password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} className={field} />
      </div>
      <div>
        <label htmlFor="admin-code" className="text-sm font-semibold text-indigo-100">Authenticator code</label>
        <input
          id="admin-code"
          name="code"
          inputMode="numeric"
          pattern="[0-9]{6}"
          maxLength={6}
          autoComplete="one-time-code"
          required
          value={code}
          onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
          className={`${field} tracking-[0.4em]`}
          aria-describedby="code-help"
        />
        <p id="code-help" className="mt-2 text-xs text-indigo-300">Enter the 6-digit code from your authenticator app.</p>
      </div>

      {error && (
        <p role="alert" className="rounded-xl bg-rose-500/15 px-4 py-3 text-sm text-rose-100 ring-1 ring-rose-400/30">
          {error}
        </p>
      )}

      <button type="submit" disabled={loading} className="btn-primary w-full rounded-2xl px-5 py-3.5 font-semibold disabled:opacity-60">
        {loading ? "Verifying…" : "Sign in"}
      </button>
    </form>
  );
}
