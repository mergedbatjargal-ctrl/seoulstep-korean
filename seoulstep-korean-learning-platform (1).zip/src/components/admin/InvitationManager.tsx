"use client";

import { useState } from "react";

type Inv = {
  id: number;
  label: string;
  createdAt: string;
  expiresAt: string;
  revokedAt: string | null;
  useCount: number;
  lastUsedAt: string | null;
};

const fmt = (s: string | null) => (s ? new Date(s).toLocaleString() : "—");

export function InvitationManager({ initial }: { initial: Inv[] }) {
  const [items, setItems] = useState<Inv[]>(initial);
  const [label, setLabel] = useState("");
  const [hours, setHours] = useState(24);
  const [link, setLink] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const reload = async () => {
    const res = await fetch("/api/admin/invitations", { cache: "no-store" });
    if (res.ok) setItems(((await res.json()) as { invitations: Inv[] }).invitations);
  };

  const create = async () => {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/invitations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ label, hours }),
      });
      if (!res.ok) throw new Error("create failed");
      const data = (await res.json()) as { url: string };
      setLink(data.url);
      setCopied(false);
      setLabel("");
      await reload();
    } catch {
      setError("Couldn’t create the invitation. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  const revoke = async (id: number) => {
    if (!window.confirm("Revoke this invitation? Learners using it will lose access immediately.")) return;
    const res = await fetch(`/api/admin/invitations?id=${id}`, { method: "DELETE" });
    if (!res.ok) setError("Couldn’t revoke that invitation.");
    await reload();
  };

  const copy = async () => {
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
    } catch {
      setError("Copy failed. Select the link and copy it manually.");
    }
  };

  const now = Date.now();

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-white/5 p-5 ring-1 ring-white/10">
        <h3 className="font-semibold text-white">Create a learner invitation</h3>
        <p className="mt-1 text-xs text-indigo-200">Invitation links grant learner access only and never admin access. The link is shown once.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_auto_auto]">
          <div>
            <label htmlFor="inv-label" className="sr-only">Label</label>
            <input id="inv-label" value={label} onChange={(e) => setLabel(e.target.value)} maxLength={120} placeholder="e.g. Tuesday Hangul group" className="w-full rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-indigo-300/60 focus-visible:ring-2 focus-visible:ring-mint" />
          </div>
          <div>
            <label htmlFor="inv-hours" className="sr-only">Expires after</label>
            <select id="inv-hours" value={hours} onChange={(e) => setHours(Number(e.target.value))} className="w-full rounded-xl border border-white/15 bg-ink px-3 py-2.5 text-sm text-white focus-visible:ring-2 focus-visible:ring-mint">
              <option value={1}>Expires in 1 hour</option>
              <option value={24}>Expires in 24 hours</option>
              <option value={168}>Expires in 7 days</option>
            </select>
          </div>
          <button type="button" onClick={create} disabled={busy} className="btn-primary rounded-xl px-5 py-2.5 text-sm font-semibold disabled:opacity-60">
            {busy ? "Creating…" : "Create link"}
          </button>
        </div>
        {link && (
          <div role="status" className="mt-4 rounded-xl bg-emerald-400/10 p-4 ring-1 ring-emerald-300/30">
            <p className="text-sm font-semibold text-emerald-100">Copy this link now. It won’t be shown again.</p>
            <div className="mt-2 flex flex-col gap-2 sm:flex-row">
              <input readOnly value={link} aria-label="New invitation link" className="min-w-0 flex-1 rounded-lg bg-black/30 px-3 py-2 font-mono text-xs text-white" onFocus={(e) => e.currentTarget.select()} />
              <button type="button" onClick={copy} className="rounded-lg bg-white px-4 py-2 text-sm font-semibold text-ink">{copied ? "Copied" : "Copy"}</button>
            </div>
          </div>
        )}
        {error && <p role="alert" className="mt-3 text-sm text-rose-200">{error}</p>}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-left text-sm">
          <caption className="sr-only">Learner invitations</caption>
          <thead className="text-xs uppercase tracking-wider text-indigo-300">
            <tr>
              <th scope="col" className="py-2 pr-3 font-semibold">Label</th>
              <th scope="col" className="py-2 pr-3 font-semibold">Status</th>
              <th scope="col" className="py-2 pr-3 font-semibold">Expires</th>
              <th scope="col" className="py-2 pr-3 font-semibold">Uses</th>
              <th scope="col" className="py-2 font-semibold"><span className="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10">
            {items.length === 0 && (
              <tr><td colSpan={5} className="py-6 text-center text-indigo-300">No invitations yet.</td></tr>
            )}
            {items.map((i) => {
              const expired = new Date(i.expiresAt).getTime() < now;
              const status = i.revokedAt ? "Revoked" : expired ? "Expired" : "Active";
              return (
                <tr key={i.id}>
                  <td className="py-3 pr-3 text-white">{i.label}</td>
                  <td className="py-3 pr-3">
                    <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${status === "Active" ? "bg-emerald-400/15 text-emerald-200" : "bg-white/10 text-indigo-200"}`}>{status}</span>
                  </td>
                  <td className="py-3 pr-3 text-indigo-200">{fmt(i.expiresAt)}</td>
                  <td className="py-3 pr-3 text-indigo-200">{i.useCount}</td>
                  <td className="py-3 text-right">
                    {status === "Active" && (
                      <button type="button" onClick={() => revoke(i.id)} className="rounded-lg px-3 py-1.5 text-xs font-semibold text-rose-200 ring-1 ring-rose-400/40 hover:bg-rose-500/20">
                        Revoke
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
