"use client";

import { useCallback, useEffect, useRef, useState } from "react";

/*
 * Consent-first classroom.
 * - Nothing is requested on page load. Camera/microphone prompts only after the learner
 *   ticks the consent box AND clicks "Enable camera".
 * - Only the camera track is requested (no microphone).
 * - Turning the camera off or leaving stops every track immediately.
 * - This deployment has no live video relay (SFU) configured, so the preview stays on this
 *   device and is NOT sent to the instructor. The UI says so explicitly.
 */

type CamState = "off" | "requesting" | "on" | "denied" | "error" | "offline" | "left";

const EVENT_URL = "/api/classroom/event";

async function logEvent(event: string) {
  try {
    await fetch(EVENT_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ event }),
      keepalive: true,
    });
  } catch {
    /* logging is best-effort; never block the learner */
  }
}

export function Classroom({ hasInvite }: { hasInvite: boolean }) {
  const [state, setState] = useState<CamState>("off");
  const [consent, setConsent] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [online, setOnline] = useState(true);

  // Stop every track on the stream (video + audio) and detach from the preview.
  const stopAll = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => {
      t.onended = null;
      t.stop();
    });
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
  }, []);

  useEffect(() => {
    const goOffline = () => {
      setOnline(false);
      stopAll();
      setState("offline");
      setMessage("Connection lost. Your camera has been turned off for your privacy. We’ll reconnect when you’re back online.");
    };
    const goOnline = () => {
      setOnline(true);
      setState((s) => (s === "offline" ? "off" : s));
      setMessage("You’re back online. Your camera is still off. Turn it on only if you want to.");
    };
    window.addEventListener("offline", goOffline);
    window.addEventListener("online", goOnline);
    return () => {
      window.removeEventListener("offline", goOffline);
      window.removeEventListener("online", goOnline);
      stopAll();
    };
  }, [stopAll]);

  // Attach the stream to the preview element once it is mounted.
  useEffect(() => {
    if (state === "on" && videoRef.current && streamRef.current) {
      videoRef.current.srcObject = streamRef.current;
      void videoRef.current.play().catch(() => {});
    }
  }, [state]);

  const turnOn = async () => {
    if (!consent || !online) return;
    if (!navigator.mediaDevices?.getUserMedia) {
      setState("error");
      setMessage("This browser can’t use a camera here. You can keep studying with your camera off.");
      return;
    }
    setState("requesting");
    setMessage("Your browser will ask for camera permission. Choose “Allow” only if you’re comfortable with the consent above.");
    try {
      // Video only. Microphone is never requested by this screen.
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 }, audio: false });
      streamRef.current = stream;
      stream.getVideoTracks().forEach((track) => {
        track.onended = () => {
          stopAll();
          setState("off");
          setMessage("Your camera stopped or was disconnected. It is off now.");
          void logEvent("camera_off");
        };
      });
      setState("on");
      setMessage(null);
      void logEvent("camera_consent");
      void logEvent("camera_on");
    } catch (err) {
      const name = err instanceof DOMException ? err.name : "";
      stopAll();
      if (name === "NotAllowedError" || name === "SecurityError") {
        setState("denied");
        setMessage("Camera permission is blocked. You can still study and join the lesson with your camera off. To try again, allow camera access for this site in your browser settings.");
      } else if (name === "NotFoundError" || name === "OverconstrainedError") {
        setState("error");
        setMessage("We couldn’t find a camera on this device. You can keep studying with your camera off.");
      } else if (name === "NotReadableError") {
        setState("error");
        setMessage("Your camera is being used by another app. Close it, then try again. Studying with your camera off works fine too.");
      } else {
        setState("error");
        setMessage("Something went wrong starting the camera. Please try again in a moment.");
      }
    }
  };

  const turnOff = () => {
    stopAll();
    setState("off");
    setMessage("Camera is off. Your video is no longer being captured.");
    void logEvent("camera_off");
  };

  const leave = () => {
    stopAll();
    setState("left");
    setConsent(false);
    setMessage("You left the session. Your camera and microphone are off.");
    void logEvent("left");
  };

  const isOn = state === "on";
  const isBusy = state === "requesting";

  return (
    <div className="grid gap-6 lg:grid-cols-[1.25fr_1fr]">
      {/* Video / study panel */}
      <section aria-labelledby="stage-title" className="flex flex-col overflow-hidden rounded-3xl bg-ink text-white shadow-2xl shadow-indigo-900/20">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-5 py-4">
          <div>
            <h2 id="stage-title" className="text-lg font-semibold">Beginner Hangul · Live room</h2>
            <p className="text-xs text-indigo-200">{hasInvite ? "Invitation active" : "Demo room — no invitation"}</p>
          </div>
          <span className="rounded-full bg-amber-400/15 px-3 py-1 text-xs font-semibold text-amber-200 ring-1 ring-amber-300/30">
            Demo · live video relay not configured
          </span>
        </div>

        {/* Persistent camera indicator */}
        <div
          role="status"
          aria-live="polite"
          className={`flex items-center gap-3 px-5 py-3 text-sm font-semibold ${isOn ? "bg-rose-600" : "bg-white/5 text-slate-200"}`}
        >
          {isOn ? (
            <>
              <span aria-hidden="true" className="h-3 w-3 shrink-0 rounded-full bg-white animate-pulse-dot" />
              <span>Camera is on — demo preview only, not shared with your instructor</span>
              <span lang="ko" className="ml-auto hidden text-xs font-normal opacity-90 sm:inline">카메라 켜짐 — 데모 미리보기</span>
            </>
          ) : (
            <>
              <span aria-hidden="true" className="h-3 w-3 shrink-0 rounded-full bg-slate-400" />
              <span>Camera is off · Microphone is off</span>
            </>
          )}
        </div>

        <div className="relative aspect-video w-full bg-gradient-to-br from-[#1b2a6b] to-[#0b1020]">
          {/* Real camera preview only exists when state === "on" */}
          <video
            ref={videoRef}
            muted
            playsInline
            aria-label="Your camera preview (on this device only)"
            className={`absolute inset-0 h-full w-full -scale-x-100 object-cover ${isOn ? "block" : "hidden"}`}
          />
          {!isOn && (
            <div className="absolute inset-0 grid place-items-center p-6 text-center">
              <div>
                <div aria-hidden="true" className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-white/10 text-4xl ring-1 ring-white/20">🎧</div>
                <p className="mt-4 font-semibold">Study with your camera off</p>
                <p className="mt-1 max-w-xs text-sm text-indigo-200">Everything in the lesson works without video.</p>
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3 p-5">
          {isOn ? (
            <button type="button" onClick={turnOff} className="rounded-2xl bg-white/10 px-5 py-3 font-semibold text-white ring-1 ring-white/20 transition hover:bg-white/20">
              Turn camera off
            </button>
          ) : (
            <button
              type="button"
              onClick={turnOn}
              disabled={!consent || isBusy || !online || state === "left"}
              className="btn-primary rounded-2xl px-5 py-3 font-semibold disabled:cursor-not-allowed disabled:opacity-40 disabled:shadow-none disabled:hover:translate-y-0"
              aria-describedby="enable-hint"
            >
              {isBusy ? "Waiting for permission…" : "Enable camera"}
            </button>
          )}
          <button
            type="button"
            onClick={leave}
            disabled={state === "left"}
            className="rounded-2xl border border-rose-300/50 px-5 py-3 font-semibold text-rose-200 transition hover:bg-rose-500/20 disabled:opacity-40"
          >
            Leave session
          </button>
          {!consent && !isOn && <p id="enable-hint" className="basis-full text-xs text-indigo-200">Tick the consent box below to enable the camera button.</p>}
        </div>
      </section>

      {/* Consent + status panel */}
      <aside aria-labelledby="consent-title" className="flex flex-col gap-5">
        <section className="rounded-3xl bg-white p-6 ring-1 ring-slate-200">
          <h2 id="consent-title" className="text-lg font-bold text-ink">Camera consent</h2>
          <ul className="mt-4 space-y-3 text-sm text-slate-700">
            <li className="flex gap-3"><span aria-hidden="true">🔒</span><span><strong className="text-ink">Who can see your video:</strong> only your instructor or an authorized administrator for this session. Other learners cannot see it.</span></li>
            <li className="flex gap-3"><span aria-hidden="true">⏺️</span><span><strong className="text-ink">Recording:</strong> video is not recorded or stored by default.</span></li>
            <li className="flex gap-3"><span aria-hidden="true">✋</span><span><strong className="text-ink">Your control:</strong> the camera is off by default. Turn it off or leave at any time, and it stops immediately.</span></li>
          </ul>

          <label className="mt-5 flex cursor-pointer items-start gap-3 rounded-2xl bg-slate-50 p-4 text-sm text-ink ring-1 ring-slate-200 has-[:checked]:ring-brand">
            <input
              type="checkbox"
              checked={consent}
              onChange={(e) => setConsent(e.target.checked)}
              className="mt-0.5 h-5 w-5 shrink-0 accent-brand"
            />
            <span>
              I understand that if I turn on my camera, <strong>only my instructor or an authorized administrator</strong> can see my video. I can turn it off or leave at any time.
            </span>
          </label>
          <p className="mt-3 text-xs text-slate-500">Microphone is not requested on this screen.</p>
        </section>

        <section aria-labelledby="status-title" className="rounded-3xl bg-white p-6 ring-1 ring-slate-200">
          <h2 id="status-title" className="text-lg font-bold text-ink">Status</h2>
          {message ? (
            <p role="status" className={`mt-3 rounded-2xl p-4 text-sm leading-relaxed ${state === "denied" || state === "error" || state === "offline" ? "bg-amber-50 text-amber-900 ring-1 ring-amber-200" : "bg-slate-50 text-slate-700"}`}>
              {message}
            </p>
          ) : (
            <p className="mt-3 text-sm text-slate-600">Ready when you are. Nothing has been requested from your device.</p>
          )}
          {state === "denied" && (
            <p className="mt-3 text-xs text-slate-500">Tip: click the lock or camera icon in your address bar to change site permissions.</p>
          )}
        </section>

        <section className="rounded-3xl bg-gradient-to-br from-[#eef1ff] to-[#e9fbf8] p-6 ring-1 ring-slate-200">
          <h2 className="text-base font-bold text-ink">About this demo</h2>
          <p className="mt-2 text-sm leading-relaxed text-slate-700">
            This deployment does not run a live video server, so nothing you do here reaches an instructor. The consent and camera controls are working so you can see exactly how the live classroom behaves.
          </p>
        </section>
      </aside>
    </div>
  );
}
