import Link from "next/link";

export function Hero() {
  return (
    <section aria-labelledby="hero-title" className="relative overflow-hidden">
      {/* Ambient background */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 grid-bg opacity-60 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
      <div aria-hidden="true" className="pointer-events-none absolute -top-40 left-1/2 -z-10 h-[38rem] w-[38rem] -translate-x-1/2 rounded-full bg-gradient-to-br from-[#3b5bff]/30 via-[#8b5cf6]/25 to-[#14b8a6]/25 blur-3xl animate-drift" />
      <div aria-hidden="true" className="pointer-events-none absolute right-[-6rem] top-40 -z-10 h-72 w-72 rounded-full bg-rose-400/20 blur-3xl animate-drift [animation-delay:-6s]" />

      <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 pb-20 pt-10 md:pt-16 lg:grid-cols-[1.05fr_0.95fr] lg:gap-16 lg:pb-28 lg:pt-20">
        <div>
          <p
            data-reveal
            className="glass inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-xs font-semibold text-brand"
          >
            <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-mint" />
            Beginner-friendly · Korean for real life
          </p>

          <h1
            id="hero-title"
            data-reveal
            style={{ "--reveal-delay": "80ms" } as React.CSSProperties}
            className="mt-6 text-balance text-[clamp(2.4rem,6.2vw,4.25rem)] font-extrabold leading-[1.02] tracking-tight text-ink"
          >
            Speak Korean with confidence,{" "}
            <span className="text-gradient">one clear step at a time.</span>
          </h1>

          <p
            data-reveal
            style={{ "--reveal-delay": "160ms" } as React.CSSProperties}
            className="mt-6 max-w-xl text-pretty text-lg leading-relaxed text-slate-700"
          >
            Learn Hangul, pronunciation, vocabulary, grammar, listening, and real conversation with structured lessons that adapt to your pace.
          </p>

          <div
            data-reveal
            style={{ "--reveal-delay": "240ms" } as React.CSSProperties}
            className="mt-8 flex flex-col gap-3 sm:flex-row"
          >
            <Link href="/learn" className="btn-primary inline-flex items-center justify-center gap-2 rounded-2xl px-7 py-4 text-base font-semibold">
              Start learning
              <span aria-hidden="true" className="transition-transform group-hover:translate-x-1">→</span>
            </Link>
            <Link
              href="/classroom"
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-300 bg-white/80 px-7 py-4 text-base font-semibold text-ink backdrop-blur transition hover:-translate-y-0.5 hover:border-brand hover:shadow-lg hover:shadow-indigo-500/10"
            >
              Join a lesson
            </Link>
          </div>

          <ul
            data-reveal
            style={{ "--reveal-delay": "320ms" } as React.CSSProperties}
            className="mt-8 flex flex-wrap gap-x-6 gap-y-3 text-sm text-slate-700"
            aria-label="Trust signals"
          >
            <li className="flex items-center gap-2"><Check />Free to start, no card needed</li>
            <li className="flex items-center gap-2"><Check />Camera always off until you choose</li>
            <li className="flex items-center gap-2"><Check />Cancel anytime</li>
          </ul>
        </div>

        {/* Premium visual: layered lesson preview */}
        <div data-reveal style={{ "--reveal-delay": "200ms" } as React.CSSProperties} className="relative mx-auto w-full max-w-md lg:max-w-none">
          <div aria-hidden="true" className="absolute -inset-6 -z-10 rounded-[2.5rem] bg-gradient-to-br from-[#3b5bff]/20 via-transparent to-[#14b8a6]/20 blur-2xl" />
          <div className="glass relative overflow-hidden rounded-[2rem] p-5 sm:p-7 animate-float-slow">
            <div className="flex items-center justify-between">
              <span className="rounded-full bg-ink px-3 py-1 text-xs font-semibold text-white">Lesson 2 · Vowels</span>
              <span className="text-xs font-medium text-slate-500">Day 6 streak</span>
            </div>

            <div className="relative mt-5 overflow-hidden rounded-3xl bg-gradient-to-br from-[#0b1020] via-[#1b2a6b] to-[#4c1d95] p-6 text-white">
              <div aria-hidden="true" className="shine absolute inset-0 opacity-40" />
              <p className="text-sm text-indigo-200">Read the letter</p>
              <p lang="ko" className="mt-2 text-7xl font-bold leading-none sm:text-8xl">ㅏ</p>
              <p className="mt-4 text-sm text-indigo-100">
                Sounds like <span className="font-semibold text-white">“a”</span> in <em>father</em>
              </p>
              <div className="absolute -right-10 -top-10 h-36 w-36 opacity-30 taegeuk-ring animate-float-slow" aria-hidden="true" />
            </div>

            <div className="mt-4 grid grid-cols-4 gap-2" role="list" aria-label="Vowel practice">
              {["ㅏ", "ㅓ", "ㅗ", "ㅜ"].map((v, i) => (
                <div
                  key={v}
                  role="listitem"
                  lang="ko"
                  className={`grid aspect-square place-items-center rounded-2xl text-2xl font-bold ${
                    i === 0 ? "bg-brand text-white shadow-lg shadow-indigo-500/30" : "bg-white text-ink ring-1 ring-slate-200"
                  }`}
                >
                  {v}
                </div>
              ))}
            </div>

            <div className="mt-5 flex items-center gap-3 rounded-2xl bg-white p-3 ring-1 ring-slate-200">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-mint/15 text-mint" aria-hidden="true">✓</div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-ink">Quiz: 3 of 4 correct</p>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-slate-200" role="progressbar" aria-label="Lesson progress" aria-valuenow={75} aria-valuemin={0} aria-valuemax={100}>
                  <div className="h-full w-3/4 rounded-full bg-gradient-to-r from-brand to-mint" />
                </div>
              </div>
            </div>
          </div>

          <div className="glass absolute -bottom-5 -left-3 hidden rounded-2xl px-4 py-3 sm:block animate-float-slow [animation-delay:-3s]">
            <p className="text-xs text-slate-500">Next review</p>
            <p className="text-sm font-semibold text-ink">Due in 2 hours</p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Check() {
  return (
    <span aria-hidden="true" className="grid h-5 w-5 place-items-center rounded-full bg-mint/15 text-mint">
      <svg viewBox="0 0 20 20" className="h-3 w-3" fill="currentColor"><path d="M7.6 13.4 4.2 10l-1.2 1.2 4.6 4.6 9-9-1.2-1.2z" /></svg>
    </span>
  );
}
