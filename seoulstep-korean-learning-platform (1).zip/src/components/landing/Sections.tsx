import Link from "next/link";

const audiences = ["Complete beginners", "Travelers to Korea", "K-pop & K-drama fans", "University students", "Working professionals"];

export function AudienceStrip() {
  const items = [...audiences, ...audiences];
  return (
    <section aria-label="Who SeoulStep is for" className="border-y border-slate-200 bg-white/70 py-6">
      <p className="sr-only">Built for:</p>
      <div className="overflow-hidden [mask-image:linear-gradient(90deg,transparent,black_10%,black_90%,transparent)]">
        <ul className="flex w-max animate-marquee gap-12 whitespace-nowrap pr-12 text-sm font-semibold uppercase tracking-[0.18em] text-slate-500" aria-hidden="true">
          {items.map((a, i) => (
            <li key={i} className="flex items-center gap-12">
              {a}
              <span className="dancheong-stripe h-2 w-8 rounded-full opacity-70" />
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

const stats = [
  { value: "6", label: "structured learning paths", detail: "Hangul → conversation" },
  { value: "3", label: "review intervals in flashcards", detail: "Spaced repetition, Leitner boxes" },
  { value: "0", label: "camera or mic on by default", detail: "You choose every time" },
  { value: "24h", label: "maximum default invite lifetime", detail: "Links expire and can be revoked" },
];

export function Stats() {
  return (
    <section aria-labelledby="stats-title" className="mx-auto max-w-6xl px-5 py-20">
      <div data-reveal className="max-w-2xl">
        <p className="text-sm font-semibold uppercase tracking-widest text-brand">Built on how memory works</p>
        <h2 id="stats-title" className="mt-3 text-balance text-3xl font-bold tracking-tight text-ink sm:text-4xl">
          Concrete design choices, not vague promises.
        </h2>
      </div>
      <dl className="mt-12 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s, i) => (
          <div
            key={s.label}
            data-reveal
            style={{ "--reveal-delay": `${i * 90}ms` } as React.CSSProperties}
            className="group relative overflow-hidden rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 transition duration-500 hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-500/10"
          >
            <div aria-hidden="true" className="absolute -right-6 -top-6 h-20 w-20 rounded-full bg-gradient-to-br from-brand/15 to-mint/15 transition-transform duration-700 group-hover:scale-150" />
            <dt className="text-sm font-medium text-slate-600">{s.label}</dt>
            <dd className="mt-2 text-4xl font-extrabold tracking-tight text-gradient">{s.value}</dd>
            <p className="mt-2 text-xs text-slate-500">{s.detail}</p>
          </div>
        ))}
      </dl>
    </section>
  );
}

const features = [
  { icon: "ㅎ", title: "Hangul, fast", body: "Read the 24 basic consonants and vowels in short, sound-first drills before you learn any words.", color: "from-[#3b5bff] to-[#6d7cff]" },
  { icon: "🔊", title: "Pronunciation", body: "Hear each sound with a built-in voice, then practice the tricky tense and aspirated consonants step by step.", color: "from-[#8b5cf6] to-[#c084fc]" },
  { icon: "📚", title: "Vocabulary", body: "Learn words in everyday context: food, travel, school, work, and K-drama phrases you will actually hear.", color: "from-[#14b8a6] to-[#5eead4]" },
  { icon: "🧩", title: "Grammar", body: "Clear patterns with examples, from basic sentence endings to politeness levels, one rule at a time.", color: "from-[#f59e0b] to-[#fcd34d]" },
  { icon: "👂", title: "Listening", body: "Short audio clips with slow and normal speed, plus comprehension questions after each one.", color: "from-[#f43f5e] to-[#fb7185]" },
  { icon: "💬", title: "Conversation", body: "Role-play real situations: ordering coffee, introducing yourself, asking for directions.", color: "from-[#0ea5e9] to-[#38bdf8]" },
  { icon: "✅", title: "Quizzes", body: "Short quizzes after each lesson show exactly which items to review, with instant feedback.", color: "from-[#22c55e] to-[#86efac]" },
  { icon: "🗂️", title: "Flashcards + spaced repetition", body: "Cards you miss come back sooner; cards you know move to longer gaps. Less cramming, more recall.", color: "from-[#6366f1] to-[#a5b4fc]" },
  { icon: "📈", title: "Progress tracking", body: "See completed lessons, review load and streaks on one simple dashboard that you control.", color: "from-[#0f766e] to-[#2dd4bf]" },
  { icon: "🏅", title: "Lesson badges", body: "Earn a badge for finishing each lesson. Badges celebrate effort, not pressure or leaderboards.", color: "from-[#d97706] to-[#fbbf24]" },
  { icon: "↩️", title: "Resume where you left off", body: "Pick up at the exact card or question you stopped on, on any device you're signed into.", color: "from-[#7c3aed] to-[#c4b5fd]" },
  { icon: "🎥", title: "Consent-first live classes", body: "Optional instructor-led sessions. Your camera stays off until you explicitly turn it on.", color: "from-[#e11d48] to-[#fda4af]" },
];

export function Features() {
  return (
    <section id="features" aria-labelledby="features-title" className="scroll-mt-24 bg-white py-24">
      <div className="mx-auto max-w-6xl px-5">
        <div data-reveal className="max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-widest text-brand">Everything in one path</p>
          <h2 id="features-title" className="mt-3 text-balance text-3xl font-bold tracking-tight text-ink sm:text-4xl">
            Every skill you need to hold a real conversation.
          </h2>
          <p className="mt-4 text-lg text-slate-600">Lessons build in order, so each step gives the next one something to stand on.</p>
        </div>

        <ul className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <li
              key={f.title}
              data-reveal
              style={{ "--reveal-delay": `${(i % 3) * 90}ms` } as React.CSSProperties}
              className="group relative overflow-hidden rounded-3xl border border-slate-200 bg-white p-6 transition duration-500 hover:-translate-y-1 hover:border-transparent hover:shadow-2xl hover:shadow-indigo-500/15"
            >
              <div aria-hidden="true" className={`absolute inset-x-0 top-0 h-1 origin-left scale-x-0 bg-gradient-to-r ${f.color} transition-transform duration-500 group-hover:scale-x-100`} />
              <div aria-hidden="true" className={`grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ${f.color} text-xl font-bold text-white shadow-lg transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110`}>
                {f.icon}
              </div>
              <h3 className="mt-5 text-lg font-semibold text-ink">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-600">{f.body}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export function Showcase() {
  const days = [
    { d: "Mon", done: true }, { d: "Tue", done: true }, { d: "Wed", done: true }, { d: "Thu", done: false, today: true },
    { d: "Fri", done: false }, { d: "Sat", done: false }, { d: "Sun", done: false },
  ];
  return (
    <section id="showcase" aria-labelledby="showcase-title" className="scroll-mt-24 overflow-hidden py-24">
      <div className="mx-auto grid max-w-6xl items-center gap-14 px-5 lg:grid-cols-2">
        <div data-reveal>
          <p className="text-sm font-semibold uppercase tracking-widest text-brand">Product preview</p>
          <h2 id="showcase-title" className="mt-3 text-balance text-3xl font-bold tracking-tight text-ink sm:text-4xl">
            A lesson that tells you what to do next.
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-slate-600">
            Each lesson opens with a clear goal, teaches one idea, checks it with a quick quiz, and schedules the cards you need to review. Here is how a Tuesday session looks.
          </p>
          <ol className="mt-8 space-y-4">
            {[
              ["Warm up", "Review 5 due flashcards from yesterday."],
              ["Learn", "Study ㅓ vs ㅏ with audio and mouth-shape tips."],
              ["Check", "Answer 4 quick questions. Miss one? It returns tomorrow."],
              ["Speak", "Say “안녕하세요” in a short role-play, then get feedback."],
            ].map(([t, b], i) => (
              <li key={t} className="flex gap-4">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-ink text-sm font-bold text-white">{i + 1}</span>
                <div>
                  <p className="font-semibold text-ink">{t}</p>
                  <p className="text-sm text-slate-600">{b}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>

        <div data-reveal style={{ "--reveal-delay": "150ms" } as React.CSSProperties} className="relative">
          <div aria-hidden="true" className="absolute -inset-8 -z-10 rounded-[3rem] bg-gradient-to-tr from-[#3b5bff]/20 via-[#8b5cf6]/15 to-[#14b8a6]/20 blur-3xl" />
          <div className="mx-auto max-w-md rounded-[2.25rem] bg-ink p-3 shadow-2xl shadow-indigo-900/40">
            <div className="overflow-hidden rounded-[1.75rem] bg-[#f7f8fc]">
              <div className="flex items-center justify-between bg-white px-5 py-4">
                <div>
                  <p className="text-xs text-slate-500">Good evening, Minji</p>
                  <p className="font-semibold text-ink">Keep your 6-day streak</p>
                </div>
                <div className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-brand to-mint text-sm font-bold text-white" aria-hidden="true">M</div>
              </div>

              <div className="p-5">
                <div className="rounded-2xl bg-white p-4 ring-1 ring-slate-200">
                  <div className="flex justify-between text-xs font-medium text-slate-500">
                    <span>This week</span><span>3 of 7 days</span>
                  </div>
                  <div className="mt-3 grid grid-cols-7 gap-1.5" role="img" aria-label="Mon, Tue and Wed completed; Thu is today; Fri to Sun still to do">
                    {days.map((d) => (
                      <div key={d.d} className="text-center">
                        <div className={`mx-auto grid h-8 w-8 place-items-center rounded-full text-xs font-bold ${d.done ? "bg-mint text-white" : d.today ? "bg-brand text-white ring-4 ring-brand/20" : "bg-slate-100 text-slate-400"}`}>
                          {d.done ? "✓" : ""}
                        </div>
                        <p className="mt-1 text-[10px] text-slate-500">{d.d}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 rounded-2xl bg-gradient-to-br from-brand to-brand-2 p-5 text-white shadow-lg shadow-indigo-500/30">
                  <p className="text-xs font-medium text-indigo-100">Resume · Lesson 3 of Vowels</p>
                  <p className="mt-1 text-lg font-semibold">Read ㅓ and ㅗ</p>
                  <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-white/25" role="progressbar" aria-label="Lesson 3 progress" aria-valuenow={40} aria-valuemin={0} aria-valuemax={100}>
                    <div className="h-full w-2/5 rounded-full bg-white" />
                  </div>
                  <p className="mt-2 text-xs text-indigo-100">40% · about 6 minutes left</p>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-3">
                  <div className="rounded-2xl bg-white p-4 ring-1 ring-slate-200">
                    <p className="text-xs text-slate-500">Cards due</p>
                    <p className="mt-1 text-2xl font-bold text-ink">12</p>
                  </div>
                  <div className="rounded-2xl bg-white p-4 ring-1 ring-slate-200">
                    <p className="text-xs text-slate-500">Badges</p>
                    <p className="mt-1 text-2xl font-bold text-ink">🏅 4</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

const benefits = [
  {
    title: "Confidence",
    body: "You practice speaking out loud from lesson one. Short, low-pressure drills mean you learn to say the sound before you worry about being perfect.",
    points: ["Pronounce before you read", "Hear every example with audio", "Mistakes are reviewed, not punished"],
  },
  {
    title: "Consistency",
    body: "Ten focused minutes a day beats a three-hour weekend. Gentle reminders, streak-friendly review queues and resumable lessons keep you coming back.",
    points: ["Daily plan sized to your time", "Spaced reviews before you forget", "Pick up exactly where you stopped"],
  },
  {
    title: "Real conversation",
    body: "Practice the phrases you will actually use: greetings, ordering food, asking for help, talking about your day. Optional live classes add a real instructor.",
    points: ["Role-play everyday situations", "Listening from natural-speed clips", "Live classes with a human teacher"],
  },
];

export function Benefits() {
  return (
    <section id="benefits" aria-labelledby="benefits-title" className="scroll-mt-24 bg-ink py-24 text-white">
      <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />
      <div className="mx-auto max-w-6xl px-5">
        <div data-reveal className="max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-widest text-mint">Why learners stay</p>
          <h2 id="benefits-title" className="mt-3 text-balance text-3xl font-bold tracking-tight sm:text-4xl">
            Confidence, consistency, and conversation you can use this week.
          </h2>
        </div>
        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {benefits.map((b, i) => (
            <article
              key={b.title}
              data-reveal
              style={{ "--reveal-delay": `${i * 120}ms` } as React.CSSProperties}
              className="glass-dark group rounded-3xl p-7 transition duration-500 hover:-translate-y-1 hover:bg-white/10"
            >
              <p className="text-sm font-semibold text-mint">0{i + 1}</p>
              <h3 className="mt-3 text-2xl font-bold">{b.title}</h3>
              <p className="mt-3 leading-relaxed text-indigo-100/90">{b.body}</p>
              <ul className="mt-6 space-y-2.5 text-sm text-indigo-50">
                {b.points.map((p) => (
                  <li key={p} className="flex gap-2.5">
                    <span aria-hidden="true" className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-mint" />
                    {p}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

const testimonials = [
  { quote: "I could read signs in Seoul on my second day. The Hangul drills are short enough that I actually finished them.", name: "Sample: Traveler, planning a first trip", tag: "Travel" },
  { quote: "The spaced repetition cards fixed my habit of forgetting words the week after I learned them.", name: "Sample: University student", tag: "Study" },
  { quote: "I wanted to understand lyrics without subtitles. Listening clips with slow speed made that realistic.", name: "Sample: K-pop fan", tag: "Fandom" },
  { quote: "Twelve minutes on my commute is enough to keep my streak. The resume feature means no lost progress.", name: "Sample: Working professional", tag: "Work" },
];

export function Testimonials() {
  return (
    <section id="testimonials" aria-labelledby="testimonials-title" className="scroll-mt-24 py-24">
      <div className="mx-auto max-w-6xl px-5">
        <div data-reveal className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-widest text-brand">Learner stories</p>
            <h2 id="testimonials-title" className="mt-3 text-balance text-3xl font-bold tracking-tight text-ink sm:text-4xl">
              Real goals, practical progress.
            </h2>
          </div>
          <p className="max-w-xs rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-900 ring-1 ring-amber-200">
            Illustrative quotes for this preview. Replace with verified learner feedback before launch.
          </p>
        </div>
        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {testimonials.map((t, i) => (
            <figure
              key={t.tag}
              data-reveal
              style={{ "--reveal-delay": `${(i % 2) * 120}ms` } as React.CSSProperties}
              className="relative rounded-3xl bg-white p-7 shadow-sm ring-1 ring-slate-200 transition duration-500 hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-500/10"
            >
              <span aria-hidden="true" className="absolute right-6 top-4 text-6xl font-serif text-brand/15">”</span>
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-brand/10 px-2.5 py-1 text-xs font-semibold text-brand">{t.tag}</span>
              </div>
              <blockquote className="mt-4 text-lg leading-relaxed text-ink">“{t.quote}”</blockquote>
              <figcaption className="mt-5 text-sm font-medium text-slate-600">{t.name}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

const tiers = [
  {
    name: "Explorer",
    price: "$0",
    period: "forever",
    desc: "Start with Hangul and see how it feels.",
    features: ["Hangul path (all 24 letters)", "3 flashcard reviews a day", "Basic progress tracking", "Lesson badges"],
    cta: "Start free",
    href: "/learn",
    recommended: false,
  },
  {
    name: "Plus",
    price: "$9",
    period: "per month",
    desc: "The full self-paced path for steady progress.",
    features: ["All 6 learning paths", "Unlimited spaced-repetition cards", "Listening clips at two speeds", "Quizzes with review queue", "Resume on any device"],
    cta: "Choose Plus",
    href: "/contact?plan=plus",
    recommended: true,
  },
  {
    name: "Live Class",
    price: "$19",
    period: "per month",
    desc: "Everything in Plus, plus small instructor-led classes.",
    features: ["Everything in Plus", "Small group live classes", "Optional camera, always consent-based", "Instructor feedback on speaking"],
    cta: "Ask about Live Class",
    href: "/contact?plan=live",
    recommended: false,
  },
];

export function Pricing() {
  return (
    <section id="pricing" aria-labelledby="pricing-title" className="scroll-mt-24 bg-white py-24">
      <div className="mx-auto max-w-6xl px-5">
        <div data-reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-brand">Pricing</p>
          <h2 id="pricing-title" className="mt-3 text-balance text-3xl font-bold tracking-tight text-ink sm:text-4xl">
            Start free. Upgrade when the habit sticks.
          </h2>
          <p className="mt-4 text-slate-600">Prices in USD, billed monthly. Cancel anytime.</p>
        </div>

        <div className="mt-14 grid items-stretch gap-6 lg:grid-cols-3">
          {tiers.map((t, i) => (
            <article
              key={t.name}
              data-reveal
              style={{ "--reveal-delay": `${i * 120}ms` } as React.CSSProperties}
              aria-labelledby={`tier-${i}`}
              className={`relative flex flex-col rounded-3xl p-7 transition duration-500 hover:-translate-y-1 ${
                t.recommended
                  ? "bg-ink text-white shadow-2xl shadow-indigo-600/30 ring-2 ring-brand lg:-my-4 lg:py-10"
                  : "bg-white ring-1 ring-slate-200 hover:shadow-xl hover:shadow-indigo-500/10"
              }`}
            >
              {t.recommended && (
                <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-brand to-brand-2 px-4 py-1 text-xs font-semibold text-white shadow-lg">
                  Recommended
                </span>
              )}
              <h3 id={`tier-${i}`} className="text-xl font-bold">{t.name}</h3>
              <p className={`mt-2 text-sm ${t.recommended ? "text-indigo-200" : "text-slate-600"}`}>{t.desc}</p>
              <p className="mt-6">
                <span className="text-4xl font-extrabold">{t.price}</span>{" "}
                <span className={`text-sm ${t.recommended ? "text-indigo-200" : "text-slate-500"}`}>{t.period}</span>
              </p>
              <ul className="mt-6 flex-1 space-y-3 text-sm">
                {t.features.map((f) => (
                  <li key={f} className="flex gap-2.5">
                    <span aria-hidden="true" className={`mt-0.5 font-bold ${t.recommended ? "text-mint" : "text-brand"}`}>✓</span>
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                href={t.href}
                className={`mt-8 block rounded-2xl px-5 py-3.5 text-center font-semibold transition ${
                  t.recommended ? "btn-primary" : "border border-slate-300 text-ink hover:border-brand hover:text-brand"
                }`}
              >
                {t.cta}
              </Link>
            </article>
          ))}
        </div>
        <p data-reveal className="mx-auto mt-10 max-w-2xl text-center text-xs text-slate-500">
          Paid plans are not yet billable in this preview. Choosing a paid plan opens our contact form to join the early-access list.
        </p>
      </div>
    </section>
  );
}

const faqs = [
  { q: "Is SeoulStep good for complete beginners?", a: "Yes. The first path teaches the 24 basic Hangul letters with sound-first drills. You don't need any prior Korean and can move at your own pace." },
  { q: "How does the spaced repetition work?", a: "Flashcards you get right move into longer review gaps; cards you miss return sooner. Your review queue is generated automatically each day." },
  { q: "Do I need to turn on my camera for live classes?", a: "No. Camera and microphone are always off by default. You can study and join a lesson with your camera off. If you choose to enable it, you press “Enable camera” and only then does your browser ask for permission." },
  { q: "Who can see my video in a live class?", a: "Only the instructor or an authorized administrator for that session. Other learners cannot see your video, and nothing is recorded or stored by default. You can turn the camera off or leave at any time, which stops the camera and microphone immediately." },
  { q: "What is a lesson invitation link?", a: "A link your instructor shares to let you join one class. It gives learner access only, expires automatically, and can be revoked by the instructor. It never gives admin access." },
  { q: "Can I use SeoulStep on my phone?", a: "Yes. The site is mobile-first and works in current versions of Safari, Chrome, Edge and Firefox on phones, tablets and desktops." },
  { q: "Is this an official Korean certification?", a: "No. SeoulStep is an educational platform. It helps you prepare, but it is not an official TOPIK or government certification." },
];

export function FAQ() {
  return (
    <section id="faq" aria-labelledby="faq-title" className="scroll-mt-24 py-24">
      <div className="mx-auto grid max-w-6xl gap-12 px-5 lg:grid-cols-[0.8fr_1.2fr]">
        <div data-reveal>
          <p className="text-sm font-semibold uppercase tracking-widest text-brand">FAQ</p>
          <h2 id="faq-title" className="mt-3 text-balance text-3xl font-bold tracking-tight text-ink sm:text-4xl">
            Questions, answered plainly.
          </h2>
          <p className="mt-4 text-slate-600">
            Still unsure? <Link href="/contact" className="font-semibold text-brand underline-offset-4 hover:underline">Contact us</Link>.
          </p>
        </div>
        <div className="divide-y divide-slate-200 rounded-3xl bg-white px-6 ring-1 ring-slate-200">
          {faqs.map((f, i) => (
            <details key={f.q} data-reveal style={{ "--reveal-delay": `${i * 60}ms` } as React.CSSProperties} className="group py-5">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 rounded-lg text-left font-semibold text-ink">
                {f.q}
                <span aria-hidden="true" className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-slate-100 text-brand transition-transform duration-300 group-open:rotate-45">+</span>
              </summary>
              <p className="mt-3 pr-8 leading-relaxed text-slate-600">{f.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

export function FinalCTA() {
  return (
    <section aria-labelledby="final-cta-title" className="px-5 pb-24">
      <div data-reveal className="relative mx-auto max-w-6xl overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-[#0b1020] via-[#1e2a78] to-[#4c1d95] px-7 py-16 text-center text-white shadow-2xl shadow-indigo-900/30 sm:px-14">
        <div aria-hidden="true" className="absolute -left-20 -top-20 h-72 w-72 rounded-full bg-mint/30 blur-3xl animate-drift" />
        <div aria-hidden="true" className="absolute -bottom-24 -right-16 h-80 w-80 rounded-full bg-rose-400/25 blur-3xl animate-drift [animation-delay:-8s]" />
        <div aria-hidden="true" className="absolute right-8 top-8 hidden h-16 w-16 opacity-40 taegeuk-ring animate-float-slow sm:block" />
        <div className="relative">
          <h2 id="final-cta-title" className="mx-auto max-w-2xl text-balance text-3xl font-bold tracking-tight sm:text-5xl">
            Your first Korean word is one tap away.
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-lg text-indigo-100">
            Start with the Hangul path today. It takes about ten minutes, and you can stop whenever you like.
          </p>
          <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link href="/learn" className="btn-primary rounded-2xl bg-white px-8 py-4 text-base font-semibold text-ink hover:bg-white">
              Start learning
            </Link>
            <Link href="/classroom" className="glass-dark rounded-2xl px-8 py-4 text-base font-semibold text-white transition hover:bg-white/15">
              Join a lesson
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
