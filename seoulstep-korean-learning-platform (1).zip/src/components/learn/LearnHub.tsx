"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ALL_LESSONS, PATHS, type Lesson } from "@/lib/lessons";

/* ---------- Local, privacy-friendly progress store (stays on this device) ---------- */

type CardState = { box: number; due: number };
type Store = {
  completed: Record<string, { score: number; at: number }>;
  cards: Record<string, CardState>;
  last?: { lessonId: string; step: "cards" | "quiz" };
};

const KEY = "seoulstep:progress:v1";
const EMPTY: Store = { completed: {}, cards: {} };
// Leitner boxes: review intervals in days for box 0..4
const INTERVALS = [0, 1, 3, 7, 14];
const DAY = 86_400_000;

function load(): Store {
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? { ...EMPTY, ...(JSON.parse(raw) as Store) } : EMPTY;
  } catch {
    return EMPTY;
  }
}

function save(s: Store) {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* storage unavailable (private mode): progress simply won't persist */
  }
}

const cardKey = (lessonId: string, i: number) => `${lessonId}#${i}`;

export function LearnHub() {
  const [store, setStore] = useState<Store>(EMPTY);
  const [ready, setReady] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [step, setStep] = useState<"cards" | "quiz">("cards");

  useEffect(() => {
    const s = load();
    setStore(s);
    setReady(true);
    if (s.last) {
      setActiveId(s.last.lessonId);
      setStep(s.last.step);
    }
  }, []);

  const update = (fn: (s: Store) => Store) => {
    setStore((prev) => {
      const next = fn(prev);
      save(next);
      return next;
    });
  };

  const active = ALL_LESSONS.find((l) => l.id === activeId) ?? null;
  const lastLesson = store.last ? ALL_LESSONS.find((l) => l.id === store.last?.lessonId) : undefined;

  const dueCount = useMemo(() => {
    const now = Date.now();
    let n = 0;
    for (const lesson of ALL_LESSONS) {
      lesson.cards.forEach((_, i) => {
        const c = store.cards[cardKey(lesson.id, i)];
        if (!c || c.due <= now) n++;
      });
    }
    return n;
  }, [store.cards]);

  const completedCount = Object.keys(store.completed).length;

  const openLesson = (id: string, s: "cards" | "quiz" = "cards") => {
    setActiveId(id);
    setStep(s);
    update((prev) => ({ ...prev, last: { lessonId: id, step: s } }));
    requestAnimationFrame(() => document.getElementById("lesson-player")?.scrollIntoView({ behavior: "smooth", block: "start" }));
  };

  if (!ready) {
    return <div className="mx-auto max-w-6xl px-5 py-20 text-slate-500" role="status">Loading your progress…</div>;
  }

  return (
    <div className="mx-auto max-w-6xl px-5 pb-24 pt-8">
      {/* Summary + resume */}
      <section aria-labelledby="progress-title" className="grid gap-5 lg:grid-cols-[1.3fr_1fr]">
        <div className="rounded-3xl bg-ink p-6 text-white sm:p-8">
          <p className="text-sm font-semibold text-mint">Your progress on this device</p>
          <h2 id="progress-title" className="mt-2 text-2xl font-bold sm:text-3xl">
            {completedCount === 0 ? "Let’s take your first step." : `${completedCount} of ${ALL_LESSONS.length} lessons complete`}
          </h2>
          <div className="mt-5 h-2 overflow-hidden rounded-full bg-white/15" role="progressbar" aria-label="Lessons completed" aria-valuemin={0} aria-valuemax={ALL_LESSONS.length} aria-valuenow={completedCount}>
            <div className="h-full rounded-full bg-gradient-to-r from-mint to-brand transition-all duration-700" style={{ width: `${(completedCount / ALL_LESSONS.length) * 100}%` }} />
          </div>
          <dl className="mt-6 grid grid-cols-2 gap-4 text-sm sm:max-w-md">
            <div><dt className="text-indigo-200">Cards due now</dt><dd className="text-2xl font-bold">{dueCount}</dd></div>
            <div><dt className="text-indigo-200">Badges earned</dt><dd className="text-2xl font-bold">🏅 {completedCount}</dd></div>
          </dl>
        </div>

        <div className="glass flex flex-col justify-between rounded-3xl p-6 sm:p-8">
          <div>
            <p className="text-sm font-semibold text-brand">Resume where you left off</p>
            {lastLesson ? (
              <>
                <p className="mt-2 text-xl font-bold text-ink">{lastLesson.title}</p>
                <p className="text-sm text-slate-600">{lastLesson.pathName} · {store.last?.step === "quiz" ? "Quiz" : "Flashcards"}</p>
              </>
            ) : (
              <p className="mt-2 text-slate-600">Nothing yet. Pick a path below and your place is saved automatically.</p>
            )}
          </div>
          {lastLesson && (
            <button type="button" onClick={() => openLesson(lastLesson.id, store.last?.step)} className="btn-primary mt-6 rounded-2xl px-5 py-3.5 font-semibold">
              Resume lesson
            </button>
          )}
        </div>
      </section>

      {/* Paths */}
      <section aria-labelledby="paths-title" className="mt-12">
        <div className="flex items-end justify-between gap-4">
          <h2 id="paths-title" className="text-2xl font-bold text-ink">Learning paths</h2>
          <p className="hidden text-sm text-slate-500 sm:block">Start with Hangul if you are new.</p>
        </div>
        <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {PATHS.map((p) => {
            const done = p.lessons.filter((l) => store.completed[l.id]).length;
            return (
              <li key={p.id}>
                <div className="group h-full rounded-3xl bg-white p-6 ring-1 ring-slate-200 transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-500/10">
                  <div className="flex items-center gap-3">
                    <span aria-hidden="true" className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-brand to-brand-2 text-xl font-bold text-white transition-transform duration-500 group-hover:rotate-6">{p.emoji}</span>
                    <div>
                      <h3 className="font-semibold text-ink">{p.name}</h3>
                      <p className="text-xs text-slate-500">{done} of {p.lessons.length} complete</p>
                    </div>
                  </div>
                  <p className="mt-4 text-sm text-slate-600">{p.blurb}</p>
                  <ul className="mt-4 space-y-2">
                    {p.lessons.map((l) => (
                      <li key={l.id}>
                        <button
                          type="button"
                          onClick={() => openLesson(l.id)}
                          className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-sm font-medium text-ink ring-1 ring-slate-200 transition hover:bg-slate-50 hover:ring-brand"
                          aria-label={`Open lesson: ${l.title}${store.completed[l.id] ? " (completed)" : ""}`}
                        >
                          {l.title}
                          <span aria-hidden="true">{store.completed[l.id] ? "🏅" : "→"}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              </li>
            );
          })}
        </ul>
      </section>

      {/* Player */}
      <section id="lesson-player" aria-live="polite" className="mt-12 scroll-mt-24">
        {active ? (
          <LessonPlayer
            key={active.id}
            lesson={active}
            step={step}
            setStep={(s) => {
              setStep(s);
              update((prev) => ({ ...prev, last: { lessonId: active.id, step: s } }));
            }}
            store={store}
            update={update}
          />
        ) : (
          <div className="rounded-3xl border-2 border-dashed border-slate-300 bg-white/60 p-10 text-center text-slate-600">
            <p className="text-lg font-semibold text-ink">Choose a lesson to begin</p>
            <p className="mt-2 text-sm">Lessons include flashcards with audio and a short quiz. Finish the quiz with at least 2 of 3 correct for your badge.</p>
          </div>
        )}
      </section>

      <p className="mt-12 text-center text-sm text-slate-500">
        Have an invitation from your instructor? <Link href="/classroom" className="font-semibold text-brand underline-offset-4 hover:underline">Join a live lesson</Link>.
      </p>
    </div>
  );
}

function speak(text: string) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return false;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "ko-KR";
  u.rate = 0.85;
  window.speechSynthesis.speak(u);
  return true;
}

function LessonPlayer({
  lesson,
  step,
  setStep,
  store,
  update,
}: {
  lesson: Lesson & { pathName: string };
  step: "cards" | "quiz";
  setStep: (s: "cards" | "quiz") => void;
  store: Store;
  update: (fn: (s: Store) => Store) => void;
}) {
  return (
    <article aria-labelledby="player-title" className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 sm:p-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-sm font-semibold text-brand">{lesson.pathName}</p>
          <h2 id="player-title" className="text-2xl font-bold text-ink">{lesson.title}</h2>
          <p className="text-sm text-slate-600">Goal: {lesson.goal}</p>
        </div>
        <div role="tablist" aria-label="Lesson steps" className="inline-flex rounded-2xl bg-slate-100 p-1">
          {(["cards", "quiz"] as const).map((s) => (
            <button
              key={s}
              role="tab"
              type="button"
              aria-selected={step === s}
              onClick={() => setStep(s)}
              className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${step === s ? "bg-white text-ink shadow" : "text-slate-600 hover:text-ink"}`}
            >
              {s === "cards" ? "Flashcards" : "Quiz"}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-8">
        {step === "cards" ? (
          <Flashcards lesson={lesson} store={store} update={update} />
        ) : (
          <Quiz lesson={lesson} store={store} update={update} />
        )}
      </div>
    </article>
  );
}

function Flashcards({ lesson, store, update }: { lesson: Lesson; store: Store; update: (fn: (s: Store) => Store) => void }) {
  const [index, setIndex] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [voiceOk, setVoiceOk] = useState(true);
  const card = lesson.cards[index];
  const total = lesson.cards.length;

  const grade = (good: boolean) => {
    const key = cardKey(lesson.id, index);
    const prev = store.cards[key]?.box ?? 0;
    const box = good ? Math.min(prev + 1, INTERVALS.length - 1) : 0;
    const due = Date.now() + INTERVALS[box] * DAY;
    update((s) => ({ ...s, cards: { ...s.cards, [key]: { box, due } } }));
    setRevealed(false);
    setIndex((i) => (i + 1) % total);
  };

  return (
    <div>
      <div className="flex items-center justify-between text-sm text-slate-600">
        <span aria-live="polite">Card {index + 1} of {total}</span>
        <span className="text-xs">Reviews: cards you miss return sooner</span>
      </div>

      <div className="mt-4 grid min-h-64 place-items-center rounded-3xl bg-gradient-to-br from-[#eef1ff] via-white to-[#e9fbf8] p-6 text-center ring-1 ring-slate-200 [perspective:1000px] sm:p-10">
        <div className="w-full">
          <p className="text-xs font-semibold uppercase tracking-widest text-slate-500">{revealed ? "Meaning" : "Prompt"}</p>
          <p lang={revealed ? "en" : "ko"} className="mt-3 text-balance text-4xl font-bold text-ink sm:text-5xl" key={`${index}-${revealed}`}>
            <span className="inline-block animate-[fadeUp_0.5s_ease]">{revealed ? card.back : card.front}</span>
          </p>
          {!revealed && card.hint && <p className="mt-3 text-sm text-slate-500">{card.hint}</p>}
          {revealed && card.hint && <p className="mt-3 text-sm text-slate-500">{card.hint}</p>}
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        {!revealed ? (
          <button type="button" onClick={() => setRevealed(true)} className="btn-primary rounded-2xl px-6 py-3 font-semibold">
            Show meaning
          </button>
        ) : (
          <>
            <button type="button" onClick={() => grade(false)} className="rounded-2xl bg-rose-50 px-5 py-3 font-semibold text-rose-700 ring-1 ring-rose-200 hover:bg-rose-100">
              Didn’t know
            </button>
            <button type="button" onClick={() => grade(true)} className="rounded-2xl bg-emerald-50 px-5 py-3 font-semibold text-emerald-800 ring-1 ring-emerald-200 hover:bg-emerald-100">
              Knew it
            </button>
          </>
        )}
        {card.say && (
          <button
            type="button"
            onClick={() => setVoiceOk(speak(card.say!))}
            className="ml-auto rounded-2xl px-4 py-3 text-sm font-semibold text-brand ring-1 ring-brand/30 hover:bg-brand/5"
            aria-label={`Listen to ${card.say}`}
          >
            🔊 Listen
          </button>
        )}
      </div>
      {!voiceOk && <p role="status" className="mt-3 text-sm text-slate-500">Audio isn’t available in this browser. The text above still works.</p>}
    </div>
  );
}

function Quiz({ lesson, store, update }: { lesson: Lesson; store: Store; update: (fn: (s: Store) => Store) => void }) {
  const [answers, setAnswers] = useState<(number | null)[]>(() => lesson.quiz.map(() => null));
  const [submitted, setSubmitted] = useState(false);
  const score = answers.reduce<number>((n, a, i) => (a === lesson.quiz[i].answer ? n + 1 : n), 0);
  const passed = score >= Math.ceil((lesson.quiz.length * 2) / 3);

  const submit = () => {
    setSubmitted(true);
    if (passed) update((s) => ({ ...s, completed: { ...s.completed, [lesson.id]: { score, at: Date.now() } } }));
  };

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (answers.some((a) => a === null)) return;
        submit();
      }}
      className="space-y-6"
    >
      {lesson.quiz.map((q, qi) => (
        <fieldset key={q.prompt} className="rounded-2xl bg-slate-50 p-5 ring-1 ring-slate-200">
          <legend className="px-1 font-semibold text-ink">
            {qi + 1}. {q.prompt}
          </legend>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            {q.options.map((opt, oi) => {
              const selected = answers[qi] === oi;
              const correct = submitted && oi === q.answer;
              const wrong = submitted && selected && oi !== q.answer;
              return (
                <label
                  key={opt}
                  className={`flex cursor-pointer items-center gap-3 rounded-xl border px-4 py-3 transition ${
                    correct ? "border-emerald-400 bg-emerald-50" : wrong ? "border-rose-400 bg-rose-50" : selected ? "border-brand bg-brand/5" : "border-slate-200 bg-white hover:border-brand/50"
                  } ${submitted ? "cursor-default" : ""}`}
                >
                  <input
                    type="radio"
                    name={`q-${qi}`}
                    value={oi}
                    checked={selected}
                    disabled={submitted}
                    onChange={() => setAnswers((a) => a.map((v, i) => (i === qi ? oi : v)))}
                    className="h-4 w-4 accent-brand"
                  />
                  <span lang="ko" className="font-medium text-ink">{opt}</span>
                </label>
              );
            })}
          </div>
          {submitted && <p className="mt-3 text-sm text-slate-700">{answers[qi] === q.answer ? "✓ " : "Not quite. "}{q.explain}</p>}
        </fieldset>
      ))}

      {!submitted ? (
        <div className="flex flex-wrap items-center gap-3">
          <button type="submit" disabled={answers.some((a) => a === null)} className="btn-primary rounded-2xl px-6 py-3 font-semibold disabled:cursor-not-allowed disabled:opacity-50 disabled:shadow-none disabled:hover:translate-y-0">
            Check answers
          </button>
          {answers.some((a) => a === null) && <p className="text-sm text-slate-500">Answer every question to check.</p>}
        </div>
      ) : (
        <div role="status" className={`rounded-2xl p-5 ${passed ? "bg-emerald-50 ring-1 ring-emerald-200" : "bg-amber-50 ring-1 ring-amber-200"}`}>
          <p className="text-lg font-bold text-ink">
            {passed ? "🏅 Lesson complete!" : "Almost there."} You scored {score} of {lesson.quiz.length}.
          </p>
          <p className="mt-1 text-sm text-slate-700">
            {passed ? "Your badge is saved on this device." : "Review the flashcards and try again. Two of three correct earns the badge."}
          </p>
          {!passed && (
            <button type="button" onClick={() => { setAnswers(lesson.quiz.map(() => null)); setSubmitted(false); }} className="mt-4 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-ink ring-1 ring-slate-300 hover:ring-brand">
              Try again
            </button>
          )}
        </div>
      )}
      {store.completed[lesson.id] && !submitted && <p className="text-sm text-emerald-700">🏅 You already earned this badge.</p>}
    </form>
  );
}
