import { pgTable, serial, text, timestamp, integer, uniqueIndex, index } from "drizzle-orm/pg-core";

// Invitation links grant LEARNER access only. There is no role column that could
// ever hold "admin": admin accounts are configured server-side via environment
// variables and are never created from invitations.
export const invitations = pgTable(
  "invitations",
  {
    id: serial("id").primaryKey(),
    tokenHash: text("token_hash").notNull(),
    label: text("label").notNull().default("Lesson invitation"),
    createdBy: text("created_by").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
    useCount: integer("use_count").notNull().default(0),
    lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
  },
  (t) => [uniqueIndex("invitations_token_hash_idx").on(t.tokenHash)],
);

// Append-only audit trail of admin sign-ins, admin actions and classroom access.
export const auditLog = pgTable(
  "audit_log",
  {
    id: serial("id").primaryKey(),
    event: text("event").notNull(),
    actor: text("actor").notNull(),
    detail: text("detail"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("audit_log_created_idx").on(t.createdAt)],
);

// Minimal classroom presence + camera-consent events. No names, no video, no
// recordings. learnerId is a random anonymous id stored in the learner cookie.
export const classroomEvents = pgTable(
  "classroom_events",
  {
    id: serial("id").primaryKey(),
    sessionKey: text("session_key").notNull().default("demo-room"),
    learnerId: text("learner_id").notNull(),
    invitationId: integer("invitation_id"),
    event: text("event").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("classroom_events_learner_idx").on(t.learnerId, t.createdAt)],
);

// Messages sent through the public contact form (site owner reads them from the DB).
export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  topic: text("topic").notNull().default("general"),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
