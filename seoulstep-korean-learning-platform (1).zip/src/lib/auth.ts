import "server-only";
import { createHash, createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";

/*
 * Authentication primitives (no third-party secrets in code).
 *  - Admin: email + scrypt-hashed password + TOTP (RFC 6238) second factor.
 *    Configured via server env vars: ADMIN_EMAIL, ADMIN_PASSWORD_HASH, ADMIN_TOTP_SECRET.
 *    If any is missing, admin sign-in is disabled (fails closed).
 *  - Sessions: HMAC-SHA256 signed, httpOnly, sameSite=strict tokens with a `typ`
 *    claim. Admin tokens (typ=admin) and learner tokens (typ=learner) are
 *    mutually exclusive, so an invitation can never produce admin access.
 */

export const ADMIN_COOKIE = "ss_admin";
export const LEARNER_COOKIE = "ss_learner";
export const ADMIN_TTL_SEC = 60 * 60 * 4; // 4 hours
export const LEARNER_TTL_SEC = 60 * 60 * 12; // 12 hours

function secret(): string | null {
  const s = process.env.SESSION_SECRET;
  return s && s.length >= 32 ? s : null;
}

const b64u = (buf: Buffer | string) => Buffer.from(buf).toString("base64url");

export function signToken(payload: Record<string, unknown>): string | null {
  const key = secret();
  if (!key) return null;
  const body = b64u(JSON.stringify(payload));
  const sig = createHmac("sha256", key).update(body).digest("base64url");
  return `${body}.${sig}`;
}

export function verifyToken<T extends { exp: number; typ: string }>(token: string | undefined, typ: string): T | null {
  const key = secret();
  if (!key || !token) return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const expected = createHmac("sha256", key).update(body).digest();
  const given = Buffer.from(sig, "base64url");
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return null;
  try {
    const data = JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as T;
    if (data.typ !== typ) return null;
    if (typeof data.exp !== "number" || data.exp * 1000 < Date.now()) return null;
    return data;
  } catch {
    return null;
  }
}

export function sha256(input: string): string {
  return createHash("sha256").update(input).digest("hex");
}

export function verifyPasswordHash(password: string, stored: string | undefined): boolean {
  // Format: scrypt$N$r$p$saltB64u$hashB64u
  if (!stored) return false;
  const parts = stored.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  const [, n, r, p, salt, hash] = parts;
  const expected = Buffer.from(hash, "base64url");
  const actual = scryptSync(password, Buffer.from(salt, "base64url"), expected.length, {
    N: Number(n),
    r: Number(r),
    p: Number(p),
    maxmem: 64 * 1024 * 1024,
  });
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

function base32Decode(input: string): Buffer {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const clean = input.replace(/=+$/g, "").replace(/\s+/g, "").toUpperCase();
  let bits = 0;
  let value = 0;
  const out: number[] = [];
  for (const ch of clean) {
    const idx = alphabet.indexOf(ch);
    if (idx < 0) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

export function totpAt(secretB32: string, timeMs: number): string {
  const counter = Math.floor(timeMs / 1000 / 30);
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64BE(BigInt(counter));
  const hmac = createHmac("sha1", base32Decode(secretB32)).update(buf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code = ((hmac[offset] & 0x7f) << 24) | (hmac[offset + 1] << 16) | (hmac[offset + 2] << 8) | hmac[offset + 3];
  return String(code % 1_000_000).padStart(6, "0");
}

export function verifyTotp(secretB32: string | undefined, code: string): boolean {
  if (!secretB32 || !/^\d{6}$/.test(code)) return false;
  const now = Date.now();
  // Accept the previous, current and next 30-second window for clock drift.
  return [-1, 0, 1].some((w) => {
    const expected = totpAt(secretB32, now + w * 30_000);
    return expected.length === code.length && timingSafeEqual(Buffer.from(expected), Buffer.from(code));
  });
}

export function adminConfigured(): boolean {
  return Boolean(secret() && process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD_HASH && process.env.ADMIN_TOTP_SECRET);
}

export function emailMatches(input: string): boolean {
  const configured = process.env.ADMIN_EMAIL ?? "";
  if (!configured) return false;
  return timingSafeEqual(createHash("sha256").update(input.trim().toLowerCase()).digest(), createHash("sha256").update(configured.trim().toLowerCase()).digest());
}

export function newId(): string {
  return randomBytes(16).toString("base64url");
}

export type AdminSession = { sub: string; typ: "admin"; exp: number; mfa: true };
export type LearnerToken = { lid: string; inv: number; typ: "learner"; exp: number };

/** Returns the admin session only when a valid, MFA-verified admin cookie is present. */
export async function getAdminSession(): Promise<AdminSession | null> {
  const jar = await cookies();
  const data = verifyToken<AdminSession>(jar.get(ADMIN_COOKIE)?.value, "admin");
  if (!data || data.mfa !== true) return null;
  return data;
}

export async function getLearnerToken(): Promise<LearnerToken | null> {
  const jar = await cookies();
  return verifyToken<LearnerToken>(jar.get(LEARNER_COOKIE)?.value, "learner");
}

export function cookieOptions(maxAge: number) {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict" as const,
    path: "/",
    maxAge,
  };
}

// Simple in-memory fixed-window rate limiter for admin sign-in attempts.
const attempts = new Map<string, { count: number; reset: number }>();
export function rateLimit(key: string, limit = 5, windowMs = 15 * 60_000): boolean {
  const now = Date.now();
  const entry = attempts.get(key);
  if (!entry || entry.reset < now) {
    attempts.set(key, { count: 1, reset: now + windowMs });
    return true;
  }
  entry.count += 1;
  return entry.count <= limit;
}
export function clearRateLimit(key: string) {
  attempts.delete(key);
}
