import "server-only";
import { randomBytes } from "node:crypto";
import { and, desc, eq, gt, isNull, sql } from "drizzle-orm";
import { db } from "@/db";
import { auditLog, classroomEvents, invitations } from "@/db/schema";
import { sha256, getLearnerToken } from "@/lib/auth";

export const DEMO_SESSION = "demo-room";

export const CLASSROOM_EVENTS = ["joined", "camera_consent", "camera_on", "camera_off", "left"] as const;
export type ClassroomEvent = (typeof CLASSROOM_EVENTS)[number];

export async function writeAudit(event: string, actor: string, detail?: string) {
  await db.insert(auditLog).values({ event, actor, detail: detail?.slice(0, 500) ?? null });
}

/** Creates a learner-only invitation. The raw token is returned once and never stored. */
export async function createInvitation(label: string, hours: number, createdBy: string) {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + hours * 3600_000);
  const [row] = await db
    .insert(invitations)
    .values({ tokenHash: sha256(token), label: label.slice(0, 120) || "Lesson invitation", createdBy, expiresAt })
    .returning({ id: invitations.id, expiresAt: invitations.expiresAt });
  return { token, ...row };
}

/** Returns the invitation only if it is not revoked and not expired. */
export async function findActiveInvitation(token: string) {
  if (!token || token.length < 20 || token.length > 200) return null;
  const [row] = await db
    .select()
    .from(invitations)
    .where(
      and(
        eq(invitations.tokenHash, sha256(token)),
        isNull(invitations.revokedAt),
        gt(invitations.expiresAt, new Date()),
      ),
    )
    .limit(1);
  return row ?? null;
}

export async function listInvitations() {
  return db.select().from(invitations).orderBy(desc(invitations.createdAt)).limit(50);
}

export async function revokeInvitation(id: number) {
  const [row] = await db
    .update(invitations)
    .set({ revokedAt: new Date() })
    .where(and(eq(invitations.id, id), isNull(invitations.revokedAt)))
    .returning({ id: invitations.id });
  return row ?? null;
}

export async function markInvitationUsed(id: number) {
  await db
    .update(invitations)
    .set({ useCount: sql`${invitations.useCount} + 1`, lastUsedAt: new Date() })
    .where(eq(invitations.id, id));
}

/** Learner session is valid only while its invitation is still active (revocation takes effect immediately). */
export async function getActiveLearner() {
  const token = await getLearnerToken();
  if (!token) return null;
  const [inv] = await db
    .select({ id: invitations.id })
    .from(invitations)
    .where(and(eq(invitations.id, token.inv), isNull(invitations.revokedAt), gt(invitations.expiresAt, new Date())))
    .limit(1);
  if (!inv) return null;
  return { learnerId: token.lid, invitationId: inv.id };
}

export async function logClassroomEvent(learnerId: string, invitationId: number | null, event: ClassroomEvent) {
  await db.insert(classroomEvents).values({ sessionKey: DEMO_SESSION, learnerId, invitationId, event });
}

export async function getClassroomSnapshot() {
  // Latest camera-related event per learner seen in the last 30 minutes.
  const rows = await db.execute<{ learner_id: string; event: string; last_seen: Date; joined_at: Date }>(sql`
    select distinct on (learner_id) learner_id, event, created_at as last_seen,
      (select min(created_at) from classroom_events c2 where c2.learner_id = classroom_events.learner_id) as joined_at
    from classroom_events
    where session_key = ${DEMO_SESSION} and created_at > now() - interval '30 minutes'
    order by learner_id, created_at desc
  `);
  const learners = rows.rows.map((r) => ({
    learnerId: r.learner_id.slice(0, 6),
    lastEvent: r.event,
    lastSeen: r.last_seen,
    joinedAt: r.joined_at,
    // Consent state: true only if the learner's latest camera event is camera_on.
    cameraOn: r.event === "camera_on",
    consentGiven: ["camera_consent", "camera_on", "camera_off"].includes(r.event),
  }));
  return learners;
}

export async function getRecentAudit(limit = 40) {
  return db.select().from(auditLog).orderBy(desc(auditLog.createdAt)).limit(limit);
}
