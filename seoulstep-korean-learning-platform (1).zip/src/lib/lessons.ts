// Demo lesson content for the public learning hub. All content is original.

export type Card = { front: string; back: string; hint?: string; say?: string };
export type Question = { prompt: string; options: string[]; answer: number; explain: string };
export type Lesson = {
  id: string;
  title: string;
  goal: string;
  cards: Card[];
  quiz: Question[];
};
export type LearningPath = {
  id: string;
  name: string;
  emoji: string;
  blurb: string;
  lessons: Lesson[];
};

export const PATHS: LearningPath[] = [
  {
    id: "hangul",
    name: "Hangul",
    emoji: "ㅎ",
    blurb: "Read the alphabet in sound-first steps.",
    lessons: [
      {
        id: "hangul-vowels",
        title: "Basic vowels",
        goal: "Recognize and say the first four vowels.",
        cards: [
          { front: "ㅏ", back: "a (as in “father”)", hint: "Mouth open wide", say: "아" },
          { front: "ㅓ", back: "eo (as in “comb” with rounded lips)", hint: "Mouth open, lips relaxed", say: "어" },
          { front: "ㅗ", back: "o (as in “go”)", hint: "Round your lips", say: "오" },
          { front: "ㅜ", back: "u (as in “moon”)", hint: "Lips pushed forward", say: "우" },
        ],
        quiz: [
          { prompt: "Which letter makes the “a” sound?", options: ["ㅏ", "ㅗ", "ㅜ", "ㅓ"], answer: 0, explain: "ㅏ is the open “a” vowel." },
          { prompt: "Which vowel uses rounded lips for “o”?", options: ["ㅓ", "ㅜ", "ㅗ", "ㅏ"], answer: 2, explain: "ㅗ is “o”, with rounded lips." },
          { prompt: "Which letter sounds like “moon”?", options: ["ㅗ", "ㅜ", "ㅓ", "ㅏ"], answer: 1, explain: "ㅜ is “u”, as in moon." },
        ],
      },
    ],
  },
  {
    id: "pronunciation",
    name: "Pronunciation",
    emoji: "🔊",
    blurb: "Hear and shape the sounds that trip learners up.",
    lessons: [
      {
        id: "pron-tense",
        title: "Plain, tense and aspirated",
        goal: "Hear the difference between ㄱ, ㄲ and ㅋ.",
        cards: [
          { front: "가", back: "ga: plain, softer “g”", hint: "Little air, voice starts early", say: "가" },
          { front: "까", back: "kka: tense, tighter “k”", hint: "Tense throat, no air puff", say: "까" },
          { front: "카", back: "ka: strong puff of air", hint: "Hold a hand in front of your mouth", say: "카" },
        ],
        quiz: [
          { prompt: "Which one has a strong puff of air?", options: ["가", "까", "카"], answer: 2, explain: "카 (ka) is aspirated." },
          { prompt: "Which one is the tense sound?", options: ["가", "카", "까"], answer: 2, explain: "까 (kka) is tense." },
        ],
      },
    ],
  },
  {
    id: "vocabulary",
    name: "Vocabulary",
    emoji: "📚",
    blurb: "Everyday words you will actually use.",
    lessons: [
      {
        id: "vocab-greetings",
        title: "Greetings",
        goal: "Greet people politely in three situations.",
        cards: [
          { front: "안녕하세요", back: "Hello (polite)", hint: "An-nyeong-ha-se-yo", say: "안녕하세요" },
          { front: "감사합니다", back: "Thank you (formal)", hint: "Gam-sa-ham-ni-da", say: "감사합니다" },
          { front: "죄송합니다", back: "I'm sorry (formal)", hint: "Joe-song-ham-ni-da", say: "죄송합니다" },
          { front: "잘 가요", back: "Goodbye (to someone leaving)", hint: "Jal ga-yo", say: "잘 가요" },
        ],
        quiz: [
          { prompt: "How do you say “thank you” formally?", options: ["감사합니다", "안녕하세요", "죄송합니다"], answer: 0, explain: "감사합니다 is the formal thank you." },
          { prompt: "Which phrase is a polite hello?", options: ["잘 가요", "안녕하세요", "감사합니다"], answer: 1, explain: "안녕하세요 is a polite greeting." },
        ],
      },
    ],
  },
  {
    id: "grammar",
    name: "Grammar",
    emoji: "🧩",
    blurb: "Sentence patterns, one rule at a time.",
    lessons: [
      {
        id: "grammar-topic",
        title: "Topic marker 은/는",
        goal: "Use 은/는 to introduce a topic.",
        cards: [
          { front: "저는 학생이에요", back: "I am a student. (은/는 marks “I” as the topic)", hint: "Noun + 은/는 (after a consonant: 은)" },
          { front: "오늘은 월요일이에요", back: "Today is Monday.", hint: "After a vowel: 는" },
          { front: "한국어는 재미있어요", back: "Korean is fun.", hint: "Topic + adjective ending -아요/어요" },
        ],
        quiz: [
          { prompt: "Which particle follows 저 (I) in 저___ 학생이에요?", options: ["은", "는", "이", "을"], answer: 1, explain: "저 ends in a vowel, so 는 attaches." },
          { prompt: "Which particle follows 책 (book) when it is the topic and ends in a consonant?", options: ["는", "은", "가", "를"], answer: 1, explain: "책 ends in a consonant, so 은 attaches." },
        ],
      },
    ],
  },
  {
    id: "listening",
    name: "Listening",
    emoji: "👂",
    blurb: "Train your ear with short, clear clips.",
    lessons: [
      {
        id: "listen-cafe",
        title: "At the café",
        goal: "Understand a simple order.",
        cards: [
          { front: "아메리카노 한 잔 주세요", back: "One americano, please.", hint: "한 잔 = one cup", say: "아메리카노 한 잔 주세요" },
          { front: "여기서 드세요?", back: "Will you eat here?", hint: "Staff question", say: "여기서 드세요" },
          { front: "가져갈게요", back: "I'll take it to go.", hint: "Takeout", say: "가져갈게요" },
        ],
        quiz: [
          { prompt: "“한 잔 주세요” most likely means…", options: ["One cup, please", "Two plates, please", "Thank you"], answer: 0, explain: "한 잔 = one cup; 주세요 = please give." },
        ],
      },
    ],
  },
  {
    id: "conversation",
    name: "Conversation",
    emoji: "💬",
    blurb: "Role-play the moments you'll really face.",
    lessons: [
      {
        id: "convo-intro",
        title: "Introducing yourself",
        goal: "Say your name and where you're from.",
        cards: [
          { front: "저는 ___입니다", back: "I am ___. (formal)", hint: "Fill in your name", say: "저는 민지입니다" },
          { front: "저는 ___에서 왔어요", back: "I came from ___.", hint: "Fill in your city or country" },
          { front: "만나서 반갑습니다", back: "Nice to meet you.", hint: "Formal", say: "만나서 반갑습니다" },
        ],
        quiz: [
          { prompt: "Which is a formal way to say “Nice to meet you”?", options: ["만나서 반갑습니다", "잘 가요", "미안해"], answer: 0, explain: "만나서 반갑습니다 is formal and polite." },
        ],
      },
    ],
  },
];

export const ALL_LESSONS = PATHS.flatMap((p) => p.lessons.map((l) => ({ ...l, pathId: p.id, pathName: p.name })));
