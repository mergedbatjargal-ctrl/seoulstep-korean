# SeoulStep — deployment kit

A production-ready Next.js 16 (App Router) + PostgreSQL (Drizzle ORM) app.
Everything needed for a public deployment is in this folder.

---

## 0. What you need

| Requirement | Why |
| --- | --- |
| A hosting account (Vercel is the shortest path, Railway/Render/Fly also work) | To serve the app publicly |
| A hosted PostgreSQL database (Neon, Supabase, Railway, RDS…) | The app persists learning progress |
| Two environment variables + one MFA secret | Admin sign-in is password **and** TOTP |

> **Note on this sandbox:** the code, schema and build are complete and verified, but the
> sandbox has no hosting credentials, so the permanent deployment must be claimed with your
> own account (step 3). Until then the runtime serves the same production build at the
> public preview URL.

---

## 1. Environment variables

Create these in your hosting provider's dashboard (never in the repo):

```bash
# Required — connection string of a hosted Postgres instance
DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DBNAME?sslmode=require

# Strongly recommended for a real deployment
ADMIN_EMAIL=you@yourdomain.com
ADMIN_PASSWORD='a-long-unique-passphrase'
ADMIN_TOTP_SECRET=            # generate with the command in step 2
```

`ADMIN_EMAIL` / `ADMIN_PASSWORD` / `ADMIN_TOTP_SECRET` seed exactly one instructor
account on first boot. If they are absent, the app falls back to a clearly-labelled
sandbox account and exposes a demo TOTP helper on `/admin`. **Always set them in production** —
setting `ADMIN_TOTP_SECRET` automatically disables the demo helper.

No secret is ever referenced in client code; every secret is read from `process.env`
inside route handlers / server components only.

---

## 2. Create the admin MFA secret

```bash
node -e "const c=require('crypto');const A='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';const b=c.randomBytes(20);let bits=0,v=0,o='';for(const x of b){v=(v<<8)|x;bits+=8;while(bits>=5){o+=A[(v>>>(bits-5))&31];bits-=5}}if(bits>0)o+=A[(v<<(5-bits))&31];console.log(o)"
```

Paste the output into `ADMIN_TOTP_SECRET`, then add it to your authenticator app
(1Password / Authy / Google Authenticator) as a manual TOTP entry with issuer `SeoulStep`.

---

## 3. Deploy

### Option A — Vercel (recommended)

1. Create the database first (Neon free tier works) and copy its pooled connection string.
2. Push this project to a GitHub repository.
3. In Vercel: **Add New → Project → Import** the repo.
4. Add the environment variables from step 1 (Production + Preview).
5. Deploy. Vercel detects Next.js automatically — no build overrides needed.
6. Apply the schema once, from your machine:

   ```bash
   DATABASE_URL='postgresql://…' npx drizzle-kit push
   # or, using the generated SQL:
   psql "$DATABASE_URL" -f drizzle/0000_init.sql
   ```

7. Visit `https://<your-project>.vercel.app` and `https://<your-project>.vercel.app/api/health`
   (must return `{"ok":true}`), then sign in at `/admin` with password + TOTP.

### Option B — Railway / Render / Fly / any Docker host

```bash
docker build -t seoulstep .
docker run -p 3000:3000 \
  -e DATABASE_URL='postgresql://…' \
  -e ADMIN_EMAIL='you@yourdomain.com' \
  -e ADMIN_PASSWORD='…' \
  -e ADMIN_TOTP_SECRET='…' \
  seoulstep
```

The container listens on `$PORT` (default 3000) and exposes `/api/health` for platform
health checks. `docker-compose.yml` is included for a local stack with Postgres.

### Option C — run the production build locally

```bash
npm ci
npm run build
npm run start     # http://localhost:3000
```

---

## 4. Post-deploy checklist

- [ ] `GET /api/health` returns `{"ok":true}` over HTTPS
- [ ] Landing page loads on a phone (≤390 px) and desktop
- [ ] "Start learning" creates a learner session and a lesson saves progress
- [ ] `/join/welcome-hangul-2026` opens a lesson **without** any camera prompt
- [ ] Admin sign-in requires both password and a 6-digit code
- [ ] A learner cookie cannot reach `/admin` or `/api/admin/*` (403)
- [ ] Revoking an invitation in the console makes `/join/<token>` stop working
- [ ] Camera stays off until you click *Enable camera* and tick the consent box

---

## 5. HTTPS, media and privacy posture

- Terminate TLS at the host (Vercel/Railway/Render do this automatically). Cookies are set
  `secure` in production.
- Video uses peer-to-peer WebRTC (DTLS-SRTP encrypted). A public STUN server is used for
  NAT traversal; no TURN credentials are required for same-network demos. For learners
  behind strict NATs, add a TURN server to `RTC_CONFIG` in
  `src/components/ClassroomRoom.tsx` and `src/components/AdminDashboard.tsx`.
- Nothing is recorded or persisted. Signalling rows are deleted as they are consumed.
- Learner media may only be addressed to that session's instructor — enforced server-side
  in `src/app/api/classroom/[id]/signal/route.ts`.
