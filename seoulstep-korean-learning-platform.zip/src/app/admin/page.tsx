import type { Metadata } from "next";
import { AdminDashboard } from "@/components/AdminDashboard";
import { AdminLogin } from "@/components/AdminLogin";
import { requireAdmin } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Instructor console · SeoulStep",
  robots: { index: false, follow: false },
};

export default async function AdminPage() {
  let admin: Awaited<ReturnType<typeof requireAdmin>> = null;
  let demo: { email: string; password: string; secret: string } | null = null;

  try {
    const creds = await ensureSeed();
    admin = await requireAdmin();
    // Only surface helper credentials in a sandbox that has no configured secrets.
    if (!admin && !process.env.ADMIN_PASSWORD && !process.env.ADMIN_TOTP_SECRET) {
      demo = { email: creds.email, password: creds.password, secret: creds.totpSecret };
    }
  } catch {
    admin = null;
  }

  const demoMode = !process.env.ADMIN_PASSWORD || !process.env.ADMIN_TOTP_SECRET;

  if (!admin) {
    return (
      <main id="main">
        <AdminLogin demo={demo} />
      </main>
    );
  }

  return (
    <main id="main">
      <AdminDashboard demoMode={demoMode} />
    </main>
  );
}