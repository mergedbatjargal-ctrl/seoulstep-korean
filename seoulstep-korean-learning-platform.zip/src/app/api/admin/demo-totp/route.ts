import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { totpCode } from "@/lib/totp";
import { recordAudit } from "@/lib/audit";
import { clientIp } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

/**
 * Sandbox convenience only. Hard-disabled the moment a real ADMIN_TOTP_SECRET
 * is configured in the environment, and every use is written to the audit log.
 */
export async function GET(req: Request) {
  if (process.env.ADMIN_TOTP_SECRET) {
    return NextResponse.json(
      { ok: false, message: "The demo code helper is disabled on this deployment." },
      { status: 403 },
    );
  }
  try {
    const creds = await ensureSeed();
    const rows = await db.select().from(users).where(eq(users.email, creds.email)).limit(1);
    const secret = rows[0]?.totpSecret;
    if (!secret) return NextResponse.json({ ok: false }, { status: 404 });

    await recordAudit({
      actorLabel: creds.email,
      action: "admin.demo_totp.revealed",
      target: "sandbox-helper",
      severity: "warning",
      ip: clientIp(req.headers),
    });

    return NextResponse.json({ ok: true, code: totpCode(secret) });
  } catch {
    return NextResponse.json({ ok: false }, { status: 500 });
  }
}