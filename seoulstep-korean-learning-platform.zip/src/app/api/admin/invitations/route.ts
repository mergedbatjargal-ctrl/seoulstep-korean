import crypto from "node:crypto";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { classes, invitations } from "@/db/schema";
import { eq } from "drizzle-orm";
import { clientIp, requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { getLesson } from "@/lib/curriculum";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ ok: false }, { status: 403 });
  const rows = await db.select().from(invitations);
  return NextResponse.json({ ok: true, invitations: rows });
}

export async function POST(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ ok: false }, { status: 403 });

  const body = await req.json().catch(() => null);
  const label = typeof body?.label === "string" ? body.label.trim().slice(0, 90) : "";
  const lessonId = typeof body?.lessonId === "string" ? body.lessonId : null;
  const classId = typeof body?.classId === "string" && body.classId ? body.classId : null;
  const hours = Number.isFinite(body?.expiresInHours) ? Number(body.expiresInHours) : 168;
  const maxUses = Number.isFinite(body?.maxUses) ? Number(body.maxUses) : 50;

  if (!label) {
    return NextResponse.json({ ok: false, message: "Give the invitation a label." }, { status: 400 });
  }
  if (lessonId && !getLesson(lessonId)) {
    return NextResponse.json({ ok: false, message: "Unknown lesson." }, { status: 400 });
  }
  if (classId) {
    const c = await db.select().from(classes).where(eq(classes.id, classId)).limit(1);
    if (!c[0]) return NextResponse.json({ ok: false, message: "Unknown class." }, { status: 400 });
  }

  const token = `${label
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 24) || "invite"}-${crypto.randomBytes(4).toString("hex")}`;

  const inserted = await db
    .insert(invitations)
    .values({
      token,
      scope: "learner", // never anything else
      label,
      lessonId,
      classId,
      createdBy: admin.userId,
      maxUses: Math.max(1, Math.min(500, maxUses)),
      expiresAt: new Date(Date.now() + Math.max(1, Math.min(24 * 90, hours)) * 3_600_000),
    })
    .returning();

  await recordAudit({
    actorId: admin.userId,
    actorLabel: admin.email ?? admin.displayName,
    action: "invitation.created",
    target: label,
    severity: "notice",
    ip: clientIp(req.headers),
    meta: { scope: "learner", token, expiresInHours: hours },
  });

  return NextResponse.json({ ok: true, invitation: inserted[0] });
}

export async function PATCH(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ ok: false }, { status: 403 });
  const body = await req.json().catch(() => null);
  const id = typeof body?.id === "string" ? body.id : "";
  const action = body?.action;
  if (!id) return NextResponse.json({ ok: false }, { status: 400 });

  const rows = await db.select().from(invitations).where(eq(invitations.id, id)).limit(1);
  const invite = rows[0];
  if (!invite) return NextResponse.json({ ok: false, message: "Not found." }, { status: 404 });

  if (action === "revoke") {
    await db.update(invitations).set({ revokedAt: new Date() }).where(eq(invitations.id, id));
    await recordAudit({
      actorId: admin.userId,
      actorLabel: admin.email ?? admin.displayName,
      action: "invitation.revoked",
      target: invite.label,
      severity: "warning",
      ip: clientIp(req.headers),
    });
  } else if (action === "restore") {
    await db
      .update(invitations)
      .set({
        revokedAt: null,
        expiresAt: new Date(Date.now() + 7 * 86_400_000),
      })
      .where(eq(invitations.id, id));
    await recordAudit({
      actorId: admin.userId,
      actorLabel: admin.email ?? admin.displayName,
      action: "invitation.restored",
      target: invite.label,
      severity: "notice",
      ip: clientIp(req.headers),
    });
  } else {
    return NextResponse.json({ ok: false, message: "Unknown action." }, { status: 400 });
  }

  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ ok: false }, { status: 403 });
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ ok: false }, { status: 400 });
  const rows = await db.select().from(invitations).where(eq(invitations.id, id)).limit(1);
  await db.delete(invitations).where(eq(invitations.id, id));
  await recordAudit({
    actorId: admin.userId,
    actorLabel: admin.email ?? admin.displayName,
    action: "invitation.deleted",
    target: rows[0]?.label ?? id,
    severity: "warning",
    ip: clientIp(req.headers),
  });
  return NextResponse.json({ ok: true });
}