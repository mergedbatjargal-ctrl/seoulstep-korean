import { NextResponse } from "next/server";
import { db } from "@/db";
import { attendance, auditLog, classes, invitations, users } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { clientIp, requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const admin = await requireAdmin();
  if (!admin) {
    return NextResponse.json(
      { ok: false, message: "Instructor sign-in with MFA is required." },
      { status: 403 },
    );
  }

  const [allClasses, attendanceRows, logs, invites] = await Promise.all([
    db.select().from(classes).orderBy(desc(classes.startsAt)),
    db.select().from(attendance).orderBy(desc(attendance.joinedAt)),
    db.select().from(auditLog).orderBy(desc(auditLog.createdAt)).limit(60),
    db.select().from(invitations).orderBy(desc(invitations.createdAt)),
  ]);

  const active = attendanceRows.filter((a) => !a.leftAt);

  await recordAudit({
    actorId: admin.userId,
    actorLabel: admin.email ?? admin.displayName,
    action: "admin.dashboard.viewed",
    target: "overview",
    ip: clientIp(req.headers),
  });

  return NextResponse.json({
    ok: true,
    instructor: { id: admin.userId, name: admin.displayName, email: admin.email },
    classes: allClasses.map((c) => {
      const roster = attendanceRows.filter((a) => a.classId === c.id);
      const live = roster.filter((a) => !a.leftAt);
      return {
        id: c.id,
        code: c.code,
        title: c.title,
        titleKo: c.titleKo,
        status: c.status,
        startsAt: c.startsAt.toISOString(),
        lessonId: c.lessonId,
        joined: live.length,
        totalEver: roster.length,
        camerasOn: live.filter((a) => a.cameraOn).length,
        consented: roster.filter((a) => a.cameraConsentAt).length,
      };
    }),
    attendance: attendanceRows.slice(0, 40).map((a) => ({
      id: a.id,
      classId: a.classId,
      userId: a.userId,
      displayName: a.displayName,
      joinedAt: a.joinedAt.toISOString(),
      leftAt: a.leftAt?.toISOString() ?? null,
      cameraOn: a.cameraOn,
      cameraConsentAt: a.cameraConsentAt?.toISOString() ?? null,
      handRaised: a.handRaised,
    })),
    liveStreams: active
      .filter((a) => a.cameraOn)
      .map((a) => ({
        userId: a.userId,
        classId: a.classId,
        displayName: a.displayName,
        consentedAt: a.cameraConsentAt?.toISOString() ?? null,
      })),
    invitations: invites.map((i) => ({
      id: i.id,
      token: i.token,
      label: i.label,
      lessonId: i.lessonId,
      classId: i.classId,
      scope: i.scope,
      uses: i.uses,
      maxUses: i.maxUses,
      expiresAt: i.expiresAt?.toISOString() ?? null,
      revokedAt: i.revokedAt?.toISOString() ?? null,
      createdAt: i.createdAt.toISOString(),
    })),
    audit: logs.map((l) => ({
      id: l.id,
      actorLabel: l.actorLabel,
      action: l.action,
      target: l.target,
      severity: l.severity,
      ip: l.ip,
      createdAt: l.createdAt.toISOString(),
    })),
    totals: {
      learners: (await db.select({ id: users.id }).from(users).where(eq(users.role, "learner")))
        .length,
      liveNow: active.length,
      camerasLive: active.filter((a) => a.cameraOn).length,
    },
  });
}