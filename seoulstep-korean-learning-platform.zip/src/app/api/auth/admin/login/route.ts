import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ADMIN_COOKIE, clientIp, createSession, verifyPassword } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";
import { recordAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

const attempts = new Map<string, { count: number; first: number }>();

function throttled(key: string) {
  const now = Date.now();
  const entry = attempts.get(key);
  if (!entry || now - entry.first > 10 * 60_000) {
    attempts.set(key, { count: 1, first: now });
    return false;
  }
  entry.count += 1;
  return entry.count > 8;
}

export async function POST(req: Request) {
  const ip = clientIp(req.headers);
  try {
    await ensureSeed();

    if (throttled(ip)) {
      await recordAudit({
        actorLabel: ip,
        action: "admin.signin.throttled",
        severity: "warning",
        ip,
      });
      return NextResponse.json(
        { ok: false, message: "Too many attempts. Wait ten minutes and try again." },
        { status: 429 },
      );
    }

    const body = await req.json().catch(() => null);
    const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
    const password = typeof body?.password === "string" ? body.password : "";
    if (!email || !password) {
      return NextResponse.json(
        { ok: false, message: "Enter your instructor email and password." },
        { status: 400 },
      );
    }

    const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
    const user = rows[0];
    const valid =
      user && user.role === "instructor" && verifyPassword(password, user.passwordHash);

    if (!valid || !user) {
      await recordAudit({
        actorLabel: email || ip,
        action: "admin.signin.failed",
        target: "password",
        severity: "warning",
        ip,
      });
      return NextResponse.json(
        { ok: false, message: "Those credentials don't match an instructor account." },
        { status: 401 },
      );
    }

    await createSession(user.id, {
      cookieName: ADMIN_COOKIE,
      role: "instructor",
      mfaPending: true,
      ip,
      userAgent: req.headers.get("user-agent"),
      ttlMs: 1000 * 60 * 30,
    });

    await recordAudit({
      actorId: user.id,
      actorLabel: email,
      action: "admin.signin.password_ok",
      target: "mfa-challenge-issued",
      severity: "notice",
      ip,
    });

    return NextResponse.json({ ok: true, needsMfa: true });
  } catch (err) {
    console.error("admin login error", err);
    return NextResponse.json(
      { ok: false, message: "Sign-in is temporarily unavailable. Try again shortly." },
      { status: 500 },
    );
  }
}