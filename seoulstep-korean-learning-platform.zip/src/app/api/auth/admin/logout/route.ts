import { NextResponse } from "next/server";
import { ADMIN_COOKIE, clientIp, destroySession, readSession } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const session = await readSession(ADMIN_COOKIE);
  await destroySession(ADMIN_COOKIE);
  if (session) {
    await recordAudit({
      actorId: session.userId,
      actorLabel: session.email ?? session.displayName,
      action: "admin.signout",
      severity: "info",
      ip: clientIp(req.headers),
    });
  }
  return NextResponse.json({ ok: true });
}