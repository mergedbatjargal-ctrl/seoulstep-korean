import { NextResponse } from "next/server";
import { db } from "@/db";
import { authSessions, users } from "@/db/schema";
import { and, eq, gt } from "drizzle-orm";
import { ADMIN_COOKIE, clientIp, hashToken, promoteSessionToVerified } from "@/lib/auth";
import { verifyTotp } from "@/lib/totp";
import { recordAudit } from "@/lib/audit";
import { cookies } from "next/headers";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const ip = clientIp(req.headers);
  try {
    const jar = await cookies();
    const token = jar.get(ADMIN_COOKIE)?.value;
    if (!token) {
      return NextResponse.json(
        { ok: false, message: "Your sign-in attempt expired. Start again." },
        { status: 401 },
      );
    }

    const rows = await db
      .select({
        sessionId: authSessions.id,
        userId: users.id,
        email: users.email,
        role: users.role,
        totpSecret: users.totpSecret,
        mfaPending: authSessions.mfaPending,
      })
      .from(authSessions)
      .innerJoin(users, eq(users.id, authSessions.userId))
      .where(
        and(eq(authSessions.tokenHash, hashToken(token)), gt(authSessions.expiresAt, new Date())),
      )
      .limit(1);

    const row = rows[0];
    if (!row || row.role !== "instructor") {
      return NextResponse.json({ ok: false, message: "Not authorised." }, { status: 403 });
    }

    const body = await req.json().catch(() => null);
    const code = typeof body?.code === "string" ? body.code : "";
    if (!row.totpSecret || !verifyTotp(row.totpSecret, code)) {
      await recordAudit({
        actorId: row.userId,
        actorLabel: row.email ?? row.userId,
        action: "admin.signin.mfa_failed",
        target: "totp",
        severity: "warning",
        ip,
      });
      return NextResponse.json(
        { ok: false, message: "That one-time code isn't right. Codes refresh every 30 seconds." },
        { status: 401 },
      );
    }

    await promoteSessionToVerified(ADMIN_COOKIE);
    await recordAudit({
      actorId: row.userId,
      actorLabel: row.email ?? row.userId,
      action: "admin.signin.success",
      target: "dashboard",
      severity: "notice",
      ip,
      meta: { mfa: "totp" },
    });

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("admin mfa error", err);
    return NextResponse.json(
      { ok: false, message: "Verification is temporarily unavailable." },
      { status: 500 },
    );
  }
}