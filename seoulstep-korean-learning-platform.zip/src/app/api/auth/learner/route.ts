import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  LEARNER_COOKIE,
  clientIp,
  createSession,
  destroySession,
  requireLearner,
} from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

const ADJECTIVES = ["푸른", "고요한", "빛나는", "따뜻한", "새벽", "달빛", "구름", "바람"];
const NOUNS = ["호랑이", "까치", "매화", "소나무", "학", "달", "별", "강"];

function randomName() {
  const a = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
  const n = NOUNS[Math.floor(Math.random() * NOUNS.length)];
  return `${a} ${n} · ${Math.floor(100 + Math.random() * 899)}`;
}

export async function GET() {
  const session = await requireLearner();
  if (!session) return NextResponse.json({ ok: false }, { status: 401 });
  return NextResponse.json({
    ok: true,
    learner: { id: session.userId, displayName: session.displayName },
  });
}

/** Creates an anonymous learner identity. Stores a display name only — no email required. */
export async function POST(req: Request) {
  try {
    await ensureSeed();
    const existing = await requireLearner();
    if (existing) {
      return NextResponse.json({
        ok: true,
        learner: { id: existing.userId, displayName: existing.displayName },
        created: false,
      });
    }

    let requested: string | undefined;
    try {
      const body = await req.json();
      if (typeof body?.displayName === "string") requested = body.displayName.trim();
    } catch {
      /* no body is fine */
    }

    const displayName = (requested && requested.slice(0, 48)) || randomName();
    const inserted = await db
      .insert(users)
      .values({ displayName, role: "learner" })
      .returning({ id: users.id, displayName: users.displayName });

    const learner = inserted[0];
    await createSession(learner.id, {
      cookieName: LEARNER_COOKIE,
      role: "learner",
      ip: clientIp(req.headers),
      userAgent: req.headers.get("user-agent"),
      ttlMs: 1000 * 60 * 60 * 24 * 90,
    });

    return NextResponse.json({ ok: true, learner, created: true });
  } catch (err) {
    console.error("learner session error", err);
    return NextResponse.json(
      { ok: false, message: "We couldn't start your session. Please try again." },
      { status: 500 },
    );
  }
}

export async function PATCH(req: Request) {
  const session = await requireLearner();
  if (!session) return NextResponse.json({ ok: false }, { status: 401 });
  const body = await req.json().catch(() => null);
  const name = typeof body?.displayName === "string" ? body.displayName.trim().slice(0, 48) : "";
  if (!name) {
    return NextResponse.json({ ok: false, message: "Enter a display name." }, { status: 400 });
  }
  await db.update(users).set({ displayName: name }).where(eq(users.id, session.userId));
  return NextResponse.json({ ok: true, displayName: name });
}

export async function DELETE() {
  await destroySession(LEARNER_COOKIE);
  return NextResponse.json({ ok: true });
}