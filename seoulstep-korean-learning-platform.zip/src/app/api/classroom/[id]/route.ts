import { NextResponse } from "next/server";
import { db } from "@/db";
import { attendance, classes, signals } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { clientIp, requireAdmin, requireLearner } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

type Body = {
  action?: "join" | "leave" | "camera" | "mic" | "hand";
  on?: boolean;
  /** Set true only when the learner explicitly pressed "Enable camera". */
  consent?: boolean;
};

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const cls = await db.select().from(classes).where(eq(classes.id, id)).limit(1);
  if (!cls[0]) {
    return NextResponse.json({ ok: false, message: "Session not found." }, { status: 404 });
  }
  const roster = await db.select().from(attendance).where(eq(attendance.classId, id));
  const active = roster.filter((a) => !a.leftAt);

  return NextResponse.json({
    ok: true,
    class: {
      id: cls[0].id,
      code: cls[0].code,
      title: cls[0].title,
      titleKo: cls[0].titleKo,
      status: cls[0].status,
      startsAt: cls[0].startsAt.toISOString(),
      lessonId: cls[0].lessonId,
      instructorId: cls[0].instructorId,
    },
    present: active.length,
    camerasOn: active.filter((a) => a.cameraOn).length,
    roster: active.map((a) => ({
      userId: a.userId,
      displayName: a.displayName,
      cameraOn: a.cameraOn,
      handRaised: a.handRaised,
      joinedAt: a.joinedAt.toISOString(),
    })),
  });
}

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = (await req.json().catch(() => null)) as Body | null;
  const action = body?.action;

  const cls = await db.select().from(classes).where(eq(classes.id, id)).limit(1);
  if (!cls[0]) {
    return NextResponse.json({ ok: false, message: "Session not found." }, { status: 404 });
  }

  const learner = await requireLearner();
  const admin = await requireAdmin();
  const actor = learner ?? admin;
  if (!actor) {
    return NextResponse.json(
      { ok: false, message: "Open an invitation link or sign in first." },
      { status: 401 },
    );
  }

  const existing = await db
    .select()
    .from(attendance)
    .where(and(eq(attendance.classId, id), eq(attendance.userId, actor.userId)))
    .limit(1);
  const row = existing[0];

  if (action === "join") {
    if (row) {
      await db
        .update(attendance)
        .set({ leftAt: null, joinedAt: new Date(), updatedAt: new Date() })
        .where(eq(attendance.id, row.id));
    } else {
      await db.insert(attendance).values({
        classId: id,
        userId: actor.userId,
        displayName: actor.displayName,
        cameraOn: false,
        micOn: false,
      });
    }
    if (cls[0].status === "scheduled") {
      await db.update(classes).set({ status: "live" }).where(eq(classes.id, id));
    }
    await recordAudit({
      actorId: actor.userId,
      actorLabel: actor.displayName,
      action: "classroom.joined",
      target: cls[0].title,
      ip: clientIp(req.headers),
      meta: { classId: id, cameraOn: false },
    });
    return NextResponse.json({ ok: true });
  }

  if (!row) {
    return NextResponse.json({ ok: false, message: "Join the session first." }, { status: 400 });
  }

  if (action === "leave") {
    await db
      .update(attendance)
      .set({ leftAt: new Date(), cameraOn: false, micOn: false, updatedAt: new Date() })
      .where(eq(attendance.id, row.id));
    await db.delete(signals).where(eq(signals.classId, id));
    await recordAudit({
      actorId: actor.userId,
      actorLabel: actor.displayName,
      action: "classroom.left",
      target: cls[0].title,
      ip: clientIp(req.headers),
      meta: { classId: id, mediaStopped: true },
    });
    return NextResponse.json({ ok: true });
  }

  if (action === "camera") {
    const on = body?.on === true;
    // Consent can only ever be granted BY the learner, from their own device.
    if (on && body?.consent !== true) {
      return NextResponse.json(
        { ok: false, message: "Explicit learner consent is required before enabling a camera." },
        { status: 400 },
      );
    }
    await db
      .update(attendance)
      .set({
        cameraOn: on,
        cameraConsentAt: on ? (row.cameraConsentAt ?? new Date()) : row.cameraConsentAt,
        updatedAt: new Date(),
      })
      .where(eq(attendance.id, row.id));
    await recordAudit({
      actorId: actor.userId,
      actorLabel: actor.displayName,
      action: on ? "classroom.camera_enabled" : "classroom.camera_disabled",
      target: cls[0].title,
      severity: on ? "notice" : "info",
      ip: clientIp(req.headers),
      meta: { classId: id, selfInitiated: true },
    });
    return NextResponse.json({ ok: true, cameraOn: on });
  }

  if (action === "mic") {
    const on = body?.on === true;
    await db
      .update(attendance)
      .set({ micOn: on, updatedAt: new Date() })
      .where(eq(attendance.id, row.id));
    return NextResponse.json({ ok: true, micOn: on });
  }

  if (action === "hand") {
    const on = body?.on === true;
    await db
      .update(attendance)
      .set({ handRaised: on, updatedAt: new Date() })
      .where(eq(attendance.id, row.id));
    return NextResponse.json({ ok: true, handRaised: on });
  }

  return NextResponse.json({ ok: false, message: "Unknown action." }, { status: 400 });
}