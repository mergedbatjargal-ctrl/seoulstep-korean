import { NextResponse } from "next/server";
import { db } from "@/db";
import { attendance, classes, signals } from "@/db/schema";
import { and, asc, eq } from "drizzle-orm";
import { requireAdmin, requireLearner } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * Signalling relay.
 * Routing rule enforced server-side: a LEARNER may only address the instructor of
 * their own session, and the INSTRUCTOR may only address learners present in that
 * session. Learner-to-learner media paths cannot be negotiated through this API.
 */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const me = (await requireLearner()) ?? (await requireAdmin());
  if (!me) return NextResponse.json({ ok: false }, { status: 401 });

  const inbox = await db
    .select()
    .from(signals)
    .where(and(eq(signals.classId, id), eq(signals.toId, me.userId)))
    .orderBy(asc(signals.id))
    .limit(60);

  if (inbox.length) {
    await db.delete(signals).where(and(eq(signals.classId, id), eq(signals.toId, me.userId)));
  }

  return NextResponse.json({
    ok: true,
    messages: inbox.map((m) => ({
      id: m.id,
      from: m.fromId,
      kind: m.kind,
      payload: m.payload,
    })),
  });
}

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const learner = await requireLearner();
  const admin = learner ? null : await requireAdmin();
  const me = learner ?? admin;
  if (!me) return NextResponse.json({ ok: false }, { status: 401 });

  const cls = await db.select().from(classes).where(eq(classes.id, id)).limit(1);
  if (!cls[0]) return NextResponse.json({ ok: false }, { status: 404 });

  const body = await req.json().catch(() => null);
  const to = typeof body?.to === "string" ? body.to : "";
  const kind = typeof body?.kind === "string" ? body.kind : "";
  const payload = body?.payload;

  if (!to || !["offer", "answer", "ice", "bye"].includes(kind) || payload == null) {
    return NextResponse.json({ ok: false, message: "Malformed signal." }, { status: 400 });
  }

  if (learner) {
    if (!cls[0].instructorId || to !== cls[0].instructorId) {
      return NextResponse.json(
        { ok: false, message: "Learners may only send media to their instructor." },
        { status: 403 },
      );
    }
  } else if (admin) {
    if (admin.userId !== cls[0].instructorId) {
      return NextResponse.json({ ok: false, message: "Not your session." }, { status: 403 });
    }
    const present = await db
      .select()
      .from(attendance)
      .where(and(eq(attendance.classId, id), eq(attendance.userId, to)))
      .limit(1);
    if (!present[0] || present[0].leftAt) {
      return NextResponse.json(
        { ok: false, message: "That learner is not in this session." },
        { status: 403 },
      );
    }
  }

  await db.insert(signals).values({ classId: id, fromId: me.userId, toId: to, kind, payload });
  return NextResponse.json({ ok: true });
}