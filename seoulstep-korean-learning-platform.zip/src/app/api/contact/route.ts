import { NextResponse } from "next/server";
import { recordAudit } from "@/lib/audit";
import { clientIp } from "@/lib/auth";

export const dynamic = "force-dynamic";

const TOPICS = ["privacy", "camera", "account", "lesson", "other"] as const;

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const name = typeof body?.name === "string" ? body.name.trim().slice(0, 80) : "";
  const email = typeof body?.email === "string" ? body.email.trim().slice(0, 160) : "";
  const topic = typeof body?.topic === "string" ? body.topic : "other";
  const message = typeof body?.message === "string" ? body.message.trim().slice(0, 4000) : "";

  if (!message || message.length < 10) {
    return NextResponse.json(
      { ok: false, message: "Please write at least a sentence so we can help." },
      { status: 400 },
    );
  }
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return NextResponse.json(
      { ok: false, message: "That email address doesn't look right." },
      { status: 400 },
    );
  }

  // Delivered to the site owner through the same append-only log the console reads.
  await recordAudit({
    actorLabel: name || email || "anonymous",
    action: "contact.message_received",
    target: TOPICS.includes(topic as (typeof TOPICS)[number]) ? topic : "other",
    severity: "notice",
    ip: clientIp(req.headers),
    meta: { email: email || null, message },
  });

  return NextResponse.json({
    ok: true,
    message: "Thanks — your message reached the site owner. Expect a reply by email if you left one.",
  });
}