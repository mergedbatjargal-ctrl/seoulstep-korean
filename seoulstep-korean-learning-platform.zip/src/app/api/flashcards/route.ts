import { NextResponse } from "next/server";
import { db } from "@/db";
import { cardReviews, earnedBadges, progress } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireLearner } from "@/lib/auth";
import { FLASHCARDS } from "@/lib/curriculum";
import { schedule, type Grade } from "@/lib/srs";
import { evaluateBadges } from "@/lib/badges";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await requireLearner();
  if (!session) return NextResponse.json({ ok: false }, { status: 401 });

  const rows = await db.select().from(cardReviews).where(eq(cardReviews.userId, session.userId));
  const byCard = new Map(rows.map((r) => [r.cardId, r]));
  const now = Date.now();

  const cards = FLASHCARDS.map((c) => {
    const r = byCard.get(c.id);
    return {
      ...c,
      state: r
        ? {
            ease: r.ease,
            intervalDays: r.intervalDays,
            reps: r.reps,
            lapses: r.lapses,
            dueAt: r.dueAt.toISOString(),
          }
        : null,
      isNew: !r,
      isDue: !r ? false : r.dueAt.getTime() <= now,
    };
  });

  const due = cards.filter((c) => c.isDue).length;
  const fresh = cards.filter((c) => c.isNew).length;
  const learned = cards.filter((c) => c.state && c.state.reps > 0).length;

  return NextResponse.json({
    ok: true,
    cards,
    stats: { total: cards.length, due, fresh, learned },
  });
}

export async function POST(req: Request) {
  const session = await requireLearner();
  if (!session) return NextResponse.json({ ok: false }, { status: 401 });

  const body = await req.json().catch(() => null);
  const cardId = body?.cardId as string | undefined;
  const grade = body?.grade as Grade | undefined;
  if (!cardId || !FLASHCARDS.some((c) => c.id === cardId)) {
    return NextResponse.json({ ok: false, message: "Unknown card." }, { status: 400 });
  }
  if (!grade || !["again", "hard", "good", "easy"].includes(grade)) {
    return NextResponse.json({ ok: false, message: "Unknown grade." }, { status: 400 });
  }

  const rows = await db.select().from(cardReviews).where(eq(cardReviews.userId, session.userId));
  const existing = rows.find((r) => r.cardId === cardId);
  const next = schedule(
    existing
      ? {
          ease: existing.ease,
          intervalDays: existing.intervalDays,
          reps: existing.reps,
          lapses: existing.lapses,
          dueAt: existing.dueAt,
        }
      : null,
    grade,
  );

  if (existing) {
    await db
      .update(cardReviews)
      .set({
        ease: next.ease,
        intervalDays: next.intervalDays,
        reps: next.reps,
        lapses: next.lapses,
        dueAt: next.dueAt,
        updatedAt: new Date(),
      })
      .where(eq(cardReviews.id, existing.id));
  } else {
    await db.insert(cardReviews).values({
      userId: session.userId,
      cardId,
      ease: next.ease,
      intervalDays: next.intervalDays,
      reps: next.reps,
      lapses: next.lapses,
      dueAt: next.dueAt,
    });
  }

  const all = await db.select().from(cardReviews).where(eq(cardReviews.userId, session.userId));
  if (all.length >= 20) {
    const lessons = await db.select().from(progress).where(eq(progress.userId, session.userId));
    const should = evaluateBadges({
      completedLessonIds: lessons.filter((l) => l.status === "completed").map((l) => l.lessonId),
      perfectLessonIds: lessons.filter((l) => l.bestScore >= 100).map((l) => l.lessonId),
      cardsReviewed: all.length,
      joinedClass: false,
    });
    const already = await db
      .select()
      .from(earnedBadges)
      .where(eq(earnedBadges.userId, session.userId));
    const owned = new Set(already.map((b) => b.badgeId));
    const fresh = should.filter((b) => !owned.has(b));
    if (fresh.length) {
      await db
        .insert(earnedBadges)
        .values(fresh.map((badgeId) => ({ userId: session.userId, badgeId })));
    }
  }

  return NextResponse.json({
    ok: true,
    next: { dueAt: next.dueAt.toISOString(), intervalDays: next.intervalDays, reps: next.reps },
  });
}

export async function DELETE() {
  const session = await requireLearner();
  if (!session) return NextResponse.json({ ok: false }, { status: 401 });
  await db.delete(cardReviews).where(eq(cardReviews.userId, session.userId));
  return NextResponse.json({ ok: true });
}