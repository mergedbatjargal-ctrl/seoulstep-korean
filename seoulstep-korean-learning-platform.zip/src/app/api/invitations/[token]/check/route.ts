import { NextResponse } from "next/server";
import { db } from "@/db";
import { invitations } from "@/db/schema";
import { eq } from "drizzle-orm";
import { classes } from "@/db/schema";
import { getLesson } from "@/lib/curriculum";

export const dynamic = "force-dynamic";

export type InviteStatus = {
  ok: boolean;
  message?: string;
  invite?: {
    label: string;
    lessonId: string | null;
    lessonTitle: string | null;
    classId: string | null;
    classTitle: string | null;
    expiresAt: string | null;
    /** Always learner — invitations can never elevate privileges. */
    scope: "learner";
  };
};

export async function GET(_req: Request, ctx: { params: Promise<{ token: string }> }) {
  const { token } = await ctx.params;
  const rows = await db
    .select()
    .from(invitations)
    .where(eq(invitations.token, token))
    .limit(1);
  const invite = rows[0];

  if (!invite) {
    return NextResponse.json<InviteStatus>(
      { ok: false, message: "This invitation link doesn't exist. Ask your instructor to resend it." },
      { status: 404 },
    );
  }
  if (invite.revokedAt) {
    return NextResponse.json<InviteStatus>(
      { ok: false, message: "This invitation was revoked by the instructor." },
      { status: 410 },
    );
  }
  if (invite.expiresAt && invite.expiresAt.getTime() < Date.now()) {
    return NextResponse.json<InviteStatus>(
      { ok: false, message: "This invitation has expired. Ask for a fresh link." },
      { status: 410 },
    );
  }
  if (invite.uses >= invite.maxUses) {
    return NextResponse.json<InviteStatus>(
      { ok: false, message: "This invitation has reached its maximum number of uses." },
      { status: 410 },
    );
  }

  let classTitle: string | null = null;
  if (invite.classId) {
    const c = await db.select().from(classes).where(eq(classes.id, invite.classId)).limit(1);
    classTitle = c[0]?.title ?? null;
  }

  return NextResponse.json<InviteStatus>({
    ok: true,
    invite: {
      label: invite.label,
      lessonId: invite.lessonId,
      lessonTitle: invite.lessonId ? (getLesson(invite.lessonId)?.title ?? null) : null,
      classId: invite.classId,
      classTitle,
      expiresAt: invite.expiresAt ? invite.expiresAt.toISOString() : null,
      scope: "learner",
    },
  });
}