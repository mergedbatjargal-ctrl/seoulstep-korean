import { NextResponse } from "next/server";
import { db } from "@/db";
import { classes, invitations, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { LEARNER_COOKIE, clientIp, createSession, requireLearner } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

/**
 * Redeeming an invitation grants LEARNER access only.
 * There is deliberately no parameter, header or payload that can raise the scope:
 * the created session is hard-coded to role "learner".
 */
export async function POST(req: Request, ctx: { params: Promise<{ token: string }> }) {
  const { token } = await ctx.params;
  const rows = await db.select().from(invitations).where(eq(invitations.token, token)).limit(1);
  const invite = rows[0];

  if (!invite) {
    return NextResponse.json(
      { ok: false, message: "This invitation link doesn't exist." },
      { status: 404 },
    );
  }
  if (invite.revokedAt) {
    return NextResponse.json(
      { ok: false, message: "This invitation was revoked by the instructor." },
      { status: 410 },
    );
  }
  if (invite.expiresAt && invite.expiresAt.getTime() < Date.now()) {
    return NextResponse.json(
      { ok: false, message: "This invitation has expired." },
      { status: 410 },
    );
  }
  if (invite.uses >= invite.maxUses) {
    return NextResponse.json(
      { ok: false, message: "This invitation has reached its usage limit." },
      { status: 410 },
    );
  }

  let learner = await requireLearner();
  if (!learner) {
    const body = await req.json().catch(() => null);
    const requested =
      typeof body?.displayName === "string" ? body.displayName.trim().slice(0, 48) : "";
    const displayName = requested || `Guest learner · ${Math.floor(100 + Math.random() * 899)}`;
    const inserted = await db
      .insert(users)
      .values({ displayName, role: "learner" })
      .returning({ id: users.id, displayName: users.displayName });
    await createSession(inserted[0].id, {
      cookieName: LEARNER_COOKIE,
      role: "learner",
      ip: clientIp(req.headers),
      userAgent: req.headers.get("user-agent"),
      ttlMs: 1000 * 60 * 60 * 24 * 90,
    });
    learner = {
      userId: inserted[0].id,
      displayName: inserted[0].displayName,
    } as unknown as Awaited<ReturnType<typeof requireLearner>>;
  }

  if (!learner) {
    return NextResponse.json({ ok: false, message: "Session error." }, { status: 500 });
  }

  await db
    .update(invitations)
    .set({ uses: invite.uses + 1 })
    .where(eq(invitations.id, invite.id));

  await recordAudit({
    actorId: learner.userId,
    actorLabel: learner.displayName,
    action: "invitation.redeemed",
    target: invite.label,
    ip: clientIp(req.headers),
    meta: { scope: "learner", inviteId: invite.id },
  });

  let classInfo: { id: string; title: string; status: string } | null = null;
  if (invite.classId) {
    const c = await db.select().from(classes).where(eq(classes.id, invite.classId)).limit(1);
    if (c[0]) classInfo = { id: c[0].id, title: c[0].title, status: c[0].status };
  }

  return NextResponse.json({
    ok: true,
    learner: { id: learner.userId, displayName: learner.displayName },
    lessonId: invite.lessonId,
    classId: invite.classId,
    class: classInfo,
    scope: "learner" as const,
  });
}