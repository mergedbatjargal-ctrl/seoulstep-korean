import { NextResponse } from "next/server";
import { db } from "@/db";
import { cardReviews, earnedBadges, progress } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireLearner } from "@/lib/auth";
import { LESSONS, getLesson } from "@/lib/curriculum";
import { evaluateBadges } from "@/lib/badges";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await requireLearner();
  if (!session) return NextResponse.json({ ok: false }, { status: 401 });

  const [rows, badges, reviews] = await Promise.all([
    db.select().from(progress).where(eq(progress.userId, session.userId)),
    db.select().from(earnedBadges).where(eq(earnedBadges.userId, session.userId)),
    db.select().from(cardReviews).where(eq(cardReviews.userId, session.userId)),
  ]);

  const completed = rows.filter((r) => r.status === "completed");
  const resume = [...rows]
    .filter((r) => r.status === "in_progress")
    .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime())[0];

  const now = Date.now();
  const dueCount = reviews.filter((r) => r.dueAt.getTime() <= now).length;

  return NextResponse.json({
    ok: true,
    learner: { id: session.userId, displayName: session.displayName },
    progress: rows.map((r) => ({
      lessonId: r.lessonId,
      status: r.status,
      step: r.step,
      score: r.score,
      bestScore: r.bestScore,
      secondsSpent: r.secondsSpent,
      completedAt: r.completedAt?.toISOString() ?? null,
      updatedAt: r.updatedAt.toISOString(),
    })),
    badges: badges.map((b) => ({ badgeId: b.badgeId, earnedAt: b.earnedAt.toISOString() })),
    stats: {
      totalLessons: LESSONS.length,
      completed: completed.length,
      minutes: Math.round(rows.reduce((n, r) => n + r.secondsSpent, 0) / 60),
      cardsSeen: reviews.length,
      cardsDue: dueCount,
      averageScore: completed.length
        ? Math.round(completed.reduce((n, r) => n + r.bestScore, 0) / completed.length)
        : 0,
    },
    resume: resume
      ? {
          lessonId: resume.lessonId,
          step: resume.step,
          title: getLesson(resume.lessonId)?.title ?? resume.lessonId,
          updatedAt: resume.updatedAt.toISOString(),
        }
      : null,
  });
}

type SaveBody = {
  lessonId?: string;
  step?: number;
  secondsSpent?: number;
  score?: number;
  complete?: boolean;
};

export async function POST(req: Request) {
  const session = await requireLearner();
  if (!session) return NextResponse.json({ ok: false }, { status: 401 });

  const body = (await req.json().catch(() => null)) as SaveBody | null;
  const lessonId = body?.lessonId;
  if (!lessonId || !getLesson(lessonId)) {
    return NextResponse.json({ ok: false, message: "Unknown lesson." }, { status: 400 });
  }

  const existing = await db.select().from(progress).where(eq(progress.userId, session.userId));
  const current = existing.find((r) => r.lessonId === lessonId);

  const lesson = getLesson(lessonId)!;
  const score = Math.max(0, Math.min(100, Math.round(body?.score ?? current?.score ?? 0)));
  const step = Math.max(0, Math.min(lesson.blocks.length, Math.round(body?.step ?? current?.step ?? 0)));
  const addSeconds = Math.max(0, Math.min(600, Math.round(body?.secondsSpent ?? 0)));
  const complete = body?.complete === true;

  if (current) {
    await db
      .update(progress)
      .set({
        step,
        score,
        bestScore: Math.max(current.bestScore, score),
        secondsSpent: current.secondsSpent + addSeconds,
        status: complete ? "completed" : current.status,
        completedAt: complete ? (current.completedAt ?? new Date()) : current.completedAt,
        updatedAt: new Date(),
      })
      .where(eq(progress.id, current.id));
  } else {
    await db.insert(progress).values({
      userId: session.userId,
      lessonId,
      step,
      score,
      bestScore: score,
      secondsSpent: addSeconds,
      status: complete ? "completed" : "in_progress",
      completedAt: complete ? new Date() : null,
    });
  }

  // Re-evaluate badges against the fresh state.
  const [fresh, reviews] = await Promise.all([
    db.select().from(progress).where(eq(progress.userId, session.userId)),
    db.select().from(cardReviews).where(eq(cardReviews.userId, session.userId)),
  ]);
  const completedIds = fresh.filter((r) => r.status === "completed").map((r) => r.lessonId);
  const perfectIds = fresh.filter((r) => r.bestScore >= 100).map((r) => r.lessonId);
  const should = evaluateBadges({
    completedLessonIds: completedIds,
    perfectLessonIds: perfectIds,
    cardsReviewed: reviews.length,
    joinedClass: false,
  });
  const already = await db
    .select()
    .from(earnedBadges)
    .where(eq(earnedBadges.userId, session.userId));
  const owned = new Set(already.map((b) => b.badgeId));
  const newlyEarned = should.filter((b) => !owned.has(b));
  if (newlyEarned.length) {
    await db
      .insert(earnedBadges)
      .values(newlyEarned.map((badgeId) => ({ userId: session.userId, badgeId })));
  }

  return NextResponse.json({ ok: true, newlyEarned });
}

/** Undo a completion or clear progress for a lesson. */
export async function DELETE(req: Request) {
  const session = await requireLearner();
  if (!session) return NextResponse.json({ ok: false }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const lessonId = searchParams.get("lessonId");
  if (!lessonId) return NextResponse.json({ ok: false }, { status: 400 });
  const rows = await db.select().from(progress).where(eq(progress.userId, session.userId));
  const row = rows.find((r) => r.lessonId === lessonId);
  if (row) await db.delete(progress).where(eq(progress.id, row.id));
  return NextResponse.json({ ok: true });
}