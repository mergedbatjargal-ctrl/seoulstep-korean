import type { Metadata } from "next";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { classes, users } from "@/db/schema";
import { ClassroomRoom } from "@/components/ClassroomRoom";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Live session · SeoulStep" };

export default async function ClassroomSession({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  let instructorName = "your instructor";
  try {
    const rows = await db.select().from(classes).where(eq(classes.id, id)).limit(1);
    const instructorId = rows[0]?.instructorId;
    if (instructorId) {
      const u = await db.select().from(users).where(eq(users.id, instructorId)).limit(1);
      instructorName = u[0]?.displayName ?? instructorName;
    }
  } catch {
    /* the client surfaces a clear error if the session can't be loaded */
  }

  return (
    <>
      <SiteHeader variant="app" />
      <main id="main">
        <ClassroomRoom classId={id} instructorName={instructorName} />
      </main>
      <SiteFooter />
    </>
  );
}