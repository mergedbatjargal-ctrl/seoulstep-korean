import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { attendance, classes, users } from "@/db/schema";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";
import { Chip, LinkButton, Reveal, SectionLabel } from "@/components/ui";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Live classroom · SeoulStep" };

export default async function ClassroomIndex() {
  let rows: (typeof classes.$inferSelect)[] = [];
  let instructorName = "your instructor";
  let counts: Record<string, number> = {};
  try {
    await ensureSeed();
    rows = await db.select().from(classes).orderBy(desc(classes.startsAt));
    const first = rows.find((r) => r.instructorId)?.instructorId;
    if (first) {
      const u = await db.select().from(users).where(eq(users.id, first)).limit(1);
      instructorName = u[0]?.displayName ?? instructorName;
    }
    const att = await db.select().from(attendance);
    counts = att.reduce<Record<string, number>>((acc, a) => {
      if (!a.leftAt) acc[a.classId] = (acc[a.classId] ?? 0) + 1;
      return acc;
    }, {});
  } catch {
    rows = [];
  }

  return (
    <>
      <SiteHeader variant="app" />
      <main id="main" className="mx-auto max-w-6xl px-4 pb-20 pt-28 sm:px-6 lg:px-8">
        <SectionLabel tone="#FF4D5E">라이브 수업 · Live classroom</SectionLabel>
        <h1 className="font-display text-3xl font-black leading-tight text-hanji-50 sm:text-[42px]">
          Join a class. Keep your camera off.
        </h1>
        <p className="mt-3 max-w-2xl text-[15.5px] leading-relaxed text-mute-300">
          Opening this page — or any invitation link — never triggers a camera or microphone prompt.
          You choose, every time, and you can change your mind mid-class.
        </p>

        <div className="mt-7 grid gap-3 sm:grid-cols-3">
          {[
            ["Off by default", "Camera and mic start disabled on every device, every session.", "#3ED6B0"],
            ["Explicit consent", "A plain-language panel first, then your browser's own prompt.", "#F5B841"],
            ["One recipient", "Your video reaches your instructor only — never other learners.", "#FF3D9A"],
          ].map(([t, d, tone]) => (
            <div
              key={t}
              className="rounded-2xl border p-4"
              style={{ borderColor: `${tone}33`, background: `${tone}0D` }}
            >
              <p className="text-[13px] font-bold" style={{ color: tone }}>
                {t}
              </p>
              <p className="mt-1 text-[12.5px] leading-relaxed text-mute-400">{d}</p>
            </div>
          ))}
        </div>

        <div className="mt-9 space-y-3">
          {rows.map((c, i) => (
            <Reveal key={c.id} delay={i * 60}>
              <Link
                href={`/classroom/${c.id}`}
                className="card card-hover flex flex-wrap items-center gap-4 p-5"
              >
                <span
                  className="grid h-12 w-12 shrink-0 place-items-center rounded-xl font-display text-lg font-black"
                  style={{
                    background: c.status === "live" ? "#FF4D5E22" : "#26314A",
                    color: c.status === "live" ? "#FF7A72" : "#B3BDD2",
                  }}
                >
                  {c.status === "live" ? "●" : "○"}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex flex-wrap items-center gap-2">
                    <span className="font-display text-[17px] font-bold text-hanji-50">
                      {c.title}
                    </span>
                    <Chip tone={c.status === "live" ? "#FF4D5E" : "#8E9AB4"} className="!text-[9.5px]">
                      {c.status}
                    </Chip>
                  </span>
                  <span className="mt-0.5 block text-[12.5px] text-mute-400">
                    {c.titleKo} · {c.code} ·{" "}
                    {new Date(c.startsAt).toLocaleString(undefined, {
                      weekday: "short",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                </span>
                <span className="flex items-center gap-4 text-[12px] text-mute-400">
                  <span>{counts[c.id] ?? 0} present</span>
                  <span className="rounded-full border border-hanji-200/15 px-3 py-1.5 font-semibold text-hanji-100">
                    Enter lobby →
                  </span>
                </span>
              </Link>
            </Reveal>
          ))}
          {rows.length === 0 && (
            <p className="rounded-2xl border border-hanji-200/12 bg-ink-900/60 p-8 text-center text-sm text-mute-400">
              No sessions are scheduled right now. You can still work through every lesson on your
              own.
            </p>
          )}
        </div>

        <div className="mt-8 flex flex-col items-start justify-between gap-4 rounded-3xl border border-hanji-200/12 bg-ink-900/60 p-6 sm:flex-row sm:items-center">
          <p className="max-w-2xl text-sm leading-relaxed text-mute-300">
            Got an invitation link from {instructorName}? Redeeming it opens learner access to the
            lesson and its session — nothing more. Invitations carry an expiry date and can be
            revoked at any moment.
          </p>
          <LinkButton href="/learn" variant="secondary">
            Study on my own instead
          </LinkButton>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}