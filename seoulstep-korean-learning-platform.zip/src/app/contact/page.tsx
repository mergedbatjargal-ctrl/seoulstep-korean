"use client";

import { useState } from "react";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";
import { Button, SectionLabel } from "@/components/ui";

const TOPICS = [
  ["privacy", "A privacy or data question"],
  ["camera", "Something about the camera or a live session"],
  ["account", "My learner record (export or delete)"],
  ["lesson", "Lesson content or a mistake I spotted"],
  ["other", "Something else"],
] as const;

export default function ContactPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [topic, setTopic] = useState<string>("privacy");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; text: string } | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setResult(null);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name, email, topic, message }),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        setResult({ ok: false, text: json?.message ?? "That didn't send. Please try again." });
      } else {
        setResult({ ok: true, text: json.message });
        setMessage("");
      }
    } catch {
      setResult({ ok: false, text: "Network problem — check your connection and try again." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <SiteHeader variant="app" />
      <main id="main" className="mx-auto max-w-5xl px-4 pb-20 pt-28 sm:px-6 lg:px-8">
        <SectionLabel tone="#4C9BFF">문의 · Contact</SectionLabel>
        <h1 className="font-display text-3xl font-black leading-tight text-hanji-50 sm:text-[46px]">
          Talk to the person who runs this site.
        </h1>
        <p className="mt-3 max-w-2xl text-[15.5px] leading-relaxed text-mute-300">
          Not a ticket queue. Messages land in the owner's console log and get a human reply. Use
          this for privacy requests, data deletion, or anything that felt wrong in a live session.
        </p>

        <div className="mt-9 grid gap-5 lg:grid-cols-[1.3fr_1fr]">
          <form onSubmit={submit} className="card p-6">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="c-name" className="block text-[11px] font-semibold uppercase tracking-wider text-mute-400">
                  Name (optional)
                </label>
                <input
                  id="c-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-1.5 w-full rounded-xl border border-hanji-200/18 bg-ink-900 px-4 py-2.5 text-sm text-hanji-50 outline-none transition focus:border-hanbok-500"
                />
              </div>
              <div>
                <label htmlFor="c-email" className="block text-[11px] font-semibold uppercase tracking-wider text-mute-400">
                  Email (only if you want a reply)
                </label>
                <input
                  id="c-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="mt-1.5 w-full rounded-xl border border-hanji-200/18 bg-ink-900 px-4 py-2.5 text-sm text-hanji-50 outline-none transition focus:border-hanbok-500"
                />
              </div>
            </div>

            <fieldset className="mt-5">
              <legend className="text-[11px] font-semibold uppercase tracking-wider text-mute-400">
                What's this about?
              </legend>
              <div className="mt-2 flex flex-wrap gap-2">
                {TOPICS.map(([id, label]) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setTopic(id)}
                    aria-pressed={topic === id}
                    className={`rounded-full border px-3.5 py-2 text-[12.5px] font-semibold transition ${
                      topic === id
                        ? "border-hanbok-500 bg-hanbok-500/18 text-hanbok-400"
                        : "border-hanji-200/12 text-mute-400 hover:text-hanji-100"
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </fieldset>

            <label htmlFor="c-msg" className="mt-5 block text-[11px] font-semibold uppercase tracking-wider text-mute-400">
              Message
            </label>
            <textarea
              id="c-msg"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={6}
              required
              minLength={10}
              placeholder="Tell us what happened, or what you'd like us to do with your data."
              className="mt-1.5 w-full resize-y rounded-xl border border-hanji-200/18 bg-ink-900 px-4 py-3 text-sm text-hanji-50 outline-none transition placeholder:text-mute-400/60 focus:border-hanbok-500"
            />

            {result && (
              <p
                className={`mt-4 rounded-xl border px-3 py-2.5 text-[13.5px] ${
                  result.ok
                    ? "border-celadon-500/40 bg-celadon-500/10 text-celadon-400"
                    : "border-dancheong-500/40 bg-dancheong-500/10 text-dancheong-400"
                }`}
              >
                {result.text}
              </p>
            )}

            <Button type="submit" size="lg" className="mt-5" disabled={busy || message.trim().length < 10}>
              {busy ? "Sending…" : "Send to the site owner"}
            </Button>
            <p className="mt-3 text-[11.5px] leading-relaxed text-mute-400">
              We store only what you type here plus a timestamp, and only to answer you.
            </p>
          </form>

          <aside className="space-y-4">
            <div className="card p-6">
              <h2 className="font-display text-lg font-bold text-hanji-50">Data requests</h2>
              <p className="mt-2 text-[13.5px] leading-relaxed text-mute-400">
                Ask for a copy of your record, or for it to be deleted entirely. We action requests
                within 30 days and confirm by email if you gave one.
              </p>
            </div>
            <div className="card p-6">
              <h2 className="font-display text-lg font-bold text-hanji-50">Report a privacy concern</h2>
              <p className="mt-2 text-[13.5px] leading-relaxed text-mute-400">
                If a camera ever appeared to be active without your consent, tell us immediately.
                Include the session name and roughly when it happened — the audit log will show
                exactly what occurred.
              </p>
            </div>
            <div className="card p-6">
              <h2 className="font-display text-lg font-bold text-hanji-50">Operator</h2>
              <p className="mt-2 text-[13.5px] leading-relaxed text-mute-400">
                SeoulStep Learning · Seoul &amp; remote
                <br />
                Everything on this site runs over HTTPS. No third-party analytics are loaded.
              </p>
            </div>
          </aside>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}