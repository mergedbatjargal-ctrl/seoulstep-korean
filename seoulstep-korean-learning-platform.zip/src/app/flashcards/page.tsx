"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { FLASHCARDS } from "@/lib/curriculum";
import { GRADE_LABELS, previewInterval, schedule, type Grade, type SrsState } from "@/lib/srs";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";
import { Button, Chip, ProgressRing, SectionLabel, Toast, cx } from "@/components/ui";
import { primeVoices, speakKorean, speechSupported } from "@/lib/speech";
import { ensureLearner } from "@/lib/learner-client";

type CardState = {
  ease: number;
  intervalDays: number;
  reps: number;
  lapses: number;
  dueAt: string;
};

type ApiCard = (typeof FLASHCARDS)[number] & {
  state: CardState | null;
  isNew: boolean;
  isDue: boolean;
};

type Mode = "due" | "new" | "all";

export default function FlashcardsPage() {
  const [cards, setCards] = useState<ApiCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [mode, setMode] = useState<Mode>("due");
  const [deck, setDeck] = useState<string>("All");
  const [queue, setQueue] = useState<string[]>([]);
  const [pos, setPos] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [reviewed, setReviewed] = useState(0);
  const [toast, setToast] = useState<string | null>(null);

  const decks = useMemo(
    () => ["All", ...Array.from(new Set(FLASHCARDS.map((c) => c.deck)))],
    [],
  );

  const load = useCallback(async () => {
    setLoading(true);
    try {
      await ensureLearner();
      const res = await fetch("/api/flashcards", { cache: "no-store" });
      if (!res.ok) throw new Error("bad");
      const json = await res.json();
      setCards(json.cards as ApiCard[]);
      setError(null);
    } catch {
      setError("Your deck couldn't be loaded. Check your connection and refresh.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    primeVoices();
  }, [load]);

  const pool = useMemo(() => {
    let list = cards;
    if (deck !== "All") list = list.filter((c) => c.deck === deck);
    if (mode === "due") list = list.filter((c) => c.isDue);
    if (mode === "new") list = list.filter((c) => c.isNew);
    return list;
  }, [cards, deck, mode]);

  // Rebuild the queue whenever the pool selection changes (not on every review).
  useEffect(() => {
    setQueue(pool.map((c) => c.id));
    setPos(0);
    setFlipped(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, deck, cards.length, loading]);

  const current = cards.find((c) => c.id === queue[pos]) ?? null;
  const dueCount = cards.filter((c) => c.isDue).length;
  const newCount = cards.filter((c) => c.isNew).length;
  const learnedCount = cards.filter((c) => c.state && c.state.reps > 0).length;

  async function grade(g: Grade) {
    if (!current) return;
    const before: SrsState | null = current.state
      ? { ...current.state, dueAt: new Date(current.state.dueAt) }
      : null;
    const next = schedule(before, g);

    // Optimistic update
    setCards((prev) =>
      prev.map((c) =>
        c.id === current.id
          ? {
              ...c,
              isNew: false,
              isDue: next.dueAt.getTime() <= Date.now(),
              state: {
                ease: next.ease,
                intervalDays: next.intervalDays,
                reps: next.reps,
                lapses: next.lapses,
                dueAt: next.dueAt.toISOString(),
              },
            }
          : c,
      ),
    );
    setReviewed((n) => n + 1);
    setFlipped(false);
    setPos((p) => p + 1);

    try {
      const res = await fetch("/api/flashcards", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ cardId: current.id, grade: g }),
      });
      if (!res.ok) throw new Error("bad");
      setToast(`Next review in ${previewInterval(before, g)}`);
      setTimeout(() => setToast(null), 1800);
    } catch {
      // Roll back on failure
      setCards((prev) =>
        prev.map((c) => (c.id === current.id ? { ...c, state: current.state, isNew: current.isNew, isDue: current.isDue } : c)),
      );
      setToast("Couldn't save that review — try again.");
      setTimeout(() => setToast(null), 2400);
    }
  }

  const sessionDone = queue.length > 0 && pos >= queue.length;

  return (
    <>
      <SiteHeader variant="app" />
      <main id="main" className="mx-auto max-w-6xl px-4 pb-20 pt-28 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-5">
          <div>
            <SectionLabel tone="#F5B841">플래시카드 · Spaced repetition</SectionLabel>
            <h1 className="font-display text-3xl font-black leading-tight text-hanji-50 sm:text-[42px]">
              Review right before you'd forget.
            </h1>
            <p className="mt-2 max-w-xl text-[15px] text-mute-300">
              Each answer reschedules the card with an SM-2 curve. Grade honestly — the algorithm
              only works if you do.
            </p>
          </div>
          <div className="flex items-center gap-4 rounded-2xl border border-hanji-200/12 bg-ink-900/60 px-5 py-4">
            <ProgressRing
              value={FLASHCARDS.length ? Math.round((learnedCount / FLASHCARDS.length) * 100) : 0}
              size={58}
              tone="#F5B841"
            />
            <div className="text-[12px]">
              <p className="text-mute-400">
                <strong className="text-dancheong-400">{dueCount}</strong> due now
              </p>
              <p className="text-mute-400">
                <strong className="text-hanbok-400">{newCount}</strong> new
              </p>
              <p className="text-mute-400">
                <strong className="text-celadon-400">{learnedCount}</strong> in rotation
              </p>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="mt-7 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex gap-2">
            {(
              [
                ["due", `Due (${dueCount})`, "#FF4D5E"],
                ["new", `New (${newCount})`, "#4C9BFF"],
                ["all", "Browse all", "#8E9AB4"],
              ] as const
            ).map(([m, label, tone]) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                aria-pressed={mode === m}
                className={cx(
                  "rounded-full border px-4 py-2 text-[12.5px] font-semibold transition-all duration-300",
                  mode === m ? "text-ink-950" : "border-hanji-200/12 text-mute-300 hover:text-hanji-50",
                )}
                style={mode === m ? { background: tone, borderColor: tone } : undefined}
              >
                {label}
              </button>
            ))}
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {decks.map((d) => (
              <button
                key={d}
                onClick={() => setDeck(d)}
                aria-pressed={deck === d}
                className={cx(
                  "shrink-0 rounded-full border px-3.5 py-2 text-[12.5px] font-semibold transition",
                  deck === d
                    ? "border-gold-500/60 bg-gold-500/15 text-gold-400"
                    : "border-hanji-200/12 text-mute-400 hover:text-hanji-100",
                )}
              >
                {d}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <p className="mt-6 rounded-2xl border border-dancheong-500/40 bg-dancheong-500/10 px-4 py-3 text-sm text-dancheong-400">
            {error}
          </p>
        )}

        {/* Card */}
        <div className="mt-8 grid gap-6 lg:grid-cols-[1.35fr_1fr]">
          <div>
            {loading ? (
              <div className="grid h-72 place-items-center rounded-3xl border border-hanji-200/12 bg-ink-900/50 text-sm text-mute-400">
                Loading your deck…
              </div>
            ) : current ? (
              <>
                <div className="mb-3 flex items-center justify-between text-[12px] text-mute-400">
                  <span>
                    Card {pos + 1} of {queue.length}
                  </span>
                  <span className="flex items-center gap-2">
                    <Chip tone={current.isNew ? "#4C9BFF" : "#3ED6B0"} className="!text-[9.5px]">
                      {current.isNew ? "New" : `Rep ${current.state?.reps ?? 0}`}
                    </Chip>
                    <Chip tone="#8E9AB4" className="!text-[9.5px]">
                      {current.deck}
                    </Chip>
                  </span>
                </div>

                <button
                  onClick={() => setFlipped((f) => !f)}
                  className="block h-72 w-full [perspective:1400px]"
                  aria-label="Flip card"
                >
                  <div
                    className="relative h-full w-full transition-transform duration-700 [transform-style:preserve-3d]"
                    style={{ transform: flipped ? "rotateY(180deg)" : "none" }}
                  >
                    <div className="absolute inset-0 grid place-items-center overflow-hidden rounded-3xl border border-gold-500/30 bg-[linear-gradient(150deg,rgba(245,184,65,0.14),rgba(14,19,32,0.96))] p-8 [backface-visibility:hidden]">
                      <div className="text-center">
                        <p className="font-display text-5xl font-black text-hanji-50 sm:text-6xl">
                          {current.front}
                        </p>
                        <p className="mt-3 text-base text-gold-400">{current.roman}</p>
                        <p className="mt-6 text-[11px] uppercase tracking-[0.24em] text-mute-400">
                          Tap to reveal
                        </p>
                      </div>
                    </div>
                    <div className="absolute inset-0 grid place-items-center overflow-hidden rounded-3xl border border-celadon-500/35 bg-[linear-gradient(150deg,rgba(62,214,176,0.16),rgba(14,19,32,0.96))] p-8 [backface-visibility:hidden] [transform:rotateY(180deg)]">
                      <div className="text-center">
                        <p className="font-display text-3xl font-bold text-celadon-400 sm:text-4xl">
                          {current.back}
                        </p>
                        <div className="mt-5 rounded-2xl border border-hanji-200/12 bg-ink-900/60 px-4 py-3">
                          <p className="font-display text-[17px] text-hanji-50">{current.example}</p>
                          <p className="mt-1 text-[13px] text-mute-400">{current.exampleEn}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </button>

                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => {
                      if (!speechSupported()) {
                        setToast("Speech isn't available in this browser.");
                        setTimeout(() => setToast(null), 2200);
                        return;
                      }
                      speakKorean(flipped ? current.example : current.front);
                    }}
                  >
                    🔊 Hear it
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => setFlipped((f) => !f)}>
                    {flipped ? "Show Korean" : "Reveal meaning"}
                  </Button>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {(["again", "hard", "good", "easy"] as Grade[]).map((g) => {
                    const meta = GRADE_LABELS[g];
                    const state: SrsState | null = current.state
                      ? { ...current.state, dueAt: new Date(current.state.dueAt) }
                      : null;
                    return (
                      <button
                        key={g}
                        onClick={() => grade(g)}
                        disabled={!flipped}
                        className={cx(
                          "rounded-2xl border px-3 py-3 text-center transition-all duration-300 disabled:opacity-40",
                          flipped && "hover:-translate-y-1",
                        )}
                        style={{ borderColor: `${meta.tone}55`, background: `${meta.tone}14` }}
                      >
                        <span className="block text-[13.5px] font-bold" style={{ color: meta.tone }}>
                          {meta.label}
                        </span>
                        <span className="block text-[10.5px] text-mute-400">
                          {previewInterval(state, g)}
                        </span>
                      </button>
                    );
                  })}
                </div>
                {!flipped && (
                  <p className="mt-2 text-center text-[11.5px] text-mute-400">
                    Reveal the meaning to grade this card.
                  </p>
                )}
              </>
            ) : sessionDone ? (
              <div className="grid h-72 place-items-center rounded-3xl border border-celadon-500/30 bg-[linear-gradient(150deg,rgba(62,214,176,0.14),rgba(14,19,32,0.95))] p-8 text-center pop">
                <div>
                  <p className="font-display text-5xl">🎴</p>
                  <h2 className="mt-3 font-display text-2xl font-black text-hanji-50">
                    Session complete
                  </h2>
                  <p className="mt-2 text-sm text-mute-300">
                    {reviewed} card{reviewed === 1 ? "" : "s"} reviewed. They'll come back exactly
                    when you need them.
                  </p>
                  <div className="mt-5 flex justify-center gap-2">
                    <Button variant="secondary" onClick={() => void load()}>
                      Refresh deck
                    </Button>
                    <Button onClick={() => setMode("new")}>Study new cards</Button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="grid h-72 place-items-center rounded-3xl border border-hanji-200/12 bg-ink-900/50 p-8 text-center">
                <div>
                  <p className="font-display text-4xl">✅</p>
                  <h2 className="mt-3 font-display text-xl font-bold text-hanji-50">
                    {mode === "due" ? "Nothing due right now" : "No cards here"}
                  </h2>
                  <p className="mt-2 max-w-sm text-sm text-mute-400">
                    {mode === "due"
                      ? "Spaced repetition is doing its job. Study new cards or come back later."
                      : "Try a different deck or switch to browse-all mode."}
                  </p>
                  <Button className="mt-5" onClick={() => setMode(mode === "due" ? "new" : "all")}>
                    {mode === "due" ? "Study new cards" : "Browse all cards"}
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Deck list */}
          <aside className="card max-h-[560px] overflow-y-auto p-5">
            <h2 className="font-display text-lg font-bold text-hanji-50">Deck</h2>
            <p className="mt-1 text-[12px] text-mute-400">
              {pool.length} card{pool.length === 1 ? "" : "s"} in this view
            </p>
            <ul className="mt-4 space-y-1.5">
              {pool.map((c) => {
                const active = current?.id === c.id;
                return (
                  <li key={c.id}>
                    <button
                      onClick={() => {
                        const idx = queue.indexOf(c.id);
                        if (idx >= 0) {
                          setPos(idx);
                          setFlipped(false);
                        }
                      }}
                      className={cx(
                        "flex w-full items-center justify-between gap-3 rounded-xl border px-3 py-2.5 text-left transition",
                        active
                          ? "border-gold-500/60 bg-gold-500/12"
                          : "border-hanji-200/10 bg-ink-900/50 hover:bg-ink-800",
                      )}
                    >
                      <span className="min-w-0">
                        <span className="block truncate font-display text-[15px] font-bold text-hanji-50">
                          {c.front}
                        </span>
                        <span className="block truncate text-[11.5px] text-mute-400">{c.back}</span>
                      </span>
                      <span
                        className="shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold"
                        style={{
                          background: c.isNew ? "#4C9BFF22" : c.isDue ? "#FF4D5E22" : "#3ED6B018",
                          color: c.isNew ? "#7BB6FF" : c.isDue ? "#FF7A72" : "#5FE6C4",
                        }}
                      >
                        {c.isNew ? "new" : c.isDue ? "due" : `${Math.round(c.state?.intervalDays ?? 0)}d`}
                      </span>
                    </button>
                  </li>
                );
              })}
              {pool.length === 0 && (
                <li className="rounded-xl border border-hanji-200/10 bg-ink-900/50 px-3 py-6 text-center text-[12.5px] text-mute-400">
                  Empty selection.
                </li>
              )}
            </ul>
          </aside>
        </div>
      </main>
      <SiteFooter />
      {toast && <Toast message={toast} tone="#F5B841" />}
    </>
  );
}