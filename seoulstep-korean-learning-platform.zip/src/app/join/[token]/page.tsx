import type { Metadata } from "next";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { classes, invitations } from "@/db/schema";
import { getLesson } from "@/lib/curriculum";
import { JoinRedeem } from "@/components/JoinRedeem";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Lesson invitation · SeoulStep" };

export default async function JoinPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;

  let problem: string | null = null;
  let label: string | null = null;
  let lessonId: string | null = null;
  let lessonTitle: string | null = null;
  let classId: string | null = null;
  let classTitle: string | null = null;
  let expiresAt: string | null = null;

  try {
    const rows = await db.select().from(invitations).where(eq(invitations.token, token)).limit(1);
    const invite = rows[0];
    if (!invite) {
      problem = "We couldn't find that invitation link. Ask your instructor to send a fresh one.";
    } else if (invite.revokedAt) {
      problem = "This invitation was revoked by the instructor, so it no longer opens anything.";
    } else if (invite.expiresAt && invite.expiresAt.getTime() < Date.now()) {
      problem = "This invitation expired. Invitation links are time-limited on purpose.";
    } else if (invite.uses >= invite.maxUses) {
      problem = "This invitation has reached its maximum number of learners.";
    } else {
      label = invite.label;
      lessonId = invite.lessonId;
      lessonTitle = invite.lessonId ? (getLesson(invite.lessonId)?.title ?? null) : null;
      classId = invite.classId;
      expiresAt = invite.expiresAt?.toISOString() ?? null;
      if (invite.classId) {
        const c = await db.select().from(classes).where(eq(classes.id, invite.classId)).limit(1);
        classTitle = c[0]?.title ?? null;
      }
    }
  } catch {
    problem = "The invitation service is temporarily unavailable. Please try again in a moment.";
  }

  return (
    <>
      <SiteHeader variant="app" />
      <main id="main">
        <JoinRedeem
          token={token}
          label={label}
          lessonId={lessonId}
          lessonTitle={lessonTitle}
          classId={classId}
          classTitle={classTitle}
          expiresAt={expiresAt}
          problem={problem}
        />
      </main>
      <SiteFooter />
    </>
  );
}