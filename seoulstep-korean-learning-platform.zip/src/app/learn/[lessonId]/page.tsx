import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { progress } from "@/db/schema";
import { LESSONS, TRACKS, getLesson } from "@/lib/curriculum";
import { requireLearner } from "@/lib/auth";
import { LessonPlayer } from "@/components/LessonPlayer";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";

export const dynamic = "force-dynamic";

export function generateStaticParams() {
  return LESSONS.map((l) => ({ lessonId: l.id }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ lessonId: string }>;
}): Promise<Metadata> {
  const { lessonId } = await params;
  const lesson = getLesson(lessonId);
  return { title: lesson ? `${lesson.title} · SeoulStep` : "Lesson · SeoulStep" };
}

export default async function LessonPage({
  params,
}: {
  params: Promise<{ lessonId: string }>;
}) {
  const { lessonId } = await params;
  const lesson = getLesson(lessonId);
  if (!lesson) notFound();

  let initialStep = 0;
  let wasCompleted = false;
  try {
    const session = await requireLearner();
    if (session) {
      const rows = await db
        .select()
        .from(progress)
        .where(and(eq(progress.userId, session.userId), eq(progress.lessonId, lessonId)))
        .limit(1);
      if (rows[0]) {
        initialStep = Math.min(rows[0].step, lesson.blocks.length - 1);
        wasCompleted = rows[0].status === "completed";
      }
    }
  } catch {
    /* lesson still renders without a session */
  }

  const tone = TRACKS.find((t) => t.id === lesson.track)?.hue ?? "#3ED6B0";

  return (
    <>
      <SiteHeader variant="app" />
      <main id="main">
        <LessonPlayer
          lesson={lesson}
          tone={tone}
          initialStep={initialStep}
          wasCompleted={wasCompleted}
        />
      </main>
      <SiteFooter />
    </>
  );
}