import type { Metadata } from "next";
import { LearnDashboard } from "@/components/LearnDashboard";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";

export const metadata: Metadata = { title: "Dashboard · SeoulStep" };

export default function LearnPage() {
  return (
    <>
      <SiteHeader variant="app" />
      <main id="main">
        <LearnDashboard />
      </main>
      <SiteFooter />
    </>
  );
}