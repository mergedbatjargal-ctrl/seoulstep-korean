"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { LESSONS, TRACKS, type TrackId } from "@/lib/curriculum";
import { useProgress } from "@/lib/learner-client";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";
import { Chip, SectionLabel, cx } from "@/components/ui";

type Filter = "all" | "todo" | "done";

export default function TracksPage() {
  const { data } = useProgress();
  const [track, setTrack] = useState<TrackId | "all">("all");
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");

  const byLesson = useMemo(
    () => new Map(data?.progress.map((p) => [p.lessonId, p]) ?? []),
    [data],
  );

  const lessons = LESSONS.filter((l) => {
    if (track !== "all" && l.track !== track) return false;
    const p = byLesson.get(l.id);
    if (filter === "done" && p?.status !== "completed") return false;
    if (filter === "todo" && p?.status === "completed") return false;
    if (query.trim()) {
      const q = query.toLowerCase();
      if (
        !l.title.toLowerCase().includes(q) &&
        !l.titleKo.includes(query) &&
        !l.summary.toLowerCase().includes(q)
      )
        return false;
    }
    return true;
  });

  return (
    <>
      <SiteHeader variant="app" />
      <main id="main" className="mx-auto max-w-7xl px-4 pb-20 pt-28 sm:px-6 lg:px-8">
        <SectionLabel>전체 수업 · All lessons</SectionLabel>
        <h1 className="font-display text-3xl font-black leading-tight text-hanji-50 sm:text-[42px]">
          Every lesson, in order.
        </h1>
        <p className="mt-2 max-w-2xl text-[15px] text-mute-300">
          Work top to bottom, or jump to whatever you need this week. Progress saves as you read.
        </p>

        {/* Controls */}
        <div className="mt-7 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex gap-2 overflow-x-auto pb-1">
            <FilterPill on={track === "all"} onClick={() => setTrack("all")} tone="#8E9AB4">
              All tracks
            </FilterPill>
            {TRACKS.map((t) => (
              <FilterPill
                key={t.id}
                on={track === t.id}
                onClick={() => setTrack(t.id)}
                tone={t.hue}
              >
                {t.glyph} {t.name}
              </FilterPill>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search lessons…"
              aria-label="Search lessons"
              className="w-full rounded-full border border-hanji-200/15 bg-ink-900 px-4 py-2 text-sm text-hanji-50 outline-none transition placeholder:text-mute-400/60 focus:border-celadon-500 lg:w-56"
            />
            {(["all", "todo", "done"] as Filter[]).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={cx(
                  "shrink-0 rounded-full border px-3 py-2 text-[12.5px] font-semibold capitalize transition",
                  filter === f
                    ? "border-celadon-500/60 bg-celadon-500/15 text-celadon-400"
                    : "border-hanji-200/12 text-mute-400 hover:text-hanji-100",
                )}
              >
                {f === "todo" ? "To do" : f}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-7 grid gap-3.5 md:grid-cols-2">
          {lessons.map((l) => {
            const p = byLesson.get(l.id);
            const t = TRACKS.find((x) => x.id === l.track)!;
            const done = p?.status === "completed";
            return (
              <Link
                key={l.id}
                href={`/learn/${l.id}`}
                className="card card-hover group flex gap-4 p-5"
                style={{ borderColor: done ? "#3ED6B055" : undefined }}
              >
                <span
                  className="grid h-12 w-12 shrink-0 place-items-center rounded-xl font-display text-xl font-black transition-transform duration-300 group-hover:scale-110"
                  style={{ background: `${t.hue}1E`, color: t.hue, border: `1px solid ${t.hue}44` }}
                >
                  {done ? "✓" : t.glyph}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex flex-wrap items-center gap-2">
                    <span className="font-display text-[16.5px] font-bold text-hanji-50">
                      {l.title}
                    </span>
                    <span className="text-[12px] text-mute-400">{l.titleKo}</span>
                  </span>
                  <span className="mt-1 block text-[13px] leading-relaxed text-mute-400">
                    {l.summary}
                  </span>
                  <span className="mt-3 flex flex-wrap items-center gap-2">
                    <Chip tone={t.hue} className="!text-[9.5px]">
                      {t.name}
                    </Chip>
                    <span className="text-[11.5px] text-mute-400">
                      {l.level} · {l.minutes} min · {l.quiz.length} questions
                    </span>
                    {done && p && (
                      <span className="text-[11.5px] font-semibold text-celadon-400">
                        Best {p.bestScore}%
                      </span>
                    )}
                    {!done && p && p.step > 0 && (
                      <span className="text-[11.5px] font-semibold text-gold-400">
                        In progress · step {p.step + 1}
                      </span>
                    )}
                  </span>
                </span>
              </Link>
            );
          })}
        </div>

        {lessons.length === 0 && (
          <p className="mt-12 rounded-2xl border border-hanji-200/12 bg-ink-900/60 p-8 text-center text-sm text-mute-400">
            No lessons match that filter. Try clearing the search.
          </p>
        )}
      </main>
      <SiteFooter />
    </>
  );
}

function FilterPill({
  children,
  on,
  onClick,
  tone,
}: {
  children: React.ReactNode;
  on: boolean;
  onClick: () => void;
  tone: string;
}) {
  return (
    <button
      onClick={onClick}
      aria-pressed={on}
      className={cx(
        "shrink-0 whitespace-nowrap rounded-full border px-3.5 py-2 text-[12.5px] font-semibold transition-all duration-300",
        on ? "text-ink-950" : "border-hanji-200/12 text-mute-300 hover:text-hanji-50",
      )}
      style={on ? { background: tone, borderColor: tone } : undefined}
    >
      {children}
    </button>
  );
}