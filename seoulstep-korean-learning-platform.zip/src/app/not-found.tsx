import Link from "next/link";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";
import { LinkButton } from "@/components/ui";

export default function NotFound() {
  return (
    <>
      <SiteHeader variant="app" />
      <main id="main" className="mx-auto grid min-h-[70vh] max-w-2xl place-items-center px-4 pt-24 text-center">
        <div>
          <p className="font-display text-7xl font-black text-celadon-500">길을 잃었어요</p>
          <h1 className="mt-4 font-display text-3xl font-black text-hanji-50">
            This page took a wrong turn.
          </h1>
          <p className="mt-3 text-[15px] leading-relaxed text-mute-300">
            The lesson or session you asked for isn't here. Your progress is safe — pick up from
            your dashboard.
          </p>
          <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
            <LinkButton href="/learn">Go to my dashboard</LinkButton>
            <Link
              href="/"
              className="inline-flex items-center justify-center rounded-full border border-hanji-200/18 px-7 py-3.5 text-[15px] font-semibold text-hanji-100 transition hover:border-celadon-500/60"
            >
              Back home
            </Link>
          </div>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}