import type { Metadata } from "next";
import { Landing } from "@/components/Landing";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";

export const metadata: Metadata = {
  title: "SeoulStep · Learn Korean, step by step",
  description:
    "Structured Korean lessons for Hangul, pronunciation, vocabulary, grammar, listening and conversation — with spaced-repetition flashcards, progress tracking, and live classes where your camera stays off until you choose otherwise.",
};

export default function Home() {
  return (
    <>
      <SiteHeader variant="landing" />
      <main id="main">
        <Landing />
      </main>
      <SiteFooter />
    </>
  );
}