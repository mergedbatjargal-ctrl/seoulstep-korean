import type { Metadata } from "next";
import Link from "next/link";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";
import { LinkButton, Reveal, SectionLabel } from "@/components/ui";

export const metadata: Metadata = { title: "Privacy practices · SeoulStep" };

const SECTIONS = [
  {
    title: "What we store",
    tone: "#3ED6B0",
    items: [
      "A display name you choose (an email address is optional and never required to learn).",
      "Lesson positions, quiz scores, time spent, and badges — so you can resume where you left off.",
      "Flashcard scheduling state: interval, ease and next-due date per card.",
      "Classroom presence: when you joined and left, and the timestamp of any camera consent you gave.",
      "An append-only audit log of instructor sign-ins and classroom access events.",
    ],
  },
  {
    title: "What we never do",
    tone: "#FF4D5E",
    items: [
      "We never request camera or microphone access because you opened a page or an invitation link.",
      "We never enable a learner's camera remotely. There is no instructor control that can do this.",
      "We never route one learner's video to another learner. Signalling rejects those routes server-side.",
      "We never record, transcribe, or store video or audio streams.",
      "We never use hidden capture, background capture, deceptive controls, or permission workarounds.",
      "We never sell, rent, or share your data with advertisers or data brokers. There are no ad SDKs or tracking pixels.",
    ],
  },
  {
    title: "How live video works",
    tone: "#F5B841",
    items: [
      "Camera and microphone are off by default in every session, on every device.",
      "Before any browser permission prompt appears, you see a plain-language panel naming exactly who will receive your video.",
      "The browser prompt is triggered only by your click on “Enable camera” after you tick the confirmation.",
      "While streaming, a red pulsing banner reads “Camera is on — visible to the instructor”, with a one-tap control to stop.",
      "Media travels peer-to-peer over WebRTC, encrypted in transit with DTLS-SRTP, addressed to that session's instructor only.",
      "Turning the camera off, or pressing “Leave session”, stops every media track immediately.",
    ],
  },
  {
    title: "Invitation links",
    tone: "#4C9BFF",
    items: [
      "Invitations are always learner-scoped. Redeeming one can never grant instructor or admin access.",
      "Every invitation carries an expiry date and a maximum number of uses.",
      "Instructors can revoke an invitation at any moment; revoked links stop working instantly.",
      "Opening an invitation never triggers a device permission request.",
    ],
  },
  {
    title: "Instructor accounts",
    tone: "#C77DFF",
    items: [
      "The instructor console is a separate, private area protected by a password and a time-based one-time code (TOTP).",
      "Passwords are stored as salted scrypt hashes; sessions use HTTP-only, SameSite cookies over HTTPS.",
      "Sign-in attempts — successful and failed — and all classroom access are written to an audit log.",
      "No secrets, keys, or credentials are ever embedded in the frontend bundle.",
    ],
  },
  {
    title: "Your controls",
    tone: "#FF3D9A",
    items: [
      "Export everything we hold about you as JSON from the Progress page.",
      "Clear progress for any lesson, or your entire flashcard history, at any time.",
      "Decline or withdraw camera consent at any point without losing access to any lesson.",
      "Contact the site owner to request deletion of your learner record.",
    ],
  },
];

export default function PrivacyPage() {
  return (
    <>
      <SiteHeader variant="app" />
      <main id="main" className="mx-auto max-w-4xl px-4 pb-20 pt-28 sm:px-6 lg:px-8">
        <SectionLabel tone="#C77DFF">개인정보 처리방침 · Privacy practices</SectionLabel>
        <h1 className="font-display text-3xl font-black leading-tight text-hanji-50 sm:text-[46px]">
          Privacy, written so you can actually read it.
        </h1>
        <p className="mt-4 text-[15.5px] leading-relaxed text-mute-300">
          SeoulStep is operated by SeoulStep Learning. This page explains what the service does with
          your data and your devices, in full. If anything here is unclear, ask us — the contact
          form reaches the site owner directly.
        </p>

        <div className="mt-10 space-y-4">
          {SECTIONS.map((s, i) => (
            <Reveal key={s.title} delay={i * 50}>
              <section className="card p-6">
                <div className="flex items-center gap-3">
                  <span className="h-8 w-1 rounded-full" style={{ background: s.tone }} />
                  <h2 className="font-display text-xl font-bold text-hanji-50">{s.title}</h2>
                </div>
                <ul className="mt-4 space-y-2.5">
                  {s.items.map((it) => (
                    <li key={it} className="flex gap-3 text-[14px] leading-relaxed text-mute-300">
                      <span
                        className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full"
                        style={{ background: s.tone }}
                      />
                      <span>{it}</span>
                    </li>
                  ))}
                </ul>
              </section>
            </Reveal>
          ))}
        </div>

        <div className="mt-8 rounded-3xl border border-hanji-200/12 bg-ink-900/60 p-6">
          <h2 className="font-display text-xl font-bold text-hanji-50">If recording is ever added</h2>
          <p className="mt-2 text-[14px] leading-relaxed text-mute-300">
            It is not part of the product today. If that ever changes, it will require separate,
            explicit, per-session consent from every participant — never bundled into a general
            terms update — and a clear, permanent recording indicator will be shown to everyone in
            the room for the entire duration. Declining will never reduce access to the class.
          </p>
        </div>

        <div className="mt-8 flex flex-col items-start justify-between gap-4 rounded-3xl border border-celadon-500/25 bg-celadon-500/8 p-6 sm:flex-row sm:items-center">
          <p className="text-[14px] leading-relaxed text-hanji-100">
            Questions, data requests, or a concern about how something behaved? Tell the site owner
            directly — you'll get a human reply.
          </p>
          <div className="flex shrink-0 gap-2">
            <LinkButton href="/contact">Contact the owner</LinkButton>
            <Link
              href="/learn"
              className="inline-flex items-center rounded-full border border-hanji-200/18 px-5 py-2.5 text-sm font-semibold text-hanji-100 transition hover:border-celadon-500/60"
            >
              Back to learning
            </Link>
          </div>
        </div>

        <p className="mt-6 text-[12px] text-mute-400">
          Last updated {new Date().toLocaleDateString(undefined, { month: "long", year: "numeric" })}.
          Transport is HTTPS everywhere; media is encrypted with DTLS-SRTP.
        </p>
      </main>
      <SiteFooter />
    </>
  );
}