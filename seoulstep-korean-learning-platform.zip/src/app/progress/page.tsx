"use client";

import Link from "next/link";
import { useState } from "react";
import { BADGES, LESSONS, TRACKS } from "@/lib/curriculum";
import { formatRelative } from "@/lib/badges";
import { useProgress } from "@/lib/learner-client";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";
import { Button, Chip, LinkButton, ProgressRing, SectionLabel, Toast, cx } from "@/components/ui";

export default function ProgressPage() {
  const { data, loading, error, refresh } = useProgress();
  const [busy, setBusy] = useState<string | null>(null);
  const [toast, setToast] = useState<{ msg: string; tone: string } | null>(null);
  const [undo, setUndo] = useState<{ lessonId: string; title: string } | null>(null);

  const byLesson = new Map(data?.progress.map((p) => [p.lessonId, p]) ?? []);
  const earned = new Map(data?.badges.map((b) => [b.badgeId, b.earnedAt]) ?? []);
  const pct = data ? Math.round((data.stats.completed / data.stats.totalLessons) * 100) : 0;

  const perTrack = TRACKS.map((t) => {
    const ls = LESSONS.filter((l) => l.track === t.id);
    const done = ls.filter((l) => byLesson.get(l.id)?.status === "completed").length;
    const avg =
      ls.reduce((n, l) => n + (byLesson.get(l.id)?.bestScore ?? 0), 0) / (ls.length || 1);
    return { ...t, done, total: ls.length, avg: Math.round(avg) };
  });

  const maxMinutes = Math.max(
    1,
    ...TRACKS.map((t) =>
      LESSONS.filter((l) => l.track === t.id).reduce(
        (n, l) => n + (byLesson.get(l.id)?.secondsSpent ?? 0),
        0,
      ),
    ),
  );

  async function resetLesson(lessonId: string, title: string) {
    setBusy(lessonId);
    try {
      await fetch(`/api/progress?lessonId=${encodeURIComponent(lessonId)}`, { method: "DELETE" });
      setUndo({ lessonId, title });
      setToast({ msg: `Progress cleared for “${title}”.`, tone: "#F5B841" });
      await refresh();
    } catch {
      setToast({ msg: "Couldn't clear that lesson. Try again.", tone: "#FF4D5E" });
    } finally {
      setBusy(null);
      setTimeout(() => {
        setToast(null);
        setUndo(null);
      }, 6000);
    }
  }

  function exportData() {
    if (!data) return;
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "seoulstep-progress.json";
    a.click();
    URL.revokeObjectURL(url);
    setToast({ msg: "Your data was exported as JSON.", tone: "#3ED6B0" });
    setTimeout(() => setToast(null), 2600);
  }

  return (
    <>
      <SiteHeader variant="app" />
      <main id="main" className="mx-auto max-w-7xl px-4 pb-20 pt-28 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-5">
          <div>
            <SectionLabel tone="#C77DFF">진도 · Progress</SectionLabel>
            <h1 className="font-display text-3xl font-black leading-tight text-hanji-50 sm:text-[42px]">
              Everything you've earned.
            </h1>
            <p className="mt-2 max-w-xl text-[15px] text-mute-300">
              Only what's necessary is stored: a display name, your lesson positions and scores.
              Export or clear it whenever you like.
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={exportData} disabled={!data}>
              Export my data
            </Button>
            <LinkButton href="/learn/tracks">Keep learning</LinkButton>
          </div>
        </div>

        {error && (
          <p className="mt-6 rounded-2xl border border-dancheong-500/40 bg-dancheong-500/10 px-4 py-3 text-sm text-dancheong-400">
            {error}
          </p>
        )}

        {/* Stat band */}
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              label: "Course complete",
              value: `${pct}%`,
              sub: `${data?.stats.completed ?? 0} of ${data?.stats.totalLessons ?? LESSONS.length} lessons`,
              tone: "#3ED6B0",
              ring: pct,
            },
            {
              label: "Average quiz score",
              value: `${data?.stats.averageScore ?? 0}%`,
              sub: "across completed lessons",
              tone: "#F5B841",
              ring: data?.stats.averageScore ?? 0,
            },
            {
              label: "Time studied",
              value: `${data?.stats.minutes ?? 0}m`,
              sub: "tracked inside lessons",
              tone: "#4C9BFF",
              ring: Math.min(100, ((data?.stats.minutes ?? 0) / 120) * 100),
            },
            {
              label: "Cards in rotation",
              value: `${data?.stats.cardsSeen ?? 0}`,
              sub: `${data?.stats.cardsDue ?? 0} due right now`,
              tone: "#FF3D9A",
              ring: ((data?.stats.cardsSeen ?? 0) / 24) * 100,
            },
          ].map((s) => (
            <div key={s.label} className="card flex items-center gap-4 p-5">
              <ProgressRing value={loading ? 0 : s.ring} size={56} tone={s.tone} label="" />
              <div>
                <p className="text-[11px] uppercase tracking-widest text-mute-400">{s.label}</p>
                <p className="font-display text-2xl font-black" style={{ color: s.tone }}>
                  {s.value}
                </p>
                <p className="text-[11.5px] text-mute-400">{s.sub}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 grid gap-5 lg:grid-cols-[1.25fr_1fr]">
          {/* Track breakdown */}
          <div className="card p-5 sm:p-6">
            <h2 className="font-display text-xl font-bold text-hanji-50">By track</h2>
            <p className="mt-1 text-[12.5px] text-mute-400">
              Bars show lessons finished; the label shows your average best score.
            </p>
            <ul className="mt-5 space-y-4">
              {perTrack.map((t) => {
                const p = Math.round((t.done / t.total) * 100);
                const seconds = LESSONS.filter((l) => l.track === t.id).reduce(
                  (n, l) => n + (byLesson.get(l.id)?.secondsSpent ?? 0),
                  0,
                );
                return (
                  <li key={t.id}>
                    <div className="flex items-baseline justify-between gap-3">
                      <span className="flex items-center gap-2">
                        <span
                          className="grid h-6 w-6 place-items-center rounded-md font-display text-[12px] font-black"
                          style={{ background: `${t.hue}22`, color: t.hue }}
                        >
                          {t.glyph}
                        </span>
                        <span className="text-[14px] font-semibold text-hanji-50">{t.name}</span>
                        <span className="text-[11.5px] text-mute-400">{t.nameKo}</span>
                      </span>
                      <span className="text-[12px] text-mute-400">
                        {t.done}/{t.total} · avg {t.avg}% · {Math.round(seconds / 60)}m
                      </span>
                    </div>
                    <div className="mt-2 flex items-center gap-2">
                      <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-ink-700">
                        <div
                          className="h-full rounded-full transition-[width] duration-1000"
                          style={{
                            width: `${p}%`,
                            background: `linear-gradient(90deg, ${t.hue}, ${t.hue}88)`,
                          }}
                        />
                      </div>
                      <span
                        className="w-9 text-right text-[11px] font-bold"
                        style={{ color: t.hue }}
                      >
                        {p}%
                      </span>
                    </div>
                    <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-ink-800">
                      <div
                        className="h-full rounded-full bg-hanbok-500/60 transition-[width] duration-1000"
                        style={{ width: `${(seconds / maxMinutes) * 100}%` }}
                        title="Relative time spent"
                      />
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>

          {/* Badges */}
          <div className="card p-5 sm:p-6">
            <div className="flex items-baseline justify-between">
              <h2 className="font-display text-xl font-bold text-hanji-50">Badges</h2>
              <span className="text-[12px] text-mute-400">
                {earned.size}/{BADGES.length}
              </span>
            </div>
            <ul className="mt-5 grid grid-cols-2 gap-3">
              {BADGES.map((b) => {
                const at = earned.get(b.id);
                return (
                  <li
                    key={b.id}
                    className={cx(
                      "rounded-2xl border p-3 transition-all duration-500",
                      at ? "bg-ink-800" : "border-hanji-200/10 bg-ink-900/40",
                    )}
                    style={at ? { borderColor: `${b.hue}66` } : undefined}
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className={cx(
                          "grid h-9 w-9 shrink-0 place-items-center rounded-full font-display text-base font-black",
                          !at && "opacity-30 grayscale",
                        )}
                        style={{ background: `${b.hue}22`, color: b.hue }}
                      >
                        {b.glyph}
                      </span>
                      <div className="min-w-0">
                        <p
                          className={cx(
                            "truncate text-[12.5px] font-bold",
                            at ? "text-hanji-50" : "text-mute-400",
                          )}
                        >
                          {b.name}
                        </p>
                        <p className="truncate text-[10.5px] text-mute-400">
                          {at ? formatRelative(at) : b.desc}
                        </p>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>

        {/* Lesson log */}
        <div className="card mt-5 overflow-hidden p-5 sm:p-6">
          <h2 className="font-display text-xl font-bold text-hanji-50">Lesson log</h2>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[620px] text-left text-[13px]">
              <thead>
                <tr className="border-b border-hanji-200/12 text-[10.5px] uppercase tracking-widest text-mute-400">
                  <th className="pb-2.5 pr-3 font-semibold">Lesson</th>
                  <th className="pb-2.5 pr-3 font-semibold">Track</th>
                  <th className="pb-2.5 pr-3 font-semibold">Status</th>
                  <th className="pb-2.5 pr-3 font-semibold">Best</th>
                  <th className="pb-2.5 pr-3 font-semibold">Updated</th>
                  <th className="pb-2.5 font-semibold sr-only">Actions</th>
                </tr>
              </thead>
              <tbody>
                {LESSONS.map((l) => {
                  const p = byLesson.get(l.id);
                  const t = TRACKS.find((x) => x.id === l.track)!;
                  return (
                    <tr key={l.id} className="border-b border-hanji-200/6 last:border-0">
                      <td className="py-3 pr-3">
                        <Link
                          href={`/learn/${l.id}`}
                          className="font-semibold text-hanji-50 hover:text-celadon-400"
                        >
                          {l.title}
                        </Link>
                      </td>
                      <td className="py-3 pr-3">
                        <Chip tone={t.hue} className="!text-[9.5px]">
                          {t.name}
                        </Chip>
                      </td>
                      <td className="py-3 pr-3">
                        {p?.status === "completed" ? (
                          <span className="font-semibold text-celadon-400">Completed</span>
                        ) : p ? (
                          <span className="text-gold-400">Step {p.step + 1}</span>
                        ) : (
                          <span className="text-mute-400">Not started</span>
                        )}
                      </td>
                      <td className="py-3 pr-3 text-hanji-100">{p ? `${p.bestScore}%` : "—"}</td>
                      <td className="py-3 pr-3 text-mute-400">
                        {p ? formatRelative(p.updatedAt) : "—"}
                      </td>
                      <td className="py-3 text-right">
                        {p && (
                          <button
                            onClick={() => resetLesson(l.id, l.title)}
                            disabled={busy === l.id}
                            className="rounded-full border border-hanji-200/12 px-3 py-1 text-[11.5px] text-mute-400 transition hover:border-dancheong-500/60 hover:text-dancheong-400 disabled:opacity-40"
                          >
                            {busy === l.id ? "Clearing…" : "Clear"}
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </main>
      <SiteFooter />
      {toast && (
        <div className="fixed bottom-5 left-1/2 z-[120] flex -translate-x-1/2 items-center gap-3 rounded-full border border-hanji-200/20 bg-ink-850 px-4 py-2.5 shadow-2xl pop">
          <span className="text-sm font-semibold" style={{ color: toast.tone }}>
            {toast.msg}
          </span>
          {undo && (
            <button
              onClick={() => {
                setToast(null);
                setUndo(null);
              }}
              className="rounded-full bg-hanji-200/10 px-3 py-1 text-[12px] font-bold text-hanji-100 hover:bg-hanji-200/20"
            >
              Dismiss
            </button>
          )}
        </div>
      )}
      {!toast && loading && (
        <Toast message="Loading your progress…" tone="#8E9AB4" />
      )}
    </>
  );
}