import type { MetadataRoute } from "next";
import { LESSONS } from "@/lib/curriculum";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_SITE_URL || "https://seoulstep.study";
  const now = new Date();
  const routes = ["", "/learn", "/learn/tracks", "/flashcards", "/progress", "/classroom", "/privacy", "/contact"].map(
    (path) => ({
      url: `${base}${path}`,
      lastModified: now,
      changeFrequency: "weekly" as const,
      priority: path === "" ? 1 : 0.7,
    }),
  );
  const lessons = LESSONS.map((l) => ({
    url: `${base}/learn/${l.id}`,
    lastModified: now,
    changeFrequency: "monthly" as const,
    priority: 0.6,
  }));
  return [...routes, ...lessons];
}