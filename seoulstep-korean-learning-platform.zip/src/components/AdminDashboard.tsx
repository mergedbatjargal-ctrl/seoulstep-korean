"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { LESSONS } from "@/lib/curriculum";
import { formatRelative } from "@/lib/badges";
import { Button, Chip, Modal, Toast, cx } from "@/components/ui";

type Overview = {
  instructor: { id: string; name: string; email: string | null };
  classes: {
    id: string;
    code: string;
    title: string;
    titleKo: string;
    status: string;
    startsAt: string;
    lessonId: string | null;
    joined: number;
    totalEver: number;
    camerasOn: number;
    consented: number;
  }[];
  attendance: {
    id: string;
    classId: string;
    userId: string;
    displayName: string;
    joinedAt: string;
    leftAt: string | null;
    cameraOn: boolean;
    cameraConsentAt: string | null;
    handRaised: boolean;
  }[];
  liveStreams: { userId: string; classId: string; displayName: string; consentedAt: string | null }[];
  invitations: {
    id: string;
    token: string;
    label: string;
    lessonId: string | null;
    classId: string | null;
    scope: string;
    uses: number;
    maxUses: number;
    expiresAt: string | null;
    revokedAt: string | null;
    createdAt: string;
  }[];
  audit: {
    id: string;
    actorLabel: string;
    action: string;
    target: string | null;
    severity: string;
    ip: string | null;
    createdAt: string;
  }[];
  totals: { learners: number; liveNow: number; camerasLive: number };
};

type Tab = "overview" | "invitations" | "audit";

const SEVERITY: Record<string, string> = {
  info: "#8E9AB4",
  notice: "#4C9BFF",
  warning: "#F5B841",
};

export function AdminDashboard({ demoMode = false }: { demoMode?: boolean }) {
  const router = useRouter();
  const [data, setData] = useState<Overview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("overview");
  const [activeClass, setActiveClass] = useState<string | null>(null);
  const [toast, setToast] = useState<{ msg: string; tone: string } | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [detail, setDetail] = useState<Overview["attendance"][number] | null>(null);

  const [streams, setStreams] = useState<Record<string, MediaStream>>({});
  const pcsRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const signalTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const videoRefs = useRef<Map<string, HTMLVideoElement | null>>(new Map());

  const flash = (msg: string, tone = "#3ED6B0") => {
    setToast({ msg, tone });
    setTimeout(() => setToast(null), 2600);
  };

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/overview", { cache: "no-store" });
      if (res.status === 403) {
        router.refresh();
        return;
      }
      const json = await res.json();
      if (!res.ok || !json.ok) throw new Error(json?.message ?? "bad");
      setData(json as Overview);
      setError(null);
      setActiveClass((prev) => {
        if (prev) return prev;
        const live = (json as Overview).classes.find((c) => c.status === "live");
        return live?.id ?? (json as Overview).classes[0]?.id ?? null;
      });
    } catch {
      setError("The dashboard couldn't be loaded. It will retry automatically.");
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    void load();
    const t = setInterval(() => void load(), 6000);
    return () => clearInterval(t);
  }, [load]);

  /* ── Receive learner streams (only those the learner enabled) ── */
  useEffect(() => {
    if (!activeClass || !data) return;
    const instructorId = data.instructor.id;

    const teardown = () => {
      pcsRef.current.forEach((pc) => pc.close());
      pcsRef.current.clear();
      setStreams({});
      if (signalTimer.current) clearInterval(signalTimer.current);
      signalTimer.current = null;
    };

    const poll = async () => {
      try {
        const res = await fetch(`/api/classroom/${activeClass}/signal`, { cache: "no-store" });
        const json = await res.json();
        for (const msg of json?.messages ?? []) {
          const from = msg.from as string;
          if (msg.kind === "offer") {
            pcsRef.current.get(from)?.close();
            const pc = new RTCPeerConnection({
              iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
            });
            pcsRef.current.set(from, pc);
            pc.ontrack = (e) => {
              const [stream] = e.streams;
              if (stream) setStreams((prev) => ({ ...prev, [from]: stream }));
            };
            pc.onicecandidate = (e) => {
              if (e.candidate) {
                void fetch(`/api/classroom/${activeClass}/signal`, {
                  method: "POST",
                  headers: { "content-type": "application/json" },
                  body: JSON.stringify({ to: from, kind: "ice", payload: e.candidate.toJSON() }),
                });
              }
            };
            pc.onconnectionstatechange = () => {
              if (["failed", "closed", "disconnected"].includes(pc.connectionState)) {
                setStreams((prev) => {
                  const next = { ...prev };
                  delete next[from];
                  return next;
                });
              }
            };
            await pc.setRemoteDescription(new RTCSessionDescription(msg.payload));
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
            await fetch(`/api/classroom/${activeClass}/signal`, {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ to: from, kind: "answer", payload: answer }),
            });
          } else if (msg.kind === "ice") {
            const pc = pcsRef.current.get(from);
            if (pc) {
              try {
                await pc.addIceCandidate(new RTCIceCandidate(msg.payload));
              } catch {
                /* stale candidate */
              }
            }
          } else if (msg.kind === "bye") {
            pcsRef.current.get(from)?.close();
            pcsRef.current.delete(from);
            setStreams((prev) => {
              const next = { ...prev };
              delete next[from];
              return next;
            });
          }
        }
      } catch {
        /* transient */
      }
    };

    void poll();
    signalTimer.current = setInterval(poll, 2000);
    void instructorId;
    return teardown;
  }, [activeClass, data]);

  useEffect(() => {
    Object.entries(streams).forEach(([id, stream]) => {
      const el = videoRefs.current.get(id);
      if (el && el.srcObject !== stream) el.srcObject = stream;
    });
  }, [streams]);

  async function signOut() {
    await fetch("/api/auth/admin/logout", { method: "POST" });
    router.refresh();
  }

  async function inviteAction(id: string, action: "revoke" | "restore") {
    const res = await fetch("/api/admin/invitations", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id, action }),
    });
    if (res.ok) {
      flash(action === "revoke" ? "Invitation revoked." : "Invitation restored for 7 days.");
      void load();
    } else flash("That action failed. Try again.", "#FF4D5E");
  }

  async function inviteDelete(id: string) {
    const res = await fetch(`/api/admin/invitations?id=${encodeURIComponent(id)}`, {
      method: "DELETE",
    });
    if (res.ok) {
      flash("Invitation deleted.", "#F5B841");
      void load();
    } else flash("Couldn't delete that invitation.", "#FF4D5E");
  }

  function copyLink(token: string) {
    const url = `${window.location.origin}/join/${token}`;
    navigator.clipboard?.writeText(url).then(
      () => flash("Invitation link copied."),
      () => flash(url, "#8E9AB4"),
    );
  }

  const klass = data?.classes.find((c) => c.id === activeClass) ?? null;
  const consentedStreams = (data?.liveStreams ?? []).filter((s) => s.classId === activeClass);
  const rosterForClass = (data?.attendance ?? []).filter((a) => a.classId === activeClass);
  const presentRoster = rosterForClass.filter((a) => !a.leftAt);

  return (
    <div className="mx-auto max-w-7xl px-4 pb-20 pt-24 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-[11px] font-bold uppercase tracking-[0.28em] text-hanbok-400">
            관리자 대시보드 · Instructor console
          </p>
          <h1 className="mt-1 font-display text-3xl font-black text-hanji-50">
            {data?.instructor.name ?? "…"}
          </h1>
          <p className="text-[12.5px] text-mute-400">
            {data?.instructor.email} · MFA verified · session audited
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => void load()}>
            Refresh
          </Button>
          <Button variant="danger" onClick={signOut}>
            Sign out
          </Button>
        </div>
      </div>

      {error && (
        <p className="mt-5 rounded-2xl border border-dancheong-500/40 bg-dancheong-500/10 px-4 py-3 text-sm text-dancheong-400">
          {error}
        </p>
      )}

      {demoMode && (
        <div className="mt-5 flex flex-wrap items-start gap-3 rounded-2xl border border-gold-500/45 bg-gold-500/10 px-4 py-3">
          <span aria-hidden className="mt-0.5">🔐</span>
          <p className="min-w-0 flex-1 text-[12.5px] leading-relaxed text-gold-400">
            <strong className="font-bold">Demo mode.</strong> This deployment is using the seeded
            sandbox instructor account, so its credentials are shown on the sign-in screen. Before
            real use, set <code className="rounded bg-ink-900 px-1">ADMIN_PASSWORD</code> and{" "}
            <code className="rounded bg-ink-900 px-1">ADMIN_TOTP_SECRET</code> — that instantly
            removes the credentials panel and the code helper. No learner data is exposed here, and
            no control exists to enable a learner's camera.
          </p>
        </div>
      )}

      {/* Stats */}
      <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          ["Learners", data?.totals.learners ?? 0, "#3ED6B0", "accounts with progress"],
          ["In session now", data?.totals.liveNow ?? 0, "#4C9BFF", "across all classes"],
          ["Cameras live", data?.totals.camerasLive ?? 0, "#FF4D5E", "learner-consented only"],
          [
            "Active invites",
            (data?.invitations ?? []).filter((i) => !i.revokedAt && (!i.expiresAt || new Date(i.expiresAt) > new Date())).length,
            "#F5B841",
            "learner scope only",
          ],
        ].map(([label, value, tone, sub]) => (
          <div key={label as string} className="card p-5">
            <p className="text-[11px] uppercase tracking-widest text-mute-400">{label as string}</p>
            <p className="mt-1 font-display text-3xl font-black" style={{ color: tone as string }}>
              {loading ? "—" : (value as number)}
            </p>
            <p className="text-[11.5px] text-mute-400">{sub as string}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="mt-7 flex gap-2 border-b border-hanji-200/10">
        {(
          [
            ["overview", "Classes & streams"],
            ["invitations", "Invitations"],
            ["audit", "Audit log"],
          ] as [Tab, string][]
        ).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={cx(
              "relative px-4 py-2.5 text-[13.5px] font-semibold transition-colors",
              tab === id ? "text-hanji-50" : "text-mute-400 hover:text-hanji-100",
            )}
          >
            {label}
            <span
              className={cx(
                "absolute inset-x-2 -bottom-px h-0.5 origin-left rounded-full bg-[linear-gradient(90deg,#4C9BFF,#C77DFF)] transition-transform duration-300",
                tab === id ? "scale-x-100" : "scale-x-0",
              )}
            />
          </button>
        ))}
      </div>

      {/* OVERVIEW */}
      {tab === "overview" && (
        <div className="mt-6 grid gap-5 lg:grid-cols-[300px_1fr]">
          <div className="space-y-2">
            {(data?.classes ?? []).map((c) => (
              <button
                key={c.id}
                onClick={() => setActiveClass(c.id)}
                className={cx(
                  "w-full rounded-2xl border p-4 text-left transition-all duration-300",
                  activeClass === c.id
                    ? "border-hanbok-500/60 bg-ink-800"
                    : "border-hanji-200/10 bg-ink-900/50 hover:bg-ink-800/60",
                )}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-display text-[15px] font-bold text-hanji-50">{c.title}</span>
                  <Chip tone={c.status === "live" ? "#FF4D5E" : "#8E9AB4"} className="!text-[9px]">
                    {c.status}
                  </Chip>
                </div>
                <p className="mt-1 text-[11.5px] text-mute-400">
                  {c.code} · {new Date(c.startsAt).toLocaleString(undefined, {
                    month: "short",
                    day: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
                <div className="mt-3 flex gap-3 text-[11.5px]">
                  <span className="text-hanbok-400">{c.joined} present</span>
                  <span className="text-dancheong-400">{c.camerasOn} cameras</span>
                  <span className="text-mute-400">{c.consented} consented</span>
                </div>
              </button>
            ))}
            {(data?.classes ?? []).length === 0 && !loading && (
              <p className="rounded-2xl border border-hanji-200/10 bg-ink-900/50 p-5 text-[13px] text-mute-400">
                No classes scheduled.
              </p>
            )}
          </div>

          <div className="space-y-5">
            {/* Video grid */}
            <div className="card p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="font-display text-lg font-bold text-hanji-50">
                    Shared video · {klass?.title ?? "—"}
                  </h2>
                  <p className="mt-0.5 text-[12px] text-mute-400">
                    A tile carries live video only when that learner joined this session and enabled
                    their own camera. Nothing is recorded, and no control here can turn one on.
                  </p>
                </div>
                <Chip tone="#FF4D5E">
                  {consentedStreams.length} live · {presentRoster.length} present
                </Chip>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                {consentedStreams.map((s) => (
                  <div
                    key={s.userId}
                    className="relative aspect-video overflow-hidden rounded-2xl border-2 border-dancheong-500/60 bg-ink-950"
                  >
                    <video
                      ref={(el) => {
                        videoRefs.current.set(s.userId, el);
                      }}
                      autoPlay
                      playsInline
                      muted
                      className={cx(
                        "h-full w-full object-cover transition-opacity",
                        streams[s.userId] ? "opacity-100" : "opacity-0",
                      )}
                    />
                    {!streams[s.userId] && (
                      <div className="absolute inset-0 grid place-items-center">
                        <div className="text-center">
                          <div className="mx-auto h-8 w-8 animate-[spinSlow_2.4s_linear_infinite] rounded-full border-2 border-dancheong-500/40 border-t-dancheong-500" />
                          <p className="mt-3 text-[11.5px] text-mute-400">
                            Negotiating encrypted channel…
                          </p>
                        </div>
                      </div>
                    )}
                    <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 bg-[linear-gradient(0deg,rgba(6,8,13,0.92),transparent)] px-3 py-2">
                      <span className="truncate text-[12px] font-bold text-hanji-50">
                        {s.displayName}
                      </span>
                      <span className="flex items-center gap-1.5 rounded-full bg-dancheong-500/25 px-2 py-0.5 text-[10px] font-bold text-dancheong-400">
                        <span className="h-1.5 w-1.5 rounded-full bg-dancheong-500 live-ring" />
                        consented {s.consentedAt ? formatRelative(s.consentedAt) : ""}
                      </span>
                    </div>
                  </div>
                ))}

                {/* Present learners who have NOT enabled a camera occupy an inert slot. */}
                {presentRoster
                  .filter((a) => !a.cameraOn)
                  .map((a) => (
                    <div
                      key={a.id}
                      className="relative grid aspect-video place-items-center overflow-hidden rounded-2xl border border-dashed border-hanji-200/18 bg-[linear-gradient(155deg,rgba(19,26,42,0.7),rgba(6,8,13,0.9))]"
                    >
                      <div className="text-center">
                        <span className="mx-auto grid h-11 w-11 place-items-center rounded-full border border-hanji-200/20 bg-ink-800">
                          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="#8E9AB4" strokeWidth="1.8" strokeLinecap="round">
                            <path d="M23 7l-7 5 7 5V7ZM1 5h14v14H1V5Z" />
                            <path d="M3 3l18 18" />
                          </svg>
                        </span>
                        <p className="mt-2.5 text-[12.5px] font-bold text-hanji-100">
                          {a.displayName}
                        </p>
                        <p className="text-[10.5px] text-mute-400">Camera off — nothing shared</p>
                      </div>
                      <span className="absolute bottom-2 right-2.5 text-[10px] text-mute-400">
                        joined {formatRelative(a.joinedAt)}
                      </span>
                    </div>
                  ))}

                {presentRoster.length === 0 && (
                  <div className="col-span-full rounded-2xl border border-hanji-200/12 bg-ink-900/50 p-8 text-center">
                    <p className="font-display text-lg font-bold text-hanji-100">
                      Nobody is in this session yet
                    </p>
                    <p className="mx-auto mt-2 max-w-md text-[13px] leading-relaxed text-mute-400">
                      Tiles appear here as learners join. Cameras stay off unless a learner
                      explicitly turns one on.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Attendance */}
            <div className="card overflow-hidden p-5">
              <h2 className="font-display text-lg font-bold text-hanji-50">
                Attendance &amp; camera consent
              </h2>
              <div className="mt-4 overflow-x-auto">
                <table className="w-full min-w-[640px] text-left text-[13px]">
                  <thead>
                    <tr className="border-b border-hanji-200/12 text-[10.5px] uppercase tracking-widest text-mute-400">
                      <th className="pb-2.5 pr-3 font-semibold">Learner</th>
                      <th className="pb-2.5 pr-3 font-semibold">Joined</th>
                      <th className="pb-2.5 pr-3 font-semibold">Status</th>
                      <th className="pb-2.5 pr-3 font-semibold">Camera consent</th>
                      <th className="pb-2.5 font-semibold">Detail</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rosterForClass.map((a) => (
                      <tr key={a.id} className="border-b border-hanji-200/6 last:border-0">
                        <td className="py-3 pr-3 font-semibold text-hanji-50">{a.displayName}</td>
                        <td className="py-3 pr-3 text-mute-400">{formatRelative(a.joinedAt)}</td>
                        <td className="py-3 pr-3">
                          {a.leftAt ? (
                            <span className="text-mute-400">Left {formatRelative(a.leftAt)}</span>
                          ) : (
                            <span className="font-semibold text-celadon-400">Present</span>
                          )}
                          {a.handRaised && <span className="ml-2">✋</span>}
                        </td>
                        <td className="py-3 pr-3">
                          {a.cameraOn ? (
                            <span className="rounded-full bg-dancheong-500/18 px-2.5 py-1 text-[11px] font-bold text-dancheong-400">
                              On · consented {a.cameraConsentAt ? formatRelative(a.cameraConsentAt) : ""}
                            </span>
                          ) : a.cameraConsentAt ? (
                            <span className="text-[12px] text-gold-400">
                              Consented earlier, currently off
                            </span>
                          ) : (
                            <span className="text-[12px] text-mute-400">No consent given</span>
                          )}
                        </td>
                        <td className="py-3">
                          <button
                            onClick={() => setDetail(a)}
                            className="rounded-full border border-hanji-200/14 px-3 py-1 text-[11.5px] text-mute-300 transition hover:border-hanbok-500/60 hover:text-hanbok-400"
                          >
                            Open
                          </button>
                        </td>
                      </tr>
                    ))}
                    {rosterForClass.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-8 text-center text-mute-400">
                          Nobody has joined this session yet.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* INVITATIONS */}
      {tab === "invitations" && (
        <div className="mt-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="max-w-2xl text-[13.5px] leading-relaxed text-mute-300">
              Every invitation is created with{" "}
              <strong className="text-celadon-400">learner scope</strong>. There is no option,
              parameter, or API path that makes an invitation grant instructor access.
            </p>
            <Button variant="gold" onClick={() => setCreateOpen(true)}>
              + New invitation
            </Button>
          </div>

          <div className="mt-5 space-y-2.5">
            {(data?.invitations ?? []).map((i) => {
              const expired = i.expiresAt ? new Date(i.expiresAt) < new Date() : false;
              const dead = !!i.revokedAt || expired || i.uses >= i.maxUses;
              return (
                <div
                  key={i.id}
                  className={cx(
                    "card flex flex-wrap items-center gap-4 p-4",
                    dead && "opacity-70",
                  )}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-display text-[15px] font-bold text-hanji-50">
                        {i.label}
                      </span>
                      <Chip tone="#3ED6B0" className="!text-[9px]">
                        {i.scope} scope
                      </Chip>
                      {i.revokedAt ? (
                        <Chip tone="#FF4D5E" className="!text-[9px]">
                          revoked
                        </Chip>
                      ) : expired ? (
                        <Chip tone="#F5B841" className="!text-[9px]">
                          expired
                        </Chip>
                      ) : (
                        <Chip tone="#4C9BFF" className="!text-[9px]">
                          active
                        </Chip>
                      )}
                    </div>
                    <p className="mt-1 break-all font-mono text-[11.5px] text-mute-400">
                      /join/{i.token}
                    </p>
                    <p className="mt-1 text-[11.5px] text-mute-400">
                      {i.uses}/{i.maxUses} uses ·{" "}
                      {i.expiresAt
                        ? `expires ${new Date(i.expiresAt).toLocaleDateString()}`
                        : "no expiry"}{" "}
                      · created {formatRelative(i.createdAt)}
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => copyLink(i.token)}
                      className="rounded-full border border-hanji-200/14 px-3 py-1.5 text-[12px] font-semibold text-hanji-100 transition hover:border-celadon-500/60 hover:text-celadon-400"
                    >
                      Copy link
                    </button>
                    {i.revokedAt ? (
                      <button
                        onClick={() => inviteAction(i.id, "restore")}
                        className="rounded-full border border-celadon-500/40 px-3 py-1.5 text-[12px] font-semibold text-celadon-400 transition hover:bg-celadon-500/12"
                      >
                        Restore
                      </button>
                    ) : (
                      <button
                        onClick={() => inviteAction(i.id, "revoke")}
                        className="rounded-full border border-gold-500/40 px-3 py-1.5 text-[12px] font-semibold text-gold-400 transition hover:bg-gold-500/12"
                      >
                        Revoke
                      </button>
                    )}
                    <button
                      onClick={() => inviteDelete(i.id)}
                      className="rounded-full border border-dancheong-500/40 px-3 py-1.5 text-[12px] font-semibold text-dancheong-400 transition hover:bg-dancheong-500/12"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              );
            })}
            {(data?.invitations ?? []).length === 0 && (
              <p className="rounded-2xl border border-hanji-200/12 bg-ink-900/60 p-8 text-center text-sm text-mute-400">
                No invitations yet. Create one to share a lesson.
              </p>
            )}
          </div>
        </div>
      )}

      {/* AUDIT */}
      {tab === "audit" && (
        <div className="card mt-6 overflow-hidden p-5">
          <h2 className="font-display text-lg font-bold text-hanji-50">
            Audit log · sign-ins and classroom access
          </h2>
          <p className="mt-1 text-[12.5px] text-mute-400">
            Append-only. Includes failed sign-ins, MFA results, invitation changes, and every camera
            enable/disable event.
          </p>
          <div className="mt-4 max-h-[560px] overflow-y-auto">
            <ul className="space-y-1.5">
              {(data?.audit ?? []).map((l) => (
                <li
                  key={l.id}
                  className="flex flex-wrap items-center gap-3 rounded-xl border border-hanji-200/8 bg-ink-900/50 px-3.5 py-2.5"
                >
                  <span
                    className="h-2 w-2 shrink-0 rounded-full"
                    style={{ background: SEVERITY[l.severity] ?? "#8E9AB4" }}
                  />
                  <span className="font-mono text-[12px] font-semibold text-hanji-100">
                    {l.action}
                  </span>
                  <span className="text-[12px] text-mute-400">{l.actorLabel}</span>
                  {l.target && (
                    <span className="truncate text-[12px] text-mute-400">→ {l.target}</span>
                  )}
                  <span className="ml-auto shrink-0 text-[11.5px] text-mute-400">
                    {l.ip ? `${l.ip} · ` : ""}
                    {formatRelative(l.createdAt)}
                  </span>
                </li>
              ))}
              {(data?.audit ?? []).length === 0 && (
                <li className="rounded-xl border border-hanji-200/8 bg-ink-900/50 px-3.5 py-8 text-center text-[13px] text-mute-400">
                  Nothing logged yet.
                </li>
              )}
            </ul>
          </div>
        </div>
      )}

      {/* Create invitation */}
      <CreateInvite
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        classes={data?.classes ?? []}
        onCreated={(token) => {
          setCreateOpen(false);
          void load();
          copyLink(token);
        }}
      />

      {/* Attendance detail drawer */}
      {detail && (
        <div className="fixed inset-0 z-[100] flex justify-end">
          <div className="absolute inset-0 bg-ink-950/80 backdrop-blur-sm fade" onClick={() => setDetail(null)} />
          <aside className="relative h-full w-full max-w-md overflow-y-auto border-l border-hanji-200/12 bg-ink-850 p-6 pop">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[10.5px] uppercase tracking-[0.24em] text-mute-400">Learner</p>
                <h3 className="font-display text-2xl font-black text-hanji-50">
                  {detail.displayName}
                </h3>
              </div>
              <button
                onClick={() => setDetail(null)}
                aria-label="Close"
                className="rounded-full border border-hanji-200/15 p-1.5 text-mute-300 hover:text-dancheong-400"
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
                  <path d="M18 6 6 18M6 6l12 12" />
                </svg>
              </button>
            </div>
            <dl className="mt-6 space-y-3 text-[13.5px]">
              {[
                ["Joined", new Date(detail.joinedAt).toLocaleString()],
                ["Left", detail.leftAt ? new Date(detail.leftAt).toLocaleString() : "still present"],
                ["Camera now", detail.cameraOn ? "ON — learner enabled" : "off"],
                [
                  "Consent recorded",
                  detail.cameraConsentAt
                    ? new Date(detail.cameraConsentAt).toLocaleString()
                    : "never given",
                ],
                ["Hand raised", detail.handRaised ? "yes" : "no"],
                ["Learner id", detail.userId],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between gap-4 border-b border-hanji-200/8 pb-2.5">
                  <dt className="text-mute-400">{k}</dt>
                  <dd className="break-all text-right text-hanji-100">{v}</dd>
                </div>
              ))}
            </dl>
            <p className="mt-6 rounded-xl border border-hanji-200/12 bg-ink-900/60 p-4 text-[12.5px] leading-relaxed text-mute-400">
              There is no control on this dashboard that can start a learner's camera, unmute them,
              or capture anything. Media flows one way, from the learner's explicit action to this
              session only.
            </p>
          </aside>
        </div>
      )}

      {toast && <Toast message={toast.msg} tone={toast.tone} />}
    </div>
  );
}

function CreateInvite({
  open,
  onClose,
  classes,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  classes: { id: string; title: string }[];
  onCreated: (token: string) => void;
}) {
  const [label, setLabel] = useState("");
  const [lessonId, setLessonId] = useState("");
  const [classId, setClassId] = useState("");
  const [hours, setHours] = useState(168);
  const [maxUses, setMaxUses] = useState(50);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/invitations", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          label,
          lessonId: lessonId || null,
          classId: classId || null,
          expiresInHours: hours,
          maxUses,
        }),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        setError(json?.message ?? "Couldn't create that invitation.");
        return;
      }
      onCreated(json.invitation.token);
      setLabel("");
      setLessonId("");
      setClassId("");
    } catch {
      setError("Network problem — try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title="New learner invitation" tone="#F5B841" wide>
      <form onSubmit={submit} className="space-y-4">
        <p className="rounded-xl border border-celadon-500/30 bg-celadon-500/8 px-3 py-2.5 text-[12.5px] leading-relaxed text-celadon-400">
          Scope is fixed to <strong>learner</strong>. This link can open a lesson and a live session
          — it can never open this dashboard.
        </p>

        <div>
          <label htmlFor="inv-label" className="block text-[11px] font-semibold uppercase tracking-wider text-mute-400">
            Label
          </label>
          <input
            id="inv-label"
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="Spring cohort · week 1"
            className="mt-1.5 w-full rounded-xl border border-hanji-200/18 bg-ink-900 px-4 py-2.5 text-sm text-hanji-50 outline-none focus:border-gold-500"
          />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="inv-lesson" className="block text-[11px] font-semibold uppercase tracking-wider text-mute-400">
              Lesson
            </label>
            <select
              id="inv-lesson"
              value={lessonId}
              onChange={(e) => setLessonId(e.target.value)}
              className="mt-1.5 w-full rounded-xl border border-hanji-200/18 bg-ink-900 px-3 py-2.5 text-sm text-hanji-50 outline-none focus:border-gold-500"
            >
              <option value="">Full course</option>
              {LESSONS.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.title}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="inv-class" className="block text-[11px] font-semibold uppercase tracking-wider text-mute-400">
              Live session
            </label>
            <select
              id="inv-class"
              value={classId}
              onChange={(e) => setClassId(e.target.value)}
              className="mt-1.5 w-full rounded-xl border border-hanji-200/18 bg-ink-900 px-3 py-2.5 text-sm text-hanji-50 outline-none focus:border-gold-500"
            >
              <option value="">None</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.title}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="inv-hours" className="flex justify-between text-[11px] font-semibold uppercase tracking-wider text-mute-400">
              Expires in <span className="text-gold-400">{hours}h</span>
            </label>
            <input
              id="inv-hours"
              type="range"
              min={1}
              max={720}
              value={hours}
              onChange={(e) => setHours(Number(e.target.value))}
              className="mt-3 w-full"
            />
          </div>
          <div>
            <label htmlFor="inv-uses" className="flex justify-between text-[11px] font-semibold uppercase tracking-wider text-mute-400">
              Max learners <span className="text-gold-400">{maxUses}</span>
            </label>
            <input
              id="inv-uses"
              type="range"
              min={1}
              max={200}
              value={maxUses}
              onChange={(e) => setMaxUses(Number(e.target.value))}
              className="mt-3 w-full"
            />
          </div>
        </div>

        {error && (
          <p className="rounded-xl border border-dancheong-500/40 bg-dancheong-500/10 px-3 py-2 text-[13px] text-dancheong-400">
            {error}
          </p>
        )}

        <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" variant="gold" disabled={busy || !label.trim()}>
            {busy ? "Creating…" : "Create & copy link"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}