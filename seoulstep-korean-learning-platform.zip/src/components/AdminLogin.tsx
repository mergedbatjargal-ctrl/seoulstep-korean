"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Button, cx } from "@/components/ui";

export function AdminLogin({
  demo,
}: {
  demo: { email: string; password: string; secret: string } | null;
}) {
  const router = useRouter();
  const [step, setStep] = useState<1 | 2>(1);
  const [email, setEmail] = useState(demo?.email ?? "");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hint, setHint] = useState<string | null>(null);
  const [seconds, setSeconds] = useState(30 - (Math.floor(Date.now() / 1000) % 30));

  useEffect(() => {
    const t = setInterval(() => setSeconds(30 - (Math.floor(Date.now() / 1000) % 30)), 1000);
    return () => clearInterval(t);
  }, []);

  async function submitPassword(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/admin/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        setError(json?.message ?? "Sign-in failed.");
        return;
      }
      setStep(2);
    } catch {
      setError("Network problem — check your connection and try again.");
    } finally {
      setBusy(false);
    }
  }

  async function submitCode(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/admin/mfa", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ code }),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        setError(json?.message ?? "Verification failed.");
        return;
      }
      router.refresh();
    } catch {
      setError("Network problem — try again.");
    } finally {
      setBusy(false);
    }
  }

  async function revealCode() {
    try {
      const res = await fetch("/api/admin/demo-totp", { cache: "no-store" });
      const json = await res.json();
      if (json?.code) setHint(`Current one-time code: ${json.code}`);
      else setError(json?.message ?? "Code helper is disabled on this deployment.");
    } catch {
      setError("Couldn't reach the code helper.");
    }
  }

  return (
    <div className="relative mx-auto flex min-h-screen max-w-lg flex-col justify-center px-4 py-20 sm:px-6">
      <div className="aurora pointer-events-none absolute inset-0 -z-10 opacity-60" />

      <div className="grain relative overflow-hidden rounded-3xl border border-hanji-200/14 bg-[linear-gradient(155deg,rgba(27,36,54,0.92),rgba(10,13,21,0.96))] p-7 shadow-[0_50px_100px_-50px_rgba(0,0,0,1)] sm:p-9">
        <div className="relative flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-[linear-gradient(140deg,#4C9BFF,#C77DFF)] font-display text-lg font-black text-ink-950">
            서
          </span>
          <div>
            <h1 className="font-display text-xl font-black text-hanji-50">Instructor access</h1>
            <p className="text-[11.5px] uppercase tracking-[0.2em] text-mute-400">
              관리자 전용 · Restricted
            </p>
          </div>
        </div>

        <div className="relative mt-6 flex items-center gap-2">
          {[1, 2].map((s) => (
            <div key={s} className="flex flex-1 items-center gap-2">
              <span
                className={cx(
                  "grid h-7 w-7 place-items-center rounded-full text-[12px] font-black transition-all duration-500",
                  step >= s ? "bg-hanbok-500 text-ink-950" : "bg-ink-700 text-mute-400",
                )}
              >
                {s}
              </span>
              <span
                className={cx(
                  "text-[12px] font-semibold",
                  step >= s ? "text-hanji-100" : "text-mute-400",
                )}
              >
                {s === 1 ? "Password" : "One-time code"}
              </span>
              {s === 1 && <span className="h-px flex-1 bg-ink-600" />}
            </div>
          ))}
        </div>

        {step === 1 ? (
          <form onSubmit={submitPassword} className="relative mt-6">
            <label htmlFor="admin-email" className="block text-[11px] font-semibold uppercase tracking-wider text-mute-400">
              Instructor email
            </label>
            <input
              id="admin-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="username"
              className="mt-1.5 w-full rounded-xl border border-hanji-200/18 bg-ink-900 px-4 py-3 text-sm text-hanji-50 outline-none transition focus:border-hanbok-500"
            />
            <label htmlFor="admin-pass" className="mt-4 block text-[11px] font-semibold uppercase tracking-wider text-mute-400">
              Password
            </label>
            <input
              id="admin-pass"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              className="mt-1.5 w-full rounded-xl border border-hanji-200/18 bg-ink-900 px-4 py-3 text-sm text-hanji-50 outline-none transition focus:border-hanbok-500"
            />
            {error && (
              <p className="mt-3 rounded-xl border border-dancheong-500/40 bg-dancheong-500/10 px-3 py-2 text-[13px] text-dancheong-400">
                {error}
              </p>
            )}
            <Button type="submit" className="mt-5 w-full" size="lg" disabled={busy}>
              {busy ? "Checking…" : "Continue to verification"}
            </Button>
            <p className="mt-3 text-center text-[11.5px] text-mute-400">
              Two factors are mandatory. There is no bypass, and every attempt is written to the
              audit log.
            </p>
          </form>
        ) : (
          <form onSubmit={submitCode} className="relative mt-6">
            <p className="text-[13.5px] leading-relaxed text-mute-300">
              Enter the 6-digit code from your authenticator app. Codes rotate every 30 seconds.
            </p>
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
              inputMode="numeric"
              autoComplete="one-time-code"
              placeholder="000000"
              aria-label="One-time code"
              className="mt-4 w-full rounded-xl border border-hanji-200/18 bg-ink-900 px-4 py-4 text-center font-display text-3xl font-black tracking-[0.4em] text-hanji-50 outline-none transition focus:border-hanbok-500"
            />
            <div className="mt-2 h-1 overflow-hidden rounded-full bg-ink-700">
              <div
                className="h-full bg-hanbok-500 transition-[width] duration-1000 ease-linear"
                style={{ width: `${(seconds / 30) * 100}%` }}
              />
            </div>
            {hint && (
              <p className="mt-3 rounded-xl border border-celadon-500/40 bg-celadon-500/10 px-3 py-2 font-display text-[15px] font-bold text-celadon-400">
                {hint}
              </p>
            )}
            {error && (
              <p className="mt-3 rounded-xl border border-dancheong-500/40 bg-dancheong-500/10 px-3 py-2 text-[13px] text-dancheong-400">
                {error}
              </p>
            )}
            <Button type="submit" className="mt-5 w-full" size="lg" disabled={busy || code.length !== 6}>
              {busy ? "Verifying…" : "Verify and enter dashboard"}
            </Button>
            <button
              type="button"
              onClick={() => {
                setStep(1);
                setCode("");
                setError(null);
              }}
              className="mt-3 w-full text-center text-[12px] font-semibold text-mute-400 hover:text-hanji-100"
            >
              ← Back to password
            </button>
          </form>
        )}

        {demo && (
          <div className="relative mt-7 rounded-2xl border border-gold-500/30 bg-gold-500/8 p-4">
            <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-gold-500">
              Sandbox demo credentials
            </p>
            <p className="mt-2 text-[12.5px] leading-relaxed text-mute-300">
              This preview seeds one instructor account so the dashboard can be reviewed. In a real
              deployment <code className="rounded bg-ink-900 px-1">ADMIN_EMAIL</code>,{" "}
              <code className="rounded bg-ink-900 px-1">ADMIN_PASSWORD</code> and{" "}
              <code className="rounded bg-ink-900 px-1">ADMIN_TOTP_SECRET</code> come from the server
              environment and the helper below is disabled.
            </p>
            <dl className="mt-3 space-y-1 text-[12.5px]">
              <div className="flex gap-2">
                <dt className="w-20 text-mute-400">Email</dt>
                <dd className="font-mono text-hanji-100">{demo.email}</dd>
              </div>
              <div className="flex gap-2">
                <dt className="w-20 text-mute-400">Password</dt>
                <dd className="font-mono text-hanji-100">{demo.password}</dd>
              </div>
              <div className="flex gap-2">
                <dt className="w-20 text-mute-400">TOTP</dt>
                <dd className="break-all font-mono text-hanji-100">{demo.secret}</dd>
              </div>
            </dl>
            <button
              onClick={revealCode}
              className="mt-3 rounded-full border border-gold-500/40 px-3 py-1.5 text-[12px] font-semibold text-gold-400 transition hover:bg-gold-500/15"
            >
              Reveal current code (demo only, audited)
            </button>
          </div>
        )}
      </div>
    </div>
  );
}