"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { getLesson } from "@/lib/curriculum";
import { Button, Chip, cx } from "@/components/ui";
import { ensureLearner, type Learner } from "@/lib/learner-client";

type ClassInfo = {
  id: string;
  code: string;
  title: string;
  titleKo: string;
  status: string;
  startsAt: string;
  lessonId: string | null;
  instructorId: string | null;
};

type Peer = {
  userId: string;
  displayName: string;
  cameraOn: boolean;
  handRaised: boolean;
  joinedAt: string;
};

type Phase = "lobby" | "joined";
type CamState = "off" | "requesting" | "on" | "denied" | "error";

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
};

export function ClassroomRoom({ classId, instructorName }: { classId: string; instructorName: string }) {
  const [learner, setLearner] = useState<Learner | null>(null);
  const [info, setInfo] = useState<ClassInfo | null>(null);
  const [roster, setRoster] = useState<Peer[]>([]);
  const [phase, setPhase] = useState<Phase>("lobby");
  const [camState, setCamState] = useState<CamState>("off");
  const [micOn, setMicOn] = useState(false);
  const [hand, setHand] = useState(false);
  const [consentOpen, setConsentOpen] = useState(false);
  const [consentChecked, setConsentChecked] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [linkState, setLinkState] = useState<"idle" | "connecting" | "connected" | "unavailable">("idle");
  const [elapsed, setElapsed] = useState(0);

  const streamRef = useRef<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);

  /* ── boot ─────────────────────────────────────────────────── */
  useEffect(() => {
    let alive = true;
    (async () => {
      const l = await ensureLearner();
      if (!alive) return;
      if (!l) setError("We couldn't reach the server. Refresh to try again.");
      setLearner(l);
      try {
        const res = await fetch(`/api/classroom/${classId}`, { cache: "no-store" });
        const json = await res.json();
        if (!res.ok || !json.ok) {
          setError(json?.message ?? "That session could not be found.");
          return;
        }
        setInfo(json.class);
        setRoster(json.roster ?? []);
      } catch {
        setError("Network problem loading this session.");
      }
    })();
    return () => {
      alive = false;
    };
  }, [classId]);

  /* ── hard stop for all media ──────────────────────────────── */
  const stopAllMedia = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    pcRef.current?.getSenders().forEach((s) => s.track?.stop());
    pcRef.current?.close();
    pcRef.current = null;
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = null;
    setLinkState("idle");
  }, []);

  useEffect(() => {
    const onLeave = () => stopAllMedia();
    window.addEventListener("pagehide", onLeave);
    window.addEventListener("beforeunload", onLeave);
    return () => {
      window.removeEventListener("pagehide", onLeave);
      window.removeEventListener("beforeunload", onLeave);
      stopAllMedia();
      if (tickRef.current) clearInterval(tickRef.current);
    };
  }, [stopAllMedia]);

  useEffect(() => {
    if (phase !== "joined") return;
    tickRef.current = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => {
      if (tickRef.current) clearInterval(tickRef.current);
      tickRef.current = null;
    };
  }, [phase]);

  /* ── roster polling ───────────────────────────────────────── */
  useEffect(() => {
    if (phase !== "joined") return;
    const t = setInterval(async () => {
      try {
        const res = await fetch(`/api/classroom/${classId}`, { cache: "no-store" });
        const json = await res.json();
        if (json?.ok) setRoster(json.roster ?? []);
      } catch {
        /* transient */
      }
    }, 5000);
    return () => clearInterval(t);
  }, [phase, classId]);

  /* ── WebRTC publish to instructor only ────────────────────── */
  const startPublishing = useCallback(
    async (stream: MediaStream) => {
      if (!info?.instructorId || typeof RTCPeerConnection === "undefined") {
        setLinkState("unavailable");
        return;
      }
      try {
        setLinkState("connecting");
        const pc = new RTCPeerConnection(RTC_CONFIG);
        pcRef.current = pc;
        stream.getTracks().forEach((t) => pc.addTrack(t, stream));

        pc.onicecandidate = (e) => {
          if (e.candidate) {
            void fetch(`/api/classroom/${classId}/signal`, {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({
                to: info.instructorId,
                kind: "ice",
                payload: e.candidate.toJSON(),
              }),
            });
          }
        };
        pc.onconnectionstatechange = () => {
          if (pc.connectionState === "connected") setLinkState("connected");
          if (pc.connectionState === "failed" || pc.connectionState === "disconnected")
            setLinkState("unavailable");
        };

        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        await fetch(`/api/classroom/${classId}/signal`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ to: info.instructorId, kind: "offer", payload: offer }),
        });

        pollRef.current = setInterval(async () => {
          try {
            const res = await fetch(`/api/classroom/${classId}/signal`, { cache: "no-store" });
            const json = await res.json();
            for (const msg of json?.messages ?? []) {
              if (msg.kind === "answer" && !pc.currentRemoteDescription) {
                await pc.setRemoteDescription(new RTCSessionDescription(msg.payload));
              } else if (msg.kind === "ice") {
                try {
                  await pc.addIceCandidate(new RTCIceCandidate(msg.payload));
                } catch {
                  /* ignore stale candidates */
                }
              }
            }
          } catch {
            /* transient */
          }
        }, 2000);

        // If the instructor never answers, degrade to a clear status rather than hanging.
        setTimeout(() => {
          setLinkState((s) => (s === "connecting" ? "unavailable" : s));
        }, 15000);
      } catch {
        setLinkState("unavailable");
      }
    },
    [classId, info?.instructorId],
  );

  /* ── consented camera enable ──────────────────────────────── */
  async function enableCamera() {
    setError(null);
    setCamState("requesting");
    setConsentOpen(false);
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        setCamState("error");
        setError(
          "This browser doesn't expose a camera API. You can still take part with audio and text.",
        );
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: "user" },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => undefined);
      }
      setCamState("on");
      await fetch(`/api/classroom/${classId}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "camera", on: true, consent: true }),
      });
      void startPublishing(stream);
    } catch (err) {
      const name = (err as DOMException)?.name;
      if (name === "NotAllowedError" || name === "SecurityError") {
        setCamState("denied");
        setError(
          "Camera permission was declined. Nothing was shared, and you can keep studying normally. Change your browser's site settings if you'd like to try again.",
        );
      } else if (name === "NotFoundError" || name === "OverconstrainedError") {
        setCamState("error");
        setError("No camera was found on this device. You can still take part without video.");
      } else {
        setCamState("error");
        setError("The camera couldn't be started. You can still take part without video.");
      }
    }
  }

  async function disableCamera() {
    stopAllMedia();
    setCamState("off");
    await fetch(`/api/classroom/${classId}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "camera", on: false }),
    }).catch(() => undefined);
  }

  async function toggleMic() {
    const next = !micOn;
    if (next) {
      try {
        const audio = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        // Merge into the existing stream so a single stream represents this learner.
        if (streamRef.current) {
          audio.getAudioTracks().forEach((t) => streamRef.current!.addTrack(t));
        } else {
          streamRef.current = audio;
        }
        setMicOn(true);
      } catch {
        setError("Microphone permission was declined. You can keep participating by text.");
        return;
      }
    } else {
      streamRef.current?.getAudioTracks().forEach((t) => {
        t.stop();
        streamRef.current?.removeTrack(t);
      });
      setMicOn(false);
    }
    await fetch(`/api/classroom/${classId}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "mic", on: next }),
    }).catch(() => undefined);
  }

  async function join() {
    setError(null);
    const res = await fetch(`/api/classroom/${classId}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "join" }),
    }).catch(() => null);
    if (!res || !res.ok) {
      setError("We couldn't join that session. Check your connection and try again.");
      return;
    }
    setPhase("joined");
    setElapsed(0);
  }

  async function leave() {
    stopAllMedia();
    setCamState("off");
    setMicOn(false);
    setHand(false);
    await fetch(`/api/classroom/${classId}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "leave" }),
    }).catch(() => undefined);
    setPhase("lobby");
    setElapsed(0);
  }

  const lesson = info?.lessonId ? getLesson(info.lessonId) : null;
  const mins = String(Math.floor(elapsed / 60)).padStart(2, "0");
  const secs = String(elapsed % 60).padStart(2, "0");

  return (
    <div className="mx-auto max-w-7xl px-4 pb-20 pt-24 sm:px-6 lg:px-8">
      {/* Persistent camera indicator */}
      {camState === "on" && (
        <div
          role="status"
          aria-live="polite"
          className="sticky top-[70px] z-40 mb-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl border-2 border-dancheong-500 bg-[linear-gradient(100deg,rgba(255,77,94,0.22),rgba(224,41,63,0.12))] px-4 py-3 live-ring"
        >
          <span className="flex items-center gap-3">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-dancheong-500 text-ink-950">
              <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor">
                <path d="M23 7l-7 5 7 5V7ZM1 5h14v14H1V5Z" />
              </svg>
            </span>
            <span>
              <span className="block text-[14px] font-black uppercase tracking-wide text-dancheong-400">
                Camera is on — visible to the instructor
              </span>
              <span className="block text-[11.5px] text-hanji-200">
                {instructorName} only · not shown to other learners · not recorded
              </span>
            </span>
          </span>
          <Button variant="danger" size="sm" onClick={disableCamera}>
            Turn camera off now
          </Button>
        </div>
      )}

      <div className="flex flex-wrap items-center gap-3">
        <Link
          href="/classroom"
          className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-mute-400 transition hover:text-hanji-50"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
            <path d="M19 12H5M11 18l-6-6 6-6" />
          </svg>
          All sessions
        </Link>
        <span className="text-mute-400/40">/</span>
        <Chip tone={info?.status === "live" ? "#FF4D5E" : "#8E9AB4"}>
          {info?.status === "live" ? "● Live now" : info?.status ?? "loading"}
        </Chip>
        {info && <Chip tone="#8E9AB4">{info.code}</Chip>}
        {phase === "joined" && <Chip tone="#3ED6B0">In session · {mins}:{secs}</Chip>}
      </div>

      <h1 className="mt-4 font-display text-3xl font-black leading-tight text-hanji-50 sm:text-[40px]">
        {info?.title ?? "Loading session…"}
      </h1>
      <p className="mt-1 font-display text-lg text-mute-400">{info?.titleKo}</p>

      {error && (
        <div className="mt-5 flex items-start gap-3 rounded-2xl border border-dancheong-500/45 bg-dancheong-500/10 px-4 py-3">
          <span aria-hidden className="mt-0.5 text-dancheong-400">⚠</span>
          <p className="text-[13.5px] leading-relaxed text-dancheong-400">{error}</p>
          <button
            onClick={() => setError(null)}
            className="ml-auto shrink-0 text-[12px] font-semibold text-mute-400 hover:text-hanji-100"
          >
            Dismiss
          </button>
        </div>
      )}

      <div className="mt-7 grid gap-5 lg:grid-cols-[1.5fr_1fr]">
        {/* Stage */}
        <div className="overflow-hidden rounded-3xl border border-hanji-200/12 bg-ink-900">
          <div className="relative aspect-video bg-[linear-gradient(160deg,#131A2A,#06080D)]">
            <video
              ref={videoRef}
              playsInline
              muted
              autoPlay
              className={cx(
                "h-full w-full -scale-x-100 object-cover transition-opacity duration-500",
                camState === "on" ? "opacity-100" : "opacity-0",
              )}
            />
            {camState !== "on" && (
              <div className="absolute inset-0 grid place-items-center p-6 text-center">
                <div>
                  <div className="mx-auto grid h-20 w-20 place-items-center rounded-full border-2 border-hanji-200/25 bg-ink-800/70">
                    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#B3BDD2" strokeWidth="1.7" strokeLinecap="round">
                      <path d="M23 7l-7 5 7 5V7ZM1 5h14v14H1V5Z" />
                      <path d="M3 3l18 18" />
                    </svg>
                  </div>
                  <p className="mt-4 font-display text-xl font-bold text-hanji-50">
                    {phase === "joined" ? "Camera is off" : "You haven't joined yet"}
                  </p>
                  <p className="mx-auto mt-2 max-w-sm text-[13.5px] leading-relaxed text-mute-400">
                    {phase === "joined"
                      ? "You're fully in the class. Turn your camera on only if you want to."
                      : "Nothing is captured until you join, and joining never turns on your camera or microphone."}
                  </p>
                </div>
              </div>
            )}

            {camState === "on" && (
              <div className="pointer-events-none absolute left-3 top-3 flex items-center gap-2 rounded-full bg-ink-950/80 px-3 py-1.5 backdrop-blur">
                <span className="h-2 w-2 rounded-full bg-dancheong-500 live-ring" />
                <span className="text-[11.5px] font-bold text-hanji-50">
                  LIVE · to {instructorName}
                </span>
              </div>
            )}

            {camState === "on" && linkState !== "idle" && (
              <div className="pointer-events-none absolute bottom-3 left-3 rounded-full bg-ink-950/80 px-3 py-1.5 text-[11px] font-semibold backdrop-blur">
                <span
                  style={{
                    color:
                      linkState === "connected"
                        ? "#3ED6B0"
                        : linkState === "connecting"
                          ? "#F5B841"
                          : "#8E9AB4",
                  }}
                >
                  {linkState === "connected"
                    ? "Encrypted channel connected"
                    : linkState === "connecting"
                      ? "Connecting encrypted channel…"
                      : "Instructor not connected — your preview is local only"}
                </span>
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="flex flex-wrap items-center gap-2 border-t border-hanji-200/10 bg-ink-850 p-4">
            {phase === "lobby" ? (
              <>
                <Button onClick={join} disabled={!info}>
                  Join without camera
                </Button>
                <Button
                  variant="secondary"
                  onClick={() => {
                    setConsentChecked(false);
                    setConsentOpen(true);
                  }}
                  disabled={!info}
                >
                  Enable camera…
                </Button>
                <span className="ml-auto text-[11.5px] text-mute-400">
                  Camera &amp; mic are off by default
                </span>
              </>
            ) : (
              <>
                <button
                  onClick={() => {
                    if (camState === "on") void disableCamera();
                    else {
                      setConsentChecked(false);
                      setConsentOpen(true);
                    }
                  }}
                  disabled={camState === "requesting"}
                  className={cx(
                    "inline-flex items-center gap-2 rounded-full border px-4 py-2.5 text-sm font-semibold transition-all duration-300 active:scale-95",
                    camState === "on"
                      ? "border-dancheong-500 bg-dancheong-500/20 text-dancheong-400"
                      : "border-hanji-200/20 bg-ink-800 text-hanji-100 hover:border-celadon-500/60",
                  )}
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round">
                    <path d="M23 7l-7 5 7 5V7ZM1 5h14v14H1V5Z" />
                    {camState !== "on" && <path d="M3 3l18 18" />}
                  </svg>
                  {camState === "requesting"
                    ? "Requesting…"
                    : camState === "on"
                      ? "Camera on"
                      : "Camera off"}
                </button>

                <button
                  onClick={toggleMic}
                  className={cx(
                    "inline-flex items-center gap-2 rounded-full border px-4 py-2.5 text-sm font-semibold transition-all duration-300 active:scale-95",
                    micOn
                      ? "border-celadon-500 bg-celadon-500/20 text-celadon-400"
                      : "border-hanji-200/20 bg-ink-800 text-hanji-100 hover:border-celadon-500/60",
                  )}
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round">
                    <rect x="9" y="2" width="6" height="12" rx="3" />
                    <path d="M5 11a7 7 0 0 0 14 0M12 18v4" />
                    {!micOn && <path d="M3 3l18 18" />}
                  </svg>
                  {micOn ? "Mic on" : "Mic off"}
                </button>

                <button
                  onClick={() => {
                    const next = !hand;
                    setHand(next);
                    void fetch(`/api/classroom/${classId}`, {
                      method: "POST",
                      headers: { "content-type": "application/json" },
                      body: JSON.stringify({ action: "hand", on: next }),
                    });
                  }}
                  className={cx(
                    "inline-flex items-center gap-2 rounded-full border px-4 py-2.5 text-sm font-semibold transition-all duration-300 active:scale-95",
                    hand
                      ? "border-gold-500 bg-gold-500/20 text-gold-400"
                      : "border-hanji-200/20 bg-ink-800 text-hanji-100 hover:border-gold-500/60",
                  )}
                >
                  ✋ {hand ? "Hand raised" : "Raise hand"}
                </button>

                <Button variant="danger" className="ml-auto" onClick={leave}>
                  Leave session
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Side panel */}
        <div className="space-y-4">
          <div className="card p-5">
            <h2 className="font-display text-lg font-bold text-hanji-50">Who can see you</h2>
            <ul className="mt-3 space-y-2.5 text-[13px]">
              {[
                [`Instructor · ${instructorName}`, true, "#3ED6B0"],
                ["Other learners", false, "#FF4D5E"],
                ["Recording / storage", false, "#FF4D5E"],
              ].map(([label, allowed, tone]) => (
                <li key={label as string} className="flex items-center gap-2.5">
                  <span
                    className="grid h-5 w-5 place-items-center rounded-full text-[10px] font-black text-ink-950"
                    style={{ background: tone as string }}
                  >
                    {allowed ? "✓" : "✕"}
                  </span>
                  <span className="text-hanji-100">{label as string}</span>
                  <span className="ml-auto text-[11.5px]" style={{ color: tone as string }}>
                    {allowed ? (camState === "on" ? "receiving now" : "only if you enable") : "never"}
                  </span>
                </li>
              ))}
            </ul>
            <div className="mt-4 hairline" />
            <p className="mt-3 text-[11.5px] leading-relaxed text-mute-400">
              Media travels over encrypted WebRTC (DTLS-SRTP). Your stream is addressed to this
              session's instructor only — the signalling server rejects learner-to-learner routes.
              Nothing is recorded or stored.
            </p>
          </div>

          <div className="card p-5">
            <div className="flex items-baseline justify-between">
              <h2 className="font-display text-lg font-bold text-hanji-50">In the room</h2>
              <span className="text-[12px] text-mute-400">{roster.length} present</span>
            </div>
            <ul className="mt-3 space-y-2">
              {roster.map((p) => (
                <li
                  key={p.userId}
                  className="flex items-center gap-3 rounded-xl border border-hanji-200/10 bg-ink-900/60 px-3 py-2"
                >
                  <span
                    className="grid h-8 w-8 place-items-center rounded-full text-[12px] font-black"
                    style={{
                      background: p.cameraOn ? "#FF4D5E22" : "#26314A",
                      color: p.cameraOn ? "#FF7A72" : "#B3BDD2",
                    }}
                  >
                    {p.displayName.slice(0, 1)}
                  </span>
                  <span className="min-w-0 flex-1 truncate text-[13px] text-hanji-100">
                    {p.displayName}
                    {p.userId === learner?.id && <span className="text-mute-400"> (you)</span>}
                  </span>
                  {p.handRaised && <span title="Hand raised">✋</span>}
                  <span
                    className="rounded-full px-2 py-0.5 text-[10px] font-bold"
                    style={{
                      background: p.cameraOn ? "#FF4D5E22" : "#1B2436",
                      color: p.cameraOn ? "#FF7A72" : "#8E9AB4",
                    }}
                  >
                    {p.cameraOn ? "cam on" : "cam off"}
                  </span>
                </li>
              ))}
              {roster.length === 0 && (
                <li className="rounded-xl border border-hanji-200/10 bg-ink-900/50 px-3 py-5 text-center text-[12.5px] text-mute-400">
                  Nobody has joined yet.
                </li>
              )}
            </ul>
          </div>

          {lesson && (
            <div className="card p-5">
              <p className="text-[10.5px] font-bold uppercase tracking-[0.24em] text-gold-500">
                Today's material
              </p>
              <h2 className="mt-1.5 font-display text-lg font-bold text-hanji-50">{lesson.title}</h2>
              <p className="mt-1 text-[12.5px] leading-relaxed text-mute-400">{lesson.summary}</p>
              <Link
                href={`/learn/${lesson.id}`}
                className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-semibold text-celadon-400 hover:underline"
              >
                Open the lesson →
              </Link>
            </div>
          )}
        </div>
      </div>

      {/* Consent dialog — the only path to a camera prompt */}
      {consentOpen && (
        <div className="fixed inset-0 z-[110] flex items-end justify-center sm:items-center sm:p-6">
          <div
            className="absolute inset-0 bg-ink-950/85 backdrop-blur-sm fade"
            onClick={() => setConsentOpen(false)}
            aria-hidden
          />
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="consent-title"
            className="relative w-full overflow-hidden rounded-t-3xl border border-gold-500/30 bg-ink-850 shadow-2xl pop sm:max-w-lg sm:rounded-3xl"
          >
            <div className="h-1 w-full bg-[linear-gradient(90deg,#F5B841,#FF4D5E,transparent)]" />
            <div className="max-h-[80vh] overflow-y-auto p-6">
              <p className="text-[11px] font-bold uppercase tracking-[0.28em] text-gold-500">
                동의 · Before we ask your browser
              </p>
              <h2 id="consent-title" className="mt-2 font-display text-2xl font-black text-hanji-50">
                Turn on your camera?
              </h2>

              <div className="mt-4 space-y-3 text-[13.5px] leading-relaxed text-mute-300">
                <p>
                  <strong className="text-hanji-100">Who will see it:</strong> only{" "}
                  <strong className="text-hanji-100">{instructorName}</strong>, the instructor
                  authorised for this session. No other learner can receive your video.
                </p>
                <p>
                  <strong className="text-hanji-100">What happens next:</strong> your browser will
                  show its own permission prompt. This is the first time we ask it for anything —
                  nothing was requested before this click.
                </p>
                <p>
                  <strong className="text-hanji-100">Recording:</strong> none. Your stream is not
                  recorded, saved, or replayed. There is no background or hidden capture.
                </p>
                <p>
                  <strong className="text-hanji-100">Stopping:</strong> the camera toggle and “Leave
                  session” both stop the stream immediately. Turning it off is instant and needs no
                  explanation.
                </p>
                <p className="rounded-xl border border-celadon-500/30 bg-celadon-500/8 px-3 py-2.5 text-celadon-400">
                  You can complete this entire course with your camera off. Declining changes
                  nothing about your access.
                </p>
              </div>

              <label className="mt-5 flex cursor-pointer items-start gap-3 rounded-xl border border-hanji-200/14 bg-ink-900/60 p-3.5">
                <input
                  type="checkbox"
                  checked={consentChecked}
                  onChange={(e) => setConsentChecked(e.target.checked)}
                  className="mt-0.5 h-4 w-4 shrink-0 accent-[#3ED6B0]"
                />
                <span className="text-[13px] leading-relaxed text-hanji-100">
                  I understand that {instructorName} will see my live video, and I'm choosing to
                  turn my camera on.
                </span>
              </label>

              <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
                <Button variant="ghost" onClick={() => setConsentOpen(false)}>
                  No thanks — keep it off
                </Button>
                <Button variant="gold" disabled={!consentChecked} onClick={enableCamera}>
                  Enable camera
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}