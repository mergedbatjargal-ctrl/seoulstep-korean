"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button, LinkButton, cx } from "@/components/ui";

export function JoinRedeem({
  token,
  label,
  lessonId,
  lessonTitle,
  classId,
  classTitle,
  expiresAt,
  problem,
}: {
  token: string;
  label: string | null;
  lessonId: string | null;
  lessonTitle: string | null;
  classId: string | null;
  classTitle: string | null;
  expiresAt: string | null;
  problem: string | null;
}) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function redeem() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/invitations/${encodeURIComponent(token)}/redeem`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ displayName: name.trim() || undefined }),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        setError(json?.message ?? "This invitation could not be opened.");
        setBusy(false);
        return;
      }
      router.push(json.lessonId ? `/learn/${json.lessonId}` : "/learn");
    } catch {
      setError("Network problem — check your connection and try again.");
      setBusy(false);
    }
  }

  if (problem) {
    return (
      <div className="mx-auto max-w-xl px-4 pb-24 pt-32 text-center sm:px-6">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-full border-2 border-dancheong-500/50 bg-dancheong-500/12 text-2xl">
          🔒
        </div>
        <h1 className="mt-5 font-display text-3xl font-black text-hanji-50">
          This invitation can't be used
        </h1>
        <p className="mt-3 text-[15px] leading-relaxed text-mute-300">{problem}</p>
        <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
          <LinkButton href="/learn">Start learning without an invite</LinkButton>
          <LinkButton href="/contact" variant="secondary">
            Contact the instructor
          </LinkButton>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 pb-24 pt-28 sm:px-6">
      <div className="grain relative overflow-hidden rounded-3xl border border-gold-500/25 bg-[linear-gradient(140deg,rgba(245,184,65,0.14),rgba(255,61,154,0.1)_55%,rgba(14,19,32,0.95))] p-6 sm:p-9">
        <div className="pointer-events-none absolute -right-14 -top-14 h-52 w-52 rounded-full bg-gold-500/22 blur-3xl" />
        <p className="relative text-[11px] font-bold uppercase tracking-[0.28em] text-gold-500">
          초대장 · Lesson invitation
        </p>
        <h1 className="relative mt-2 font-display text-3xl font-black leading-tight text-hanji-50 sm:text-4xl">
          {label ?? "You've been invited"}
        </h1>

        <dl className="relative mt-6 grid gap-3 sm:grid-cols-2">
          <div className="rounded-2xl border border-hanji-200/12 bg-ink-900/60 p-4">
            <dt className="text-[10.5px] uppercase tracking-widest text-mute-400">Lesson</dt>
            <dd className="mt-1 font-display text-[15px] font-bold text-hanji-50">
              {lessonTitle ?? "Full course access"}
            </dd>
          </div>
          <div className="rounded-2xl border border-hanji-200/12 bg-ink-900/60 p-4">
            <dt className="text-[10.5px] uppercase tracking-widest text-mute-400">Live session</dt>
            <dd className="mt-1 font-display text-[15px] font-bold text-hanji-50">
              {classTitle ?? "Not included"}
            </dd>
          </div>
          <div className="rounded-2xl border border-hanji-200/12 bg-ink-900/60 p-4">
            <dt className="text-[10.5px] uppercase tracking-widest text-mute-400">Access level</dt>
            <dd className="mt-1 flex items-center gap-2 font-display text-[15px] font-bold text-celadon-400">
              Learner only
              <span className="rounded-full bg-celadon-500/18 px-2 py-0.5 text-[10px] uppercase tracking-wider">
                never admin
              </span>
            </dd>
          </div>
          <div className="rounded-2xl border border-hanji-200/12 bg-ink-900/60 p-4">
            <dt className="text-[10.5px] uppercase tracking-widest text-mute-400">Expires</dt>
            <dd className="mt-1 font-display text-[15px] font-bold text-hanji-50">
              {expiresAt
                ? new Date(expiresAt).toLocaleDateString(undefined, {
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                  })
                : "No expiry set"}
            </dd>
          </div>
        </dl>

        <div className="relative mt-6 rounded-2xl border border-celadon-500/28 bg-celadon-500/8 p-4">
          <p className="text-[13px] font-bold text-celadon-400">
            Your camera and microphone are off
          </p>
          <p className="mt-1 text-[12.5px] leading-relaxed text-mute-300">
            Opening this invitation does not request any device permission. If you later join the
            live session, you'll be asked explicitly before your browser is ever prompted, and you
            can complete everything with video off.
          </p>
        </div>

        <label
          htmlFor="join-name"
          className="relative mt-6 block text-[11px] font-semibold uppercase tracking-wider text-mute-400"
        >
          Display name (optional — this is all we store)
        </label>
        <input
          id="join-name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g. Alex"
          maxLength={48}
          className="relative mt-2 w-full rounded-xl border border-hanji-200/18 bg-ink-900 px-4 py-3 text-sm text-hanji-50 outline-none transition placeholder:text-mute-400/60 focus:border-celadon-500"
        />

        {error && (
          <p className="relative mt-3 rounded-xl border border-dancheong-500/40 bg-dancheong-500/10 px-3 py-2 text-sm text-dancheong-400">
            {error}
          </p>
        )}

        <div className="relative mt-6 flex flex-col gap-3 sm:flex-row">
          <Button size="lg" onClick={redeem} disabled={busy} className="w-full sm:w-auto">
            {busy ? "Opening…" : lessonTitle ? `Start “${lessonTitle}”` : "Open my lessons"}
          </Button>
          {classId && (
            <LinkButton href={`/classroom/${classId}`} variant="secondary" size="lg">
              Go to the live session
            </LinkButton>
          )}
        </div>

        <p className="relative mt-4 text-[11.5px] text-mute-400">
          Invitation code <code className={cx("rounded bg-ink-900 px-1.5 py-0.5")}>{token}</code> ·{" "}
          <Link href="/privacy" className="underline hover:text-hanji-100">
            privacy practices
          </Link>
        </p>
      </div>
    </div>
  );
}