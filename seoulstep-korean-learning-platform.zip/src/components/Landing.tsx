"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { BADGES, LESSONS, TRACKS, type TrackId } from "@/lib/curriculum";
import { Button, Chip, LinkButton, Reveal, SectionLabel, cx } from "@/components/ui";
import { JoinDialog } from "@/components/SiteChrome";
import { speakKorean, speechSupported, primeVoices } from "@/lib/speech";

/* ── Hangul syllable composer ─────────────────────────────────── */
/* `n` is each jamo's true index in the Unicode choseong / jungseong /
   jongseong tables — that is what the composition formula requires. */
type Jamo = { c: string; r: string; n: number };

const INITIALS: Jamo[] = [
  { c: "ㄱ", r: "g", n: 0 },
  { c: "ㄲ", r: "kk", n: 1 },
  { c: "ㄴ", r: "n", n: 2 },
  { c: "ㄷ", r: "d", n: 3 },
  { c: "ㄸ", r: "tt", n: 4 },
  { c: "ㄹ", r: "r", n: 5 },
  { c: "ㅁ", r: "m", n: 6 },
  { c: "ㅂ", r: "b", n: 7 },
  { c: "ㅃ", r: "pp", n: 8 },
  { c: "ㅅ", r: "s", n: 9 },
  { c: "ㅆ", r: "ss", n: 10 },
  { c: "ㅇ", r: "", n: 11 },
  { c: "ㅈ", r: "j", n: 12 },
  { c: "ㅉ", r: "jj", n: 13 },
  { c: "ㅊ", r: "ch", n: 14 },
  { c: "ㅋ", r: "k", n: 15 },
  { c: "ㅌ", r: "t", n: 16 },
  { c: "ㅍ", r: "p", n: 17 },
  { c: "ㅎ", r: "h", n: 18 },
];

const MEDIALS: Jamo[] = [
  { c: "ㅏ", r: "a", n: 0 },
  { c: "ㅐ", r: "ae", n: 1 },
  { c: "ㅑ", r: "ya", n: 2 },
  { c: "ㅒ", r: "yae", n: 3 },
  { c: "ㅓ", r: "eo", n: 4 },
  { c: "ㅔ", r: "e", n: 5 },
  { c: "ㅕ", r: "yeo", n: 6 },
  { c: "ㅖ", r: "ye", n: 7 },
  { c: "ㅗ", r: "o", n: 8 },
  { c: "ㅛ", r: "yo", n: 12 },
  { c: "ㅜ", r: "u", n: 13 },
  { c: "ㅠ", r: "yu", n: 17 },
  { c: "ㅡ", r: "eu", n: 18 },
  { c: "ㅣ", r: "i", n: 20 },
];

const FINALS: Jamo[] = [
  { c: "—", r: "", n: 0 },
  { c: "ㄱ", r: "k", n: 1 },
  { c: "ㄲ", r: "k", n: 2 },
  { c: "ㄴ", r: "n", n: 4 },
  { c: "ㄷ", r: "t", n: 7 },
  { c: "ㄹ", r: "l", n: 8 },
  { c: "ㅁ", r: "m", n: 16 },
  { c: "ㅂ", r: "p", n: 17 },
  { c: "ㅅ", r: "t", n: 19 },
  { c: "ㅆ", r: "t", n: 20 },
  { c: "ㅇ", r: "ng", n: 21 },
  { c: "ㅈ", r: "t", n: 22 },
  { c: "ㅎ", r: "t", n: 27 },
];

function compose(i: Jamo, m: Jamo, f: Jamo) {
  return String.fromCharCode(0xac00 + (i.n * 21 + m.n) * 28 + f.n);
}

function HangulLab() {
  const [i, setI] = useState(18); // ㅎ
  const [m, setM] = useState(0); // ㅏ
  const [f, setF] = useState(3); // ㄴ  →  한
  const [pulse, setPulse] = useState(0);

  const syllable = compose(INITIALS[i], MEDIALS[m], FINALS[f]);
  const roman = `${INITIALS[i].r}${MEDIALS[m].r}${FINALS[f].r}`;

  useEffect(() => setPulse((p) => p + 1), [i, m, f]);

  function play() {
    if (speechSupported()) speakKorean(syllable, 0.7);
  }

  return (
    <div className="relative overflow-hidden rounded-3xl border border-hanji-200/15 bg-[linear-gradient(155deg,rgba(27,36,54,0.92),rgba(10,13,21,0.96))] p-5 shadow-[0_40px_90px_-40px_rgba(0,0,0,1)] sm:p-7">
      <div className="pointer-events-none absolute -right-16 -top-16 h-52 w-52 rounded-full bg-celadon-500/18 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-20 -left-10 h-52 w-52 rounded-full bg-magenta-500/14 blur-3xl" />

      <div className="relative flex items-center justify-between">
        <div>
          <p className="text-[10.5px] font-bold uppercase tracking-[0.28em] text-celadon-500">
            Hangul Lab
          </p>
          <h3 className="font-display text-lg font-bold text-hanji-50">Build a syllable</h3>
        </div>
        <button
          onClick={play}
          className="grid h-11 w-11 place-items-center rounded-full border border-celadon-500/40 bg-celadon-500/10 text-celadon-400 transition hover:bg-celadon-500/25"
          aria-label={`Play the sound of ${syllable}`}
          title="Play sound"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
            <path d="M8 5v14l11-7z" />
          </svg>
        </button>
      </div>

      <div className="relative mt-5 grid grid-cols-[1fr_auto] items-center gap-4">
        <div className="grid h-32 place-items-center rounded-2xl border border-hanji-200/12 bg-[radial-gradient(circle_at_50%_30%,rgba(62,214,176,0.16),transparent_70%)] sm:h-40">
          <span
            key={pulse}
            className="font-display text-[76px] font-black leading-none text-hanji-50 pop sm:text-[96px]"
            style={{ textShadow: "0 12px 40px rgba(62,214,176,0.35)" }}
          >
            {syllable}
          </span>
        </div>
        <div className="flex flex-col gap-2">
          <div className="rounded-xl border border-hanji-200/12 bg-ink-900/70 px-3 py-2 text-center">
            <p className="text-[10px] uppercase tracking-widest text-mute-400">Romanised</p>
            <p className="font-display text-xl font-bold text-gold-400">{roman}</p>
          </div>
          <div className="rounded-xl border border-hanji-200/12 bg-ink-900/70 px-3 py-2 text-center">
            <p className="text-[10px] uppercase tracking-widest text-mute-400">Parts</p>
            <p className="font-display text-lg font-bold text-hanji-100">
              {INITIALS[i].c} · {MEDIALS[m].c}
              {FINALS[f].n > 0 ? ` · ${FINALS[f].c}` : ""}
            </p>
          </div>
        </div>
      </div>

      <div className="relative mt-5 space-y-3">
        <Picker
          label="Initial 초성"
          tone="#3ED6B0"
          options={INITIALS.map((x) => x.c)}
          value={i}
          onChange={setI}
        />
        <Picker
          label="Vowel 중성"
          tone="#F5B841"
          options={MEDIALS.map((x) => x.c)}
          value={m}
          onChange={setM}
        />
        <Picker
          label="Final 받침"
          tone="#FF3D9A"
          options={FINALS.map((x) => x.c)}
          value={f}
          onChange={setF}
        />
      </div>
      <p className="relative mt-4 text-[11.5px] leading-relaxed text-mute-400">
        Hangul has 11,172 possible syllable blocks — every one of them is assembled from the parts
        above. Drag through them and watch the block rebuild itself.
      </p>
    </div>
  );
}

function Picker({
  label,
  options,
  value,
  onChange,
  tone,
}: {
  label: string;
  options: string[];
  value: number;
  onChange: (n: number) => void;
  tone: string;
}) {
  return (
    <div>
      <p className="mb-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-mute-400">
        {label}
      </p>
      <div className="flex gap-1.5 overflow-x-auto pb-1.5">
        {options.map((opt, idx) => (
          <button
            key={`${label}-${idx}`}
            onClick={() => onChange(idx)}
            aria-pressed={value === idx}
            className={cx(
              "grid h-9 w-9 shrink-0 place-items-center rounded-lg border font-display text-base font-bold transition-all duration-200",
              value === idx
                ? "scale-110 text-ink-950"
                : "border-hanji-200/12 bg-ink-900/60 text-mute-300 hover:text-hanji-50",
            )}
            style={
              value === idx
                ? { background: tone, borderColor: tone, boxShadow: `0 6px 18px -6px ${tone}` }
                : undefined
            }
          >
            {opt}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ── Live mini quiz on the landing page ───────────────────────── */
const DEMO_Q = [
  {
    prompt: "Which syllable is romanised 'han'?",
    choices: ["한", "훈", "헌", "힌"],
    answer: 0,
    explain: "ㅎ + ㅏ +  = 한. Change the vowel and the whole word changes.",
  },
  {
    prompt: "감사합니다 means…",
    choices: ["Goodbye", "Thank you", "Excuse me", "Nice to meet you"],
    answer: 1,
    explain: "감사합니다 — the standard polite 'thank you'.",
  },
  {
    prompt: "Which ending makes a verb polite?",
    choices: ["-다", "-아요/어요", "-기", "-음"],
    answer: 1,
    explain: "-아요/어요 is the everyday polite present tense.",
  },
];

function MiniQuiz() {
  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const q = DEMO_Q[idx];

  function choose(i: number) {
    if (picked !== null) return;
    setPicked(i);
    if (i === q.answer) setScore((s) => s + 1);
  }
  function next() {
    if (idx + 1 >= DEMO_Q.length) {
      setDone(true);
      return;
    }
    setIdx(idx + 1);
    setPicked(null);
  }
  function reset() {
    setIdx(0);
    setPicked(null);
    setScore(0);
    setDone(false);
  }

  if (done) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 py-8 text-center pop">
        <span className="font-display text-5xl font-black text-gold-400">
          {score}/{DEMO_Q.length}
        </span>
        <p className="text-sm text-mute-300">
          {score === DEMO_Q.length
            ? "Perfect. You're ready for lesson one."
            : "Nice start — the full lessons explain every rule."}
        </p>
        <div className="mt-2 flex gap-2">
          <Button variant="secondary" size="sm" onClick={reset}>
            Try again
          </Button>
          <LinkButton href="/learn" size="sm">
            Start lesson one
          </LinkButton>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-4 flex items-center gap-2">
        {DEMO_Q.map((_, i) => (
          <span
            key={i}
            className="h-1 flex-1 rounded-full transition-all duration-500"
            style={{
              background:
                i < idx ? "#3ED6B0" : i === idx ? "linear-gradient(90deg,#F5B841,#FF3D9A)" : "#26314A",
            }}
          />
        ))}
      </div>
      <p className="font-display text-lg font-bold leading-snug text-hanji-50">{q.prompt}</p>
      <div className="mt-4 grid gap-2">
        {q.choices.map((c, i) => {
          const isAnswer = i === q.answer;
          const chosen = picked === i;
          const state =
            picked === null ? "idle" : isAnswer ? "right" : chosen ? "wrong" : "dim";
          return (
            <button
              key={c}
              onClick={() => choose(i)}
              disabled={picked !== null}
              className={cx(
                "flex items-center justify-between gap-3 rounded-xl border px-4 py-3 text-left text-sm font-medium transition-all duration-300",
                state === "idle" &&
                  "border-hanji-200/14 bg-ink-900/60 text-hanji-100 hover:border-celadon-500/60 hover:bg-ink-800",
                state === "right" && "border-celadon-500 bg-celadon-500/15 text-celadon-400",
                state === "wrong" && "border-dancheong-500 bg-dancheong-500/15 text-dancheong-400 shake",
                state === "dim" && "border-hanji-200/8 bg-ink-900/40 text-mute-400",
              )}
            >
              <span className="font-display text-base">{c}</span>
              {state === "right" && <span aria-hidden>✓</span>}
              {state === "wrong" && <span aria-hidden>✕</span>}
            </button>
          );
        })}
      </div>
      {picked !== null && (
        <div className="mt-4 rounded-xl border border-hanji-200/12 bg-ink-900/70 p-3 fade">
          <p className="text-[13px] leading-relaxed text-mute-300">{q.explain}</p>
          <Button size="sm" className="mt-3" onClick={next}>
            {idx + 1 >= DEMO_Q.length ? "See result" : "Next question"}
          </Button>
        </div>
      )}
    </div>
  );
}

/* ── Flashcard flip demo ──────────────────────────────────────── */
const DEMO_CARDS = [
  { front: "안녕하세요", roman: "an-nyeong-ha-se-yo", back: "hello / good day" },
  { front: "맛있어요", roman: "ma-si-sseo-yo", back: "it's delicious" },
  { front: "얼마예요?", roman: "eol-ma-ye-yo?", back: "how much is it?" },
  { front: "괜찮아요", roman: "gwaen-cha-na-yo", back: "it's okay" },
];

function FlashcardDemo() {
  const [i, setI] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const card = DEMO_CARDS[i];

  function advance() {
    setFlipped(false);
    setTimeout(() => setI((n) => (n + 1) % DEMO_CARDS.length), 130);
  }

  return (
    <div>
      <button
        onClick={() => setFlipped((f) => !f)}
        className="group relative block h-52 w-full [perspective:1200px]"
        aria-label="Flip flashcard"
      >
        <div
          className="relative h-full w-full transition-transform duration-700 [transform-style:preserve-3d]"
          style={{ transform: flipped ? "rotateY(180deg)" : "none" }}
        >
          <div className="absolute inset-0 grid place-items-center rounded-2xl border border-gold-500/30 bg-[linear-gradient(150deg,rgba(245,184,65,0.14),rgba(14,19,32,0.95))] p-6 [backface-visibility:hidden]">
            <div className="text-center">
              <p className="font-display text-4xl font-black text-hanji-50">{card.front}</p>
              <p className="mt-2 text-sm text-gold-400">{card.roman}</p>
              <p className="mt-4 text-[11px] uppercase tracking-[0.22em] text-mute-400">
                Tap to reveal
              </p>
            </div>
          </div>
          <div className="absolute inset-0 grid place-items-center rounded-2xl border border-celadon-500/35 bg-[linear-gradient(150deg,rgba(62,214,176,0.16),rgba(14,19,32,0.95))] p-6 [backface-visibility:hidden] [transform:rotateY(180deg)]">
            <div className="text-center">
              <p className="font-display text-2xl font-bold text-celadon-400">{card.back}</p>
              <p className="mt-2 text-sm text-mute-300">{card.front}</p>
            </div>
          </div>
        </div>
      </button>
      <div className="mt-4 grid grid-cols-4 gap-2">
        {(
          [
            ["Again", "#FF4D5E", "10m"],
            ["Hard", "#F5B841", "2d"],
            ["Good", "#3ED6B0", "5d"],
            ["Easy", "#4C9BFF", "12d"],
          ] as const
        ).map(([label, tone, when]) => (
          <button
            key={label}
            onClick={advance}
            className="rounded-xl border px-2 py-2 text-center transition-all duration-300 hover:-translate-y-0.5"
            style={{ borderColor: `${tone}44`, background: `${tone}12` }}
          >
            <span className="block text-[12.5px] font-bold" style={{ color: tone }}>
              {label}
            </span>
            <span className="block text-[10px] text-mute-400">{when}</span>
          </button>
        ))}
      </div>
      <p className="mt-3 text-[11.5px] leading-relaxed text-mute-400">
        Every answer reschedules the card with an SM-2 spaced-repetition curve, so you review right
        before you'd forget.
      </p>
    </div>
  );
}

/* ── Consent state machine visual ─────────────────────────────── */
function ConsentFlow() {
  const [step, setStep] = useState(0);
  const steps = [
    {
      title: "You open the link",
      body: "The page loads with camera and microphone off. No permission prompt is triggered — ever — by simply arriving.",
      tone: "#4C9BFF",
      icon: "M12 5c-5 0-9 4.5-9 7s4 7 9 7 9-4.5 9-7-4-7-9-7Zm0 10a3 3 0 1 1 0-6 3 3 0 0 1 0 6Z",
      badge: "Camera OFF",
    },
    {
      title: "We explain, then ask",
      body: "A plain-language panel tells you exactly who will see your video — your instructor and no other learner — and waits for you to press Enable camera.",
      tone: "#F5B841",
      icon: "M12 2 3 6v6c0 5 3.8 9.3 9 10 5.2-.7 9-5 9-10V6l-9-4Z",
      badge: "Awaiting your choice",
    },
    {
      title: "Only then, the browser prompt",
      body: "The browser's own permission dialog appears the instant you click Enable camera — never before. Deny it and you keep studying as normal.",
      tone: "#FF3D9A",
      icon: "M4 7h4l2-2h4l2 2h4v12H4V7Zm8 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z",
      badge: "You decide",
    },
    {
      title: "Live, and unmistakably marked",
      body: "A red pulsing banner reads “Camera is on — visible to your instructor” for as long as the stream runs. One tap turns it off and kills the track immediately.",
      tone: "#FF4D5E",
      icon: "M23 7l-7 5 7 5V7ZM1 5h14v14H1V5Z",
      badge: "Camera ON · streaming",
    },
  ];
  const s = steps[step];

  return (
    <div className="grid gap-6 lg:grid-cols-[0.95fr_1.05fr]">
      <div className="space-y-2">
        {steps.map((st, i) => (
          <button
            key={st.title}
            onClick={() => setStep(i)}
            className={cx(
              "flex w-full items-start gap-3 rounded-2xl border p-4 text-left transition-all duration-300",
              i === step
                ? "border-transparent bg-ink-800"
                : "border-hanji-200/10 bg-ink-900/50 hover:bg-ink-800/70",
            )}
            style={i === step ? { boxShadow: `inset 3px 0 0 ${st.tone}` } : undefined}
            aria-current={i === step}
          >
            <span
              className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg text-xs font-black"
              style={{ background: `${st.tone}22`, color: st.tone }}
            >
              {i + 1}
            </span>
            <span>
              <span className="block font-display text-[15px] font-bold text-hanji-50">
                {st.title}
              </span>
              <span className="mt-0.5 block text-[13px] leading-relaxed text-mute-400">
                {st.body}
              </span>
            </span>
          </button>
        ))}
      </div>

      <div className="relative overflow-hidden rounded-3xl border border-hanji-200/12 bg-ink-900 p-5">
        <div
          className="absolute inset-x-0 top-0 h-1 transition-colors duration-500"
          style={{ background: s.tone }}
        />
        <div className="flex items-center justify-between">
          <p className="text-[10.5px] font-bold uppercase tracking-[0.24em] text-mute-400">
            Session preview
          </p>
          <span
            className={cx(
              "rounded-full px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-widest",
              step === 3 && "live-ring",
            )}
            style={{ background: `${s.tone}20`, color: s.tone }}
          >
            {s.badge}
          </span>
        </div>

        <div className="relative mt-4 aspect-video overflow-hidden rounded-2xl border border-hanji-200/12 bg-[linear-gradient(160deg,#131A2A,#06080D)]">
          {step === 3 ? (
            <>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(255,77,94,0.22),transparent_65%)]" />
              <div className="absolute inset-0 grid place-items-center">
                <div className="text-center">
                  <div className="mx-auto grid h-16 w-16 place-items-center rounded-full border-2 border-dancheong-500/70 bg-dancheong-500/15 live-ring">
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#FF4D5E" strokeWidth="1.8">
                      <path d={s.icon} />
                    </svg>
                  </div>
                  <p className="mt-3 text-sm font-bold text-dancheong-400">
                    Camera is on — visible to the instructor
                  </p>
                  <p className="mt-1 text-[11.5px] text-mute-400">
                    Not shared with other learners · not recorded
                  </p>
                </div>
              </div>
            </>
          ) : (
            <div className="absolute inset-0 grid place-items-center">
              <div className="text-center">
                <div
                  className="mx-auto grid h-16 w-16 place-items-center rounded-full border-2"
                  style={{ borderColor: `${s.tone}88`, background: `${s.tone}18` }}
                >
                  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke={s.tone} strokeWidth="1.8">
                    <path d={s.icon} />
                    <path d="M3 3l18 18" strokeLinecap="round" />
                  </svg>
                </div>
                <p className="mt-3 text-sm font-semibold text-hanji-100">Camera is off</p>
                <p className="mt-1 text-[11.5px] text-mute-400">
                  You can complete the whole course this way.
                </p>
              </div>
            </div>
          )}
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <span className="rounded-lg border border-hanji-200/12 bg-ink-850 px-2.5 py-1.5 text-[11px] text-mute-300">
            Mic off by default
          </span>
          <span className="rounded-lg border border-hanji-200/12 bg-ink-850 px-2.5 py-1.5 text-[11px] text-mute-300">
            Leave session stops all tracks
          </span>
          <span className="rounded-lg border border-hanji-200/12 bg-ink-850 px-2.5 py-1.5 text-[11px] text-mute-300">
            No recording
          </span>
        </div>
      </div>
    </div>
  );
}

/* ── Curriculum explorer ──────────────────────────────────────── */
function CurriculumExplorer() {
  const [track, setTrack] = useState<TrackId>("hangul");
  const active = TRACKS.find((t) => t.id === track)!;
  const lessons = useMemo(() => LESSONS.filter((l) => l.track === track), [track]);
  const totalMinutes = lessons.reduce((n, l) => n + l.minutes, 0);

  return (
    <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
      <div className="flex gap-2 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible lg:pb-0">
        {TRACKS.map((t) => {
          const on = t.id === track;
          return (
            <button
              key={t.id}
              onClick={() => setTrack(t.id)}
              className={cx(
                "group flex min-w-[190px] items-center gap-3 rounded-2xl border p-3.5 text-left transition-all duration-300 lg:min-w-0",
                on ? "bg-ink-800" : "border-hanji-200/10 bg-ink-900/50 hover:bg-ink-800/60",
              )}
              style={on ? { borderColor: `${t.hue}66`, boxShadow: `0 12px 34px -22px ${t.hue}` } : undefined}
              aria-pressed={on}
            >
              <span
                className="grid h-11 w-11 shrink-0 place-items-center rounded-xl font-display text-xl font-black transition-transform duration-300 group-hover:scale-110"
                style={{ background: `${t.hue}1E`, color: t.hue, border: `1px solid ${t.hue}44` }}
              >
                {t.glyph}
              </span>
              <span className="min-w-0">
                <span className="block truncate font-display text-[15px] font-bold text-hanji-50">
                  {t.name}
                </span>
                <span className="block text-[11.5px] text-mute-400">
                  {t.nameKo} · {LESSONS.filter((l) => l.track === t.id).length} lessons
                </span>
              </span>
            </button>
          );
        })}
      </div>

      <div className="relative overflow-hidden rounded-3xl border border-hanji-200/12 bg-[linear-gradient(160deg,rgba(19,26,42,0.9),rgba(6,8,13,0.95))] p-5 sm:p-7">
        <div
          className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full blur-3xl transition-colors duration-700"
          style={{ background: `${active.hue}26` }}
        />
        <div className="relative flex flex-wrap items-start justify-between gap-4">
          <div>
            <h3 className="font-display text-2xl font-bold text-hanji-50">
              {active.name}{" "}
              <span className="text-mute-400">· {active.nameKo}</span>
            </h3>
            <p className="mt-1.5 max-w-lg text-sm leading-relaxed text-mute-300">{active.blurb}</p>
          </div>
          <Chip tone={active.hue}>
            {lessons.length} lessons · {totalMinutes} min
          </Chip>
        </div>

        <ol className="relative mt-6 space-y-2.5">
          {lessons.map((l, i) => (
            <li key={l.id}>
              <Link
                href={`/learn/${l.id}`}
                className="group flex items-center gap-4 rounded-2xl border border-hanji-200/10 bg-ink-900/60 p-4 transition-all duration-300 hover:-translate-y-0.5 hover:border-hanji-200/25 hover:bg-ink-800"
              >
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-full border font-display text-sm font-bold"
                  style={{ borderColor: `${active.hue}55`, color: active.hue }}
                >
                  {i + 1}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex flex-wrap items-baseline gap-x-2">
                    <span className="font-display text-[15px] font-bold text-hanji-50">
                      {l.title}
                    </span>
                    <span className="text-[12px] text-mute-400">{l.titleKo}</span>
                  </span>
                  <span className="mt-0.5 block truncate text-[12.5px] text-mute-400">
                    {l.summary}
                  </span>
                </span>
                <span className="hidden shrink-0 items-center gap-3 sm:flex">
                  <span className="rounded-full border border-hanji-200/12 px-2.5 py-1 text-[11px] text-mute-300">
                    {l.level}
                  </span>
                  <span className="text-[11px] text-mute-400">{l.minutes}m</span>
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.4"
                    strokeLinecap="round"
                    className="text-mute-400 transition-transform duration-300 group-hover:translate-x-1"
                    style={{ color: active.hue }}
                  >
                    <path d="M5 12h14M13 6l6 6-6 6" />
                  </svg>
                </span>
              </Link>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}

/* ── Marquee ──────────────────────────────────────────────────── */
function Marquee() {
  const glyphs = "가나다라마바사아자차카타파하강경서울한글사랑친구학교가족음식여행".split("");
  return (
    <div className="relative overflow-hidden border-y border-hanji-200/10 bg-ink-900/50 py-4">
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-[linear-gradient(90deg,#06080D,transparent)]" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-[linear-gradient(270deg,#06080D,transparent)]" />
      <div className="flex w-max animate-[marquee_38s_linear_infinite] gap-8">
        {[...glyphs, ...glyphs].map((g, i) => (
          <span
            key={i}
            className="font-display text-2xl font-bold text-hanji-200/25 transition-colors hover:text-celadon-400"
          >
            {g}
          </span>
        ))}
      </div>
      <style jsx>{`
        @keyframes marquee {
          from {
            transform: translateX(0);
          }
          to {
            transform: translateX(-50%);
          }
        }
      `}</style>
    </div>
  );
}

/* ── Page ─────────────────────────────────────────────────────── */
export function Landing() {
  const [join, setJoin] = useState(false);
  const onJoin = () => setJoin(true);
  useEffect(() => primeVoices(), []);

  return (
    <>
      <JoinDialog open={join} onClose={() => setJoin(false)} />
      {/* HERO */}
      <section className="grain relative overflow-hidden pb-16 pt-28 sm:pb-24 sm:pt-32">
        <div className="aurora pointer-events-none absolute inset-0 -z-10" />
        <div className="paper-lines pointer-events-none absolute inset-0 -z-10 opacity-60" />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 -z-10 h-40 bg-[linear-gradient(180deg,transparent,#06080D)]" />

        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-[1.08fr_0.92fr] lg:px-8">
          <div>
            <div className="rise inline-flex items-center gap-2 rounded-full border border-celadon-500/30 bg-celadon-500/10 px-3.5 py-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-celadon-500 live-ring" />
              <span className="text-[11.5px] font-semibold tracking-wide text-celadon-400">
                한글부터 회화까지 · Hangul to conversation
              </span>
            </div>

            <h1
              className="rise mt-6 font-display text-[42px] font-black leading-[1.03] tracking-tight text-hanji-50 text-balance sm:text-6xl lg:text-[68px]"
              style={{ animationDelay: "80ms" }}
            >
              Learn Korean the way
              <br />
              it was{" "}
              <span className="relative inline-block">
                <span className="bg-[linear-gradient(110deg,#3ED6B0,#F5B841_45%,#FF3D9A)] bg-clip-text text-transparent">
                  designed
                </span>
                <svg
                  className="absolute -bottom-2 left-0 w-full"
                  height="10"
                  viewBox="0 0 200 10"
                  preserveAspectRatio="none"
                  aria-hidden
                >
                  <path
                    d="M2 7C40 2 70 9 110 4s60 2 88 1"
                    stroke="#FF3D9A"
                    strokeWidth="3"
                    fill="none"
                    strokeLinecap="round"
                  />
                </svg>
              </span>{" "}
              to be learned.
            </h1>

            <p
              className="rise mt-7 max-w-xl text-[16.5px] leading-relaxed text-mute-300"
              style={{ animationDelay: "160ms" }}
            >
              SeoulStep turns a beautiful, logical alphabet into a habit. Structured lessons,
              spaced-repetition flashcards, real quizzes, and live classes where{" "}
              <strong className="font-semibold text-hanji-100">
                your camera stays off until you say otherwise
              </strong>
              .
            </p>

            <div
              className="rise mt-8 flex flex-col gap-3 sm:flex-row sm:items-center"
              style={{ animationDelay: "240ms" }}
            >
              <LinkButton href="/learn" size="lg" className="w-full sm:w-auto">
                Start learning
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round">
                  <path d="M5 12h14M13 6l6 6-6 6" />
                </svg>
              </LinkButton>
              <Button variant="gold" size="lg" onClick={onJoin} className="w-full sm:w-auto">
                Join a lesson
              </Button>
            </div>
            <p className="rise mt-3 text-[12.5px] text-mute-400" style={{ animationDelay: "300ms" }}>
              No account needed to begin · progress saves as you go
            </p>

            <dl
              className="rise mt-10 grid max-w-lg grid-cols-3 gap-3"
              style={{ animationDelay: "360ms" }}
            >
              {[
                ["6", "learning tracks", "#3ED6B0"],
                [`${LESSONS.length}`, "structured lessons", "#F5B841"],
                ["100%", "camera opt-in", "#FF3D9A"],
              ].map(([v, l, tone]) => (
                <div
                  key={l}
                  className="rounded-2xl border border-hanji-200/10 bg-ink-900/50 px-3 py-3 backdrop-blur"
                >
                  <dt className="font-display text-2xl font-black" style={{ color: tone }}>
                    {v}
                  </dt>
                  <dd className="mt-0.5 text-[11.5px] leading-tight text-mute-400">{l}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="rise floaty" style={{ animationDelay: "300ms" }}>
            <HangulLab />
          </div>
        </div>
      </section>

      <Marquee />

      {/* CURRICULUM */}
      <section id="curriculum" className="relative py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionLabel>커리큘럼 · Curriculum</SectionLabel>
            <div className="flex flex-wrap items-end justify-between gap-6">
              <h2 className="max-w-2xl font-display text-3xl font-black leading-tight text-hanji-50 text-balance sm:text-[44px]">
                Six tracks that carry you from first stroke to first conversation.
              </h2>
              <LinkButton href="/learn/tracks" variant="secondary">
                Browse every lesson
              </LinkButton>
            </div>
          </Reveal>
          <Reveal delay={90} className="mt-10">
            <CurriculumExplorer />
          </Reveal>
        </div>
      </section>

      {/* PRACTICE */}
      <section id="practice" className="relative overflow-hidden py-20 sm:py-28">
        <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(70%_50%_at_20%_0%,rgba(76,155,255,0.14),transparent_60%),radial-gradient(60%_50%_at_85%_100%,rgba(255,61,154,0.12),transparent_60%)]" />
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionLabel tone="#F5B841">연습 · Practice</SectionLabel>
            <h2 className="max-w-2xl font-display text-3xl font-black leading-tight text-hanji-50 text-balance sm:text-[44px]">
              Try it right now — no sign-up, no camera.
            </h2>
          </Reveal>

          <div className="mt-10 grid gap-5 lg:grid-cols-2">
            <Reveal delay={60}>
              <div className="card h-full p-5 sm:p-6">
                <div className="mb-4 flex items-center justify-between">
                  <div>
                    <p className="text-[10.5px] font-bold uppercase tracking-[0.24em] text-celadon-500">
                      Interactive quiz
                    </p>
                    <h3 className="font-display text-xl font-bold text-hanji-50">
                      Three questions
                    </h3>
                  </div>
                  <Chip tone="#3ED6B0">Instant feedback</Chip>
                </div>
                <MiniQuiz />
              </div>
            </Reveal>
            <Reveal delay={130}>
              <div className="card h-full p-5 sm:p-6">
                <div className="mb-4 flex items-center justify-between">
                  <div>
                    <p className="text-[10.5px] font-bold uppercase tracking-[0.24em] text-gold-500">
                      Spaced repetition
                    </p>
                    <h3 className="font-display text-xl font-bold text-hanji-50">Flashcards</h3>
                  </div>
                  <Chip tone="#F5B841">SM-2 scheduling</Chip>
                </div>
                <FlashcardDemo />
              </div>
            </Reveal>
          </div>

          <div className="mt-5 grid gap-5 md:grid-cols-3">
            {[
              {
                title: "Progress that remembers you",
                body: "Every lesson stores your position, best score and time spent. Close the tab mid-sentence and resume exactly there.",
                tone: "#4C9BFF",
                icon: "M3 3v18h18M7 15l4-5 3 3 5-7",
              },
              {
                title: "Badges worth earning",
                body: `${BADGES.length} badges mark real milestones — finishing Hangul, a perfect listening score, twenty cards reviewed.`,
                tone: "#C77DFF",
                icon: "M12 2l2.6 6.2 6.7.5-5.1 4.4 1.6 6.5L12 16.2 6.2 19.6l1.6-6.5L2.7 8.7l6.7-.5L12 2Z",
              },
              {
                title: "Audio on every card",
                body: "Tap any word to hear it in Korean. Speech runs on-device through your browser — nothing is uploaded.",
                tone: "#3ED6B0",
                icon: "M11 5 6 9H2v6h4l5 4V5Zm4.5 3a5 5 0 0 1 0 8",
              },
            ].map((f, i) => (
              <Reveal key={f.title} delay={60 * i}>
                <div className="card card-hover h-full p-5">
                  <span
                    className="grid h-10 w-10 place-items-center rounded-xl"
                    style={{ background: `${f.tone}1C`, border: `1px solid ${f.tone}44` }}
                  >
                    <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke={f.tone} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                      <path d={f.icon} />
                    </svg>
                  </span>
                  <h3 className="mt-4 font-display text-[17px] font-bold text-hanji-50">
                    {f.title}
                  </h3>
                  <p className="mt-2 text-[13.5px] leading-relaxed text-mute-400">{f.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* CLASSROOM / CONSENT */}
      <section id="classroom" className="relative py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionLabel tone="#FF4D5E">라이브 수업 · Live classroom</SectionLabel>
            <div className="flex flex-wrap items-end justify-between gap-6">
              <h2 className="max-w-3xl font-display text-3xl font-black leading-tight text-hanji-50 text-balance sm:text-[44px]">
                Your camera is off. It stays off until you decide otherwise.
              </h2>
              <LinkButton href="/classroom" variant="secondary">
                See the classroom
              </LinkButton>
            </div>
            <p className="mt-4 max-w-2xl text-[15.5px] leading-relaxed text-mute-300">
              Most platforms treat a video call as the default and privacy as an afterthought. We
              inverted it. Walk through the four states below — this is exactly what the real
              session does.
            </p>
          </Reveal>
          <Reveal delay={90} className="mt-10">
            <ConsentFlow />
          </Reveal>
        </div>
      </section>

      {/* PRIVACY */}
      <section id="privacy" className="relative overflow-hidden py-20 sm:py-28">
        <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(60%_50%_at_50%_0%,rgba(62,214,176,0.1),transparent_60%)]" />
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionLabel tone="#C77DFF">개인정보 · Privacy by construction</SectionLabel>
            <h2 className="max-w-2xl font-display text-3xl font-black leading-tight text-hanji-50 text-balance sm:text-[44px]">
              What we promise, in plain language.
            </h2>
          </Reveal>

          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                t: "Opt-in only",
                d: "No page load, invitation link, or instructor action can request or enable your camera. Only your click can.",
                tone: "#3ED6B0",
              },
              {
                t: "One recipient",
                d: "Your video travels over encrypted WebRTC to your session's instructor — never to other learners.",
                tone: "#4C9BFF",
              },
              {
                t: "Nothing recorded",
                d: "Streams are not recorded or stored. If recording is ever introduced it will need separate, explicit consent.",
                tone: "#F5B841",
              },
              {
                t: "Minimum data",
                d: "A display name and your learning progress. That's it. No tracking pixels, no ad SDKs, no data resale.",
                tone: "#FF3D9A",
              },
            ].map((p, i) => (
              <Reveal key={p.t} delay={i * 70}>
                <div className="card card-hover h-full p-5">
                  <div
                    className="mb-4 h-1 w-10 rounded-full"
                    style={{ background: p.tone }}
                  />
                  <h3 className="font-display text-[17px] font-bold text-hanji-50">{p.t}</h3>
                  <p className="mt-2 text-[13.5px] leading-relaxed text-mute-400">{p.d}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={140}>
            <div className="mt-6 flex flex-col items-start justify-between gap-4 rounded-3xl border border-hanji-200/12 bg-ink-900/60 p-6 sm:flex-row sm:items-center">
              <p className="max-w-2xl text-sm leading-relaxed text-mute-300">
                The instructor dashboard is separate, requires a password{" "}
                <strong className="text-hanji-100">and</strong> a time-based one-time code, and
                writes every sign-in and classroom access to an append-only audit log. Invitation
                links are learner-scoped by design — there is no code path from an invite to admin
                rights.
              </p>
              <div className="flex shrink-0 gap-2">
                <LinkButton href="/privacy" variant="secondary" size="sm">
                  Read the policy
                </LinkButton>
                <LinkButton href="/contact" variant="ghost" size="sm">
                  Contact owner
                </LinkButton>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* VOICES */}
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionLabel tone="#4C9BFF">후기 · From learners</SectionLabel>
          </Reveal>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {[
              {
                q: "I'd bounced off Korean twice. Reading Hangul by lesson three is the thing that finally made it stick.",
                n: "Priya N.",
                r: "Manchester · 4 weeks in",
                tone: "#3ED6B0",
              },
              {
                q: "The camera-off default is why I actually joined the live class. I turned it on in week three, on my own terms.",
                n: "Tomás R.",
                r: "Lisbon · 9 weeks in",
                tone: "#F5B841",
              },
              {
                q: "Spaced repetition plus the pronunciation drills fixed my ㄱ / ㅋ / ㄲ problem in about a fortnight.",
                n: "Amara O.",
                r: "Lagos · 6 weeks in",
                tone: "#FF3D9A",
              },
            ].map((t, i) => (
              <Reveal key={t.n} delay={i * 80}>
                <figure className="card h-full p-6">
                  <svg width="26" height="26" viewBox="0 0 24 24" fill={t.tone} opacity="0.5">
                    <path d="M9 7H5a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v2a2 2 0 0 1-2 2H4v2h1a4 4 0 0 0 4-4V7Zm11 0h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v2a2 2 0 0 1-2 2h-1v2h1a4 4 0 0 0 4-4V7Z" />
                  </svg>
                  <blockquote className="mt-4 text-[14.5px] leading-relaxed text-hanji-100">
                    {t.q}
                  </blockquote>
                  <figcaption className="mt-5 flex items-center gap-3">
                    <span
                      className="grid h-9 w-9 place-items-center rounded-full font-display text-sm font-black"
                      style={{ background: `${t.tone}22`, color: t.tone }}
                    >
                      {t.n[0]}
                    </span>
                    <span>
                      <span className="block text-[13.5px] font-semibold text-hanji-50">{t.n}</span>
                      <span className="block text-[11.5px] text-mute-400">{t.r}</span>
                    </span>
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative overflow-hidden py-16 sm:py-24">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <div className="grain relative overflow-hidden rounded-[28px] border border-hanji-200/12 bg-[linear-gradient(140deg,rgba(62,214,176,0.16),rgba(76,155,255,0.12)_45%,rgba(255,61,154,0.14))] p-8 text-center sm:p-14">
              <div className="pointer-events-none absolute -left-10 -top-10 h-44 w-44 rounded-full bg-celadon-500/25 blur-3xl" />
              <div className="pointer-events-none absolute -bottom-14 -right-8 h-48 w-48 rounded-full bg-magenta-500/25 blur-3xl" />
              <p className="relative font-display text-2xl text-hanji-200/70">천 리 길도 한 걸음부터</p>
              <h2 className="relative mt-3 font-display text-3xl font-black leading-tight text-hanji-50 text-balance sm:text-5xl">
                A thousand-mile road begins with one step.
              </h2>
              <p className="relative mx-auto mt-4 max-w-xl text-[15px] leading-relaxed text-mute-300">
                Start with the ten vowels. Eight minutes from now you'll be reading Korean out loud.
              </p>
              <div className="relative mt-8 flex flex-col justify-center gap-3 sm:flex-row">
                <LinkButton href="/learn" size="lg">
                  Start learning — it's free
                </LinkButton>
                <Button variant="secondary" size="lg" onClick={onJoin}>
                  I have an invitation
                </Button>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}

