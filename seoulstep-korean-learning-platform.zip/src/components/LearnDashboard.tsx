"use client";

import Link from "next/link";
import { BADGES, LESSONS, TRACKS } from "@/lib/curriculum";
import { formatRelative } from "@/lib/badges";
import { useProgress } from "@/lib/learner-client";
import { Chip, LinkButton, ProgressRing, Reveal, SectionLabel, cx } from "@/components/ui";

export function LearnDashboard() {
  const { data, loading, error } = useProgress();

  const byLesson = new Map(data?.progress.map((p) => [p.lessonId, p]) ?? []);
  const earned = new Set(data?.badges.map((b) => b.badgeId) ?? []);
  const pct = data ? Math.round((data.stats.completed / data.stats.totalLessons) * 100) : 0;

  const nextUp = LESSONS.find((l) => byLesson.get(l.id)?.status !== "completed") ?? LESSONS[0];

  return (
    <div className="mx-auto max-w-7xl px-4 pb-20 pt-28 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-5">
        <div>
          <SectionLabel>학습자 홈 · Your dashboard</SectionLabel>
          <h1 className="font-display text-3xl font-black leading-tight text-hanji-50 sm:text-[42px]">
            안녕하세요{data?.learner ? `, ${data.learner.displayName.split(" · ")[0]}` : ""}
          </h1>
          <p className="mt-2 max-w-xl text-[15px] text-mute-300">
            {data?.stats.completed
              ? `You've finished ${data.stats.completed} of ${data.stats.totalLessons} lessons. Keep the streak alive.`
              : "Your first lesson takes eight minutes. Start with the vowels — everything else builds on them."}
          </p>
        </div>
        <div className="flex items-center gap-4 rounded-2xl border border-hanji-200/12 bg-ink-900/60 px-5 py-4">
          <ProgressRing value={pct} size={64} />
          <div>
            <p className="text-[11px] uppercase tracking-widest text-mute-400">Course progress</p>
            <p className="font-display text-lg font-bold text-hanji-50">
              {data?.stats.completed ?? 0}/{data?.stats.totalLessons ?? LESSONS.length} lessons
            </p>
            <p className="text-[11.5px] text-celadon-400">
              {data?.stats.minutes ?? 0} min studied · {data?.stats.averageScore ?? 0}% avg score
            </p>
          </div>
        </div>
      </div>

      {error && (
        <p className="mt-6 rounded-2xl border border-dancheong-500/40 bg-dancheong-500/10 px-4 py-3 text-sm text-dancheong-400">
          {error}
        </p>
      )}

      {/* Resume + quick actions */}
      <div className="mt-8 grid gap-4 lg:grid-cols-[1.5fr_1fr]">
        <Reveal>
          <div className="grain relative h-full overflow-hidden rounded-3xl border border-hanji-200/12 bg-[linear-gradient(135deg,rgba(62,214,176,0.16),rgba(76,155,255,0.1)_50%,rgba(255,61,154,0.12))] p-6 sm:p-8">
            <div className="pointer-events-none absolute -right-12 -top-12 h-48 w-48 rounded-full bg-celadon-500/25 blur-3xl" />
            <p className="relative text-[11px] font-bold uppercase tracking-[0.28em] text-celadon-400">
              {data?.resume ? "이어하기 · Resume where you left off" : "시작하기 · Start here"}
            </p>
            <h2 className="relative mt-3 font-display text-2xl font-black text-hanji-50 sm:text-3xl">
              {data?.resume ? data.resume.title : nextUp.title}
            </h2>
            <p className="relative mt-2 max-w-lg text-sm leading-relaxed text-mute-300">
              {data?.resume
                ? `You stopped at step ${data.resume.step + 1} — ${formatRelative(data.resume.updatedAt)}. Pick it up exactly there.`
                : nextUp.summary}
            </p>
            <div className="relative mt-6 flex flex-wrap gap-3">
              <LinkButton href={`/learn/${data?.resume?.lessonId ?? nextUp.id}`} size="lg">
                {data?.resume ? "Resume lesson" : "Start lesson"}
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round">
                  <path d="M5 12h14M13 6l6 6-6 6" />
                </svg>
              </LinkButton>
              <LinkButton href="/flashcards" variant="secondary" size="lg">
                Review flashcards
                {data && data.stats.cardsDue > 0 && (
                  <span className="ml-1 rounded-full bg-gold-500 px-2 py-0.5 text-[11px] font-black text-ink-950">
                    {data.stats.cardsDue}
                  </span>
                )}
              </LinkButton>
            </div>
          </div>
        </Reveal>

        <Reveal delay={80}>
          <div className="card h-full p-6">
            <p className="text-[11px] font-bold uppercase tracking-[0.24em] text-gold-500">
              오늘의 목표 · Today
            </p>
            <ul className="mt-4 space-y-3">
              {[
                {
                  label: "Finish one lesson",
                  done: (data?.stats.completed ?? 0) > 0,
                  tone: "#3ED6B0",
                },
                {
                  label: "Review due flashcards",
                  done: !!data && data.stats.cardsDue === 0 && data.stats.cardsSeen > 0,
                  tone: "#F5B841",
                },
                {
                  label: "Score 100% on a quiz",
                  done: (data?.progress ?? []).some((p) => p.bestScore >= 100),
                  tone: "#FF3D9A",
                },
                {
                  label: "Sit in on a live class",
                  done: earned.has("class-goer"),
                  tone: "#4C9BFF",
                },
              ].map((t) => (
                <li key={t.label} className="flex items-center gap-3">
                  <span
                    className={cx(
                      "grid h-6 w-6 shrink-0 place-items-center rounded-full border text-[11px] font-black transition-all duration-300",
                      t.done ? "text-ink-950" : "text-transparent",
                    )}
                    style={{
                      borderColor: `${t.tone}66`,
                      background: t.done ? t.tone : "transparent",
                    }}
                  >
                    ✓
                  </span>
                  <span
                    className={cx(
                      "text-sm transition-colors",
                      t.done ? "text-mute-400 line-through" : "text-hanji-100",
                    )}
                  >
                    {t.label}
                  </span>
                </li>
              ))}
            </ul>
            <div className="mt-5 hairline" />
            <Link
              href="/classroom"
              className="mt-4 flex items-center justify-between rounded-xl border border-hanji-200/12 bg-ink-900/60 px-4 py-3 transition hover:border-hanbok-500/50"
            >
              <span className="text-sm font-semibold text-hanji-100">Live classroom</span>
              <span className="text-[11.5px] text-mute-400">Camera off by default →</span>
            </Link>
          </div>
        </Reveal>
      </div>

      {/* Tracks */}
      <div className="mt-12">
        <Reveal>
          <div className="flex items-end justify-between gap-4">
            <h2 className="font-display text-2xl font-bold text-hanji-50">Your tracks</h2>
            <Link href="/learn/tracks" className="text-sm font-semibold text-celadon-400 hover:underline">
              All lessons →
            </Link>
          </div>
        </Reveal>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {TRACKS.map((t, i) => {
            const lessons = LESSONS.filter((l) => l.track === t.id);
            const done = lessons.filter((l) => byLesson.get(l.id)?.status === "completed").length;
            const p = Math.round((done / lessons.length) * 100);
            const target = lessons.find((l) => byLesson.get(l.id)?.status !== "completed") ?? lessons[0];
            return (
              <Reveal key={t.id} delay={i * 60}>
                <Link
                  href={`/learn/${target.id}`}
                  className="card card-hover group block h-full p-5"
                  style={{ borderColor: `${t.hue}30` }}
                >
                  <div className="flex items-start justify-between">
                    <span
                      className="grid h-11 w-11 place-items-center rounded-xl font-display text-xl font-black transition-transform duration-300 group-hover:scale-110"
                      style={{ background: `${t.hue}1E`, color: t.hue, border: `1px solid ${t.hue}44` }}
                    >
                      {t.glyph}
                    </span>
                    <ProgressRing value={loading ? 0 : p} size={44} stroke={4} tone={t.hue} label={`${done}/${lessons.length}`} />
                  </div>
                  <h3 className="mt-4 font-display text-[17px] font-bold text-hanji-50">
                    {t.name} <span className="text-mute-400">· {t.nameKo}</span>
                  </h3>
                  <p className="mt-1.5 text-[13px] leading-relaxed text-mute-400">{t.blurb}</p>
                  <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-ink-700">
                    <div
                      className="h-full rounded-full transition-[width] duration-700"
                      style={{ width: `${p}%`, background: t.hue }}
                    />
                  </div>
                </Link>
              </Reveal>
            );
          })}
        </div>
      </div>

      {/* Badges */}
      <div className="mt-14">
        <Reveal>
          <div className="flex items-end justify-between gap-4">
            <div>
              <SectionLabel tone="#C77DFF">배지 · Badges</SectionLabel>
              <h2 className="font-display text-2xl font-bold text-hanji-50">
                {earned.size} of {BADGES.length} earned
              </h2>
            </div>
            <Link href="/progress" className="text-sm font-semibold text-violet-450 hover:underline">
              Full progress →
            </Link>
          </div>
        </Reveal>
        <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {BADGES.map((b, i) => {
            const has = earned.has(b.id);
            return (
              <Reveal key={b.id} delay={i * 45}>
                <div
                  className={cx(
                    "relative h-full overflow-hidden rounded-2xl border p-4 text-center transition-all duration-500",
                    has ? "bg-ink-800" : "border-hanji-200/10 bg-ink-900/40",
                  )}
                  style={has ? { borderColor: `${b.hue}66`, boxShadow: `0 14px 40px -26px ${b.hue}` } : undefined}
                >
                  <span
                    className={cx(
                      "mx-auto grid h-12 w-12 place-items-center rounded-full font-display text-xl font-black transition",
                      !has && "opacity-30 grayscale",
                    )}
                    style={{ background: `${b.hue}22`, color: b.hue }}
                  >
                    {b.glyph}
                  </span>
                  <p className={cx("mt-3 text-[13px] font-bold", has ? "text-hanji-50" : "text-mute-400")}>
                    {b.name}
                  </p>
                  <p className="text-[10.5px] text-mute-400">{b.nameKo}</p>
                  {has && (
                    <span className="absolute right-2 top-2">
                      <Chip tone={b.hue} className="!px-1.5 !py-0.5 !text-[9px]">
                        Earned
                      </Chip>
                    </span>
                  )}
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </div>
  );
}