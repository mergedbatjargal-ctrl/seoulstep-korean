"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { BADGES, type Lesson, type LessonBlock, nextLessonAfter } from "@/lib/curriculum";
import { Button, Chip, LinkButton, cx } from "@/components/ui";
import { primeVoices, speakKorean, speechSupported } from "@/lib/speech";
import { ensureLearner } from "@/lib/learner-client";

function SayButton({ text, tone = "#3ED6B0" }: { text: string; tone?: string }) {
  const [state, setState] = useState<"idle" | "playing" | "unavailable">("idle");
  useEffect(() => primeVoices(), []);
  return (
    <button
      onClick={() => {
        if (!speechSupported()) {
          setState("unavailable");
          setTimeout(() => setState("idle"), 2200);
          return;
        }
        speakKorean(text);
        setState("playing");
        setTimeout(() => setState("idle"), 1100);
      }}
      aria-label={`Play pronunciation of ${text}`}
      title={state === "unavailable" ? "Speech isn't available in this browser" : "Hear it"}
      className={cx(
        "grid h-8 w-8 shrink-0 place-items-center rounded-full border transition-all duration-300",
        state === "playing" && "scale-110",
      )}
      style={{
        borderColor: state === "unavailable" ? "#FF4D5E66" : `${tone}55`,
        background: state === "playing" ? `${tone}30` : `${tone}12`,
        color: state === "unavailable" ? "#FF4D5E" : tone,
      }}
    >
      {state === "unavailable" ? (
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
          <path d="M12 8v5M12 17h.01" />
          <circle cx="12" cy="12" r="9" />
        </svg>
      ) : (
        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
          <path d="M8 5v14l11-7z" />
        </svg>
      )}
    </button>
  );
}

function BlockView({ block, tone }: { block: LessonBlock; tone: string }) {
  if (block.kind === "note" || block.kind === "tip") {
    const isTip = block.kind === "tip";
    return (
      <div
        className="rounded-2xl border p-5 sm:p-6"
        style={{
          borderColor: isTip ? "#F5B84144" : `${tone}33`,
          background: isTip
            ? "linear-gradient(150deg, rgba(245,184,65,0.1), rgba(14,19,32,0.85))"
            : "linear-gradient(150deg, rgba(27,36,54,0.7), rgba(14,19,32,0.85))",
        }}
      >
        <div className="flex items-center gap-2">
          {isTip && <span aria-hidden>💡</span>}
          <h3 className="font-display text-lg font-bold text-hanji-50">{block.title}</h3>
        </div>
        <p className="mt-3 text-[15px] leading-[1.75] text-mute-300">{block.body}</p>
      </div>
    );
  }

  if (block.kind === "glyphs") {
    return (
      <div>
        <h3 className="font-display text-lg font-bold text-hanji-50">{block.title}</h3>
        <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-4">
          {block.items.map((g) => (
            <div
              key={g.char}
              className="group rounded-2xl border border-hanji-200/12 bg-ink-900/60 p-3 transition-all duration-300 hover:-translate-y-1 hover:border-hanji-200/30"
            >
              <div className="flex items-start justify-between">
                <span className="font-display text-3xl font-black text-hanji-50">{g.char}</span>
                <SayButton text={g.char} tone={tone} />
              </div>
              <p className="mt-2 text-sm font-bold" style={{ color: tone }}>
                {g.roman}
              </p>
              <p className="text-[11.5px] leading-snug text-mute-400">{g.hint}</p>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (block.kind === "vocab") {
    return (
      <div>
        <h3 className="font-display text-lg font-bold text-hanji-50">{block.title}</h3>
        <ul className="mt-4 divide-y divide-hanji-200/8 overflow-hidden rounded-2xl border border-hanji-200/12 bg-ink-900/50">
          {block.items.map((v) => (
            <li key={v.ko} className="flex items-center gap-3 p-3.5 transition hover:bg-ink-800/60">
              <SayButton text={v.ko} tone={tone} />
              <div className="min-w-0 flex-1">
                <p className="font-display text-lg font-bold text-hanji-50">{v.ko}</p>
                <p className="text-[12px] text-mute-400">{v.roman}</p>
              </div>
              <p className="shrink-0 text-right text-[13.5px] text-hanji-200">{v.en}</p>
            </li>
          ))}
        </ul>
      </div>
    );
  }

  return (
    <div>
      <h3 className="font-display text-lg font-bold text-hanji-50">{block.title}</h3>
      <div className="mt-4 space-y-3">
        {block.lines.map((l, i) => (
          <div
            key={i}
            className={cx(
              "rounded-2xl border p-4",
              i % 2 === 0
                ? "border-hanji-200/12 bg-ink-900/60"
                : "border-transparent bg-ink-800/70",
            )}
            style={i % 2 === 1 ? { borderColor: `${tone}33` } : undefined}
          >
            <div className="flex items-start gap-3">
              <span
                className="mt-0.5 shrink-0 rounded-full px-2.5 py-1 text-[11px] font-bold"
                style={{ background: `${tone}1E`, color: tone }}
              >
                {l.who}
              </span>
              <div className="min-w-0 flex-1">
                <p className="font-display text-[17px] font-bold leading-snug text-hanji-50">
                  {l.ko}
                </p>
                <p className="mt-1 text-[12.5px] text-gold-400">{l.roman}</p>
                <p className="mt-1 text-[13px] text-mute-400">{l.en}</p>
              </div>
              <SayButton text={l.ko} tone={tone} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function LessonPlayer({
  lesson,
  tone,
  initialStep,
  wasCompleted,
}: {
  lesson: Lesson;
  tone: string;
  initialStep: number;
  wasCompleted: boolean;
}) {
  const total = lesson.blocks.length;
  const [step, setStep] = useState(Math.min(initialStep, total - 1));
  const [phase, setPhase] = useState<"lesson" | "quiz" | "done">("lesson");
  const [qIndex, setQIndex] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [correct, setCorrect] = useState(0);
  const [newBadges, setNewBadges] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const startedAt = useRef(Date.now());

  const persist = useCallback(
    async (payload: Record<string, unknown>) => {
      setSaving(true);
      try {
        await ensureLearner();
        const res = await fetch("/api/progress", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ lessonId: lesson.id, ...payload }),
        });
        const json = await res.json();
        if (Array.isArray(json?.newlyEarned) && json.newlyEarned.length) {
          setNewBadges(json.newlyEarned);
        }
      } catch {
        /* progress saving is best-effort; the lesson keeps working offline */
      } finally {
        setSaving(false);
      }
    },
    [lesson.id],
  );

  // Save the reading position whenever the step changes.
  useEffect(() => {
    const seconds = Math.round((Date.now() - startedAt.current) / 1000);
    startedAt.current = Date.now();
    const t = setTimeout(() => {
      void persist({ step, secondsSpent: Math.min(seconds, 300) });
    }, 500);
    return () => clearTimeout(t);
  }, [step, persist]);

  const q = lesson.quiz[qIndex];
  const scorePct = Math.round((correct / lesson.quiz.length) * 100);

  function answer(i: number) {
    if (picked !== null) return;
    setPicked(i);
    if (i === q.answer) setCorrect((c) => c + 1);
  }

  async function nextQuestion() {
    if (qIndex + 1 < lesson.quiz.length) {
      setQIndex(qIndex + 1);
      setPicked(null);
      return;
    }
    const finalCorrect = correct;
    const pct = Math.round((finalCorrect / lesson.quiz.length) * 100);
    setPhase("done");
    await persist({ score: pct, complete: true, step: total });
  }

  const upNext = nextLessonAfter(lesson.id);

  return (
    <div className="mx-auto max-w-4xl px-4 pb-24 pt-24 sm:px-6">
      {/* Lesson header */}
      <div className="flex flex-wrap items-center gap-3">
        <Link
          href="/learn/tracks"
          className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-mute-400 transition hover:text-hanji-50"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
            <path d="M19 12H5M11 18l-6-6 6-6" />
          </svg>
          All lessons
        </Link>
        <span className="text-mute-400/40">/</span>
        <Chip tone={tone}>{lesson.level}</Chip>
        <Chip tone="#8E9AB4">{lesson.minutes} min</Chip>
        {wasCompleted && <Chip tone="#3ED6B0">Completed</Chip>}
        {saving && <span className="text-[11px] text-mute-400">Saving…</span>}
      </div>

      <h1 className="mt-4 font-display text-3xl font-black leading-tight text-hanji-50 sm:text-[40px]">
        {lesson.title}
      </h1>
      <p className="mt-1 font-display text-lg text-mute-400">{lesson.titleKo}</p>
      <p className="mt-4 max-w-2xl text-[15.5px] leading-relaxed text-mute-300">{lesson.summary}</p>

      {/* Progress rail */}
      <div className="mt-7 flex items-center gap-1.5">
        {lesson.blocks.map((_, i) => (
          <button
            key={i}
            onClick={() => {
              setPhase("lesson");
              setStep(i);
            }}
            aria-label={`Go to step ${i + 1}`}
            className="h-1.5 flex-1 rounded-full transition-all duration-500"
            style={{
              background:
                phase !== "lesson" || i < step
                  ? tone
                  : i === step
                    ? `linear-gradient(90deg, ${tone}, #F5B841)`
                    : "#26314A",
            }}
          />
        ))}
        <span
          className="ml-2 h-1.5 w-8 rounded-full"
          style={{ background: phase === "quiz" || phase === "done" ? "#FF3D9A" : "#26314A" }}
          aria-hidden
        />
      </div>

      <div className="mt-7">
        {phase === "lesson" && (
          <div key={step} className="fade">
            <p className="mb-3 text-[11px] font-bold uppercase tracking-[0.24em] text-mute-400">
              Step {step + 1} of {total}
            </p>
            <BlockView block={lesson.blocks[step]} tone={tone} />

            <div className="mt-7 flex items-center justify-between gap-3">
              <Button
                variant="secondary"
                onClick={() => setStep((s) => Math.max(0, s - 1))}
                disabled={step === 0}
              >
                ← Back
              </Button>
              {step < total - 1 ? (
                <Button onClick={() => setStep((s) => s + 1)}>Continue →</Button>
              ) : (
                <Button variant="gold" onClick={() => setPhase("quiz")}>
                  Take the quiz ({lesson.quiz.length} questions)
                </Button>
              )}
            </div>
          </div>
        )}

        {phase === "quiz" && (
          <div key={qIndex} className="fade">
            <div className="rounded-3xl border border-hanji-200/12 bg-[linear-gradient(155deg,rgba(27,36,54,0.85),rgba(14,19,32,0.92))] p-5 sm:p-7">
              <div className="flex items-center justify-between">
                <p className="text-[11px] font-bold uppercase tracking-[0.24em] text-magenta-500">
                  Quiz · 문제 {qIndex + 1}/{lesson.quiz.length}
                </p>
                <span className="text-[12px] font-semibold text-celadon-400">
                  {correct} correct
                </span>
              </div>

              <h2 className="mt-4 font-display text-xl font-bold leading-snug text-hanji-50 sm:text-2xl">
                {q.prompt}
              </h2>
              {q.promptKo && q.promptKo !== q.prompt && (
                <p className="mt-1 font-display text-lg text-mute-400">{q.promptKo}</p>
              )}

              <div className="mt-5 grid gap-2.5 sm:grid-cols-2">
                {q.choices.map((c, i) => {
                  const state =
                    picked === null
                      ? "idle"
                      : i === q.answer
                        ? "right"
                        : picked === i
                          ? "wrong"
                          : "dim";
                  return (
                    <button
                      key={c}
                      onClick={() => answer(i)}
                      disabled={picked !== null}
                      className={cx(
                        "flex items-center justify-between gap-3 rounded-xl border px-4 py-3.5 text-left font-medium transition-all duration-300",
                        state === "idle" &&
                          "border-hanji-200/14 bg-ink-900/60 text-hanji-100 hover:-translate-y-0.5 hover:border-celadon-500/60 hover:bg-ink-800",
                        state === "right" && "border-celadon-500 bg-celadon-500/15 text-celadon-400",
                        state === "wrong" &&
                          "border-dancheong-500 bg-dancheong-500/15 text-dancheong-400 shake",
                        state === "dim" && "border-hanji-200/8 bg-ink-900/40 text-mute-400",
                      )}
                    >
                      <span className="font-display text-[16px]">{c}</span>
                      {state === "right" && <span aria-hidden>✓</span>}
                      {state === "wrong" && <span aria-hidden>✕</span>}
                    </button>
                  );
                })}
              </div>

              {picked !== null && (
                <div className="mt-5 rounded-2xl border border-hanji-200/12 bg-ink-900/70 p-4 fade">
                  <p className="text-[14px] leading-relaxed text-mute-300">
                    <strong
                      className="font-semibold"
                      style={{ color: picked === q.answer ? "#3ED6B0" : "#FF4D5E" }}
                    >
                      {picked === q.answer ? "Correct. " : "Not quite. "}
                    </strong>
                    {q.explain}
                  </p>
                  <div className="mt-4 flex justify-end">
                    <Button onClick={nextQuestion}>
                      {qIndex + 1 < lesson.quiz.length ? "Next question →" : "Finish lesson"}
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {phase === "done" && (
          <div className="grain relative overflow-hidden rounded-3xl border border-hanji-200/14 bg-[linear-gradient(140deg,rgba(62,214,176,0.18),rgba(245,184,65,0.12)_50%,rgba(255,61,154,0.14))] p-7 text-center pop sm:p-10">
            <div className="pointer-events-none absolute -left-10 -top-10 h-44 w-44 rounded-full bg-celadon-500/25 blur-3xl" />
            <p className="relative font-display text-5xl">
              {scorePct === 100 ? "🏆" : scorePct >= 60 ? "🎉" : "🌱"}
            </p>
            <h2 className="relative mt-3 font-display text-3xl font-black text-hanji-50">
              {scorePct === 100 ? "만점! Perfect score" : "Lesson complete"}
            </h2>
            <p className="relative mt-2 text-[15px] text-mute-300">
              You answered {correct} of {lesson.quiz.length} correctly — {scorePct}%.
            </p>

            <div className="relative mx-auto mt-5 h-2 max-w-sm overflow-hidden rounded-full bg-ink-900/70">
              <div
                className="h-full rounded-full transition-[width] duration-1000"
                style={{
                  width: `${scorePct}%`,
                  background: "linear-gradient(90deg,#3ED6B0,#F5B841,#FF3D9A)",
                }}
              />
            </div>

            {newBadges.length > 0 && (
              <div className="relative mt-7">
                <p className="text-[11px] font-bold uppercase tracking-[0.24em] text-gold-500">
                  New badge{newBadges.length > 1 ? "s" : ""} unlocked
                </p>
                <div className="mt-3 flex flex-wrap justify-center gap-3">
                  {newBadges.map((id) => {
                    const b = BADGES.find((x) => x.id === id);
                    if (!b) return null;
                    return (
                      <div
                        key={id}
                        className="pop flex items-center gap-2.5 rounded-2xl border px-4 py-2.5"
                        style={{ borderColor: `${b.hue}66`, background: `${b.hue}18` }}
                      >
                        <span
                          className="grid h-9 w-9 place-items-center rounded-full font-display text-lg font-black"
                          style={{ background: `${b.hue}25`, color: b.hue }}
                        >
                          {b.glyph}
                        </span>
                        <span className="text-left">
                          <span className="block text-[13px] font-bold text-hanji-50">{b.name}</span>
                          <span className="block text-[11px] text-mute-400">{b.nameKo}</span>
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="relative mt-8 flex flex-col justify-center gap-3 sm:flex-row">
              {upNext && (
                <LinkButton href={`/learn/${upNext.id}`} size="lg">
                  Next: {upNext.title} →
                </LinkButton>
              )}
              <LinkButton href="/learn" variant="secondary" size="lg">
                Back to dashboard
              </LinkButton>
              <Button
                variant="ghost"
                size="lg"
                onClick={() => {
                  setPhase("lesson");
                  setStep(0);
                  setQIndex(0);
                  setPicked(null);
                  setCorrect(0);
                  setNewBadges([]);
                }}
              >
                Review again
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}