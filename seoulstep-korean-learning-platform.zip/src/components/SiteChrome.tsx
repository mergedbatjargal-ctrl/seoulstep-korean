"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Button, cx } from "@/components/ui";

const NAV = [
  { id: "curriculum", label: "Curriculum" },
  { id: "practice", label: "Practice" },
  { id: "classroom", label: "Live class" },
  { id: "privacy", label: "Privacy" },
];

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className="group flex items-center gap-2.5" aria-label="SeoulStep home">
      <span className="relative grid h-9 w-9 place-items-center overflow-hidden rounded-xl bg-[linear-gradient(140deg,#3ED6B0,#4C9BFF_60%,#FF3D9A)] font-display text-lg font-black text-ink-950 shadow-[0_6px_20px_-8px_rgba(62,214,176,0.9)] transition-transform duration-500 group-hover:rotate-6">
        서
        <span className="pointer-events-none absolute inset-y-0 -left-6 w-6 skew-x-[-20deg] bg-white/40 opacity-0 transition group-hover:animate-[sweep_0.9s_ease] group-hover:opacity-100" />
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="font-display text-[17px] font-bold tracking-tight text-hanji-50">
            SeoulStep
          </span>
          <span className="text-[9.5px] font-semibold uppercase tracking-[0.3em] text-mute-400">
            서울스텝
          </span>
        </span>
      )}
    </Link>
  );
}

export function JoinDialog({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const router = useRouter();
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) {
      setCode("");
      setError(null);
    }
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    if (open) document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const raw = code.trim();
    if (!raw) {
      setError("Paste the invitation link or code your instructor sent you.");
      return;
    }
    const token = raw.includes("/") ? raw.split("/").filter(Boolean).pop()! : raw;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/invitations/${encodeURIComponent(token)}/check`);
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data.message ?? "That invitation link is not valid.");
        setBusy(false);
        return;
      }
      router.push(`/join/${encodeURIComponent(token)}`);
    } catch {
      setError("Network problem — check your connection and try again.");
      setBusy(false);
    }
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center sm:items-center sm:p-6">
      <div className="absolute inset-0 bg-ink-950/85 backdrop-blur-sm fade" onClick={onClose} aria-hidden />
      <form
        onSubmit={submit}
        role="dialog"
        aria-modal="true"
        aria-label="Join a lesson"
        className="relative w-full overflow-hidden rounded-t-3xl border border-hanji-200/15 bg-ink-850 shadow-2xl pop sm:max-w-lg sm:rounded-3xl"
      >
        <div className="h-1 w-full bg-[linear-gradient(90deg,#F5B841,#FF3D9A,transparent)]" />
        <div className="p-6">
          <p className="text-[11px] font-bold uppercase tracking-[0.28em] text-gold-500">
            초대장 · Invitation
          </p>
          <h2 className="mt-2 font-display text-2xl font-bold text-hanji-50">Join a lesson</h2>
          <p className="mt-2 text-sm leading-relaxed text-mute-300">
            Paste the link or code from your instructor. Invitation links always open{" "}
            <strong className="text-hanji-100">learner access only</strong> — they can never grant
            admin rights, and they expire or can be revoked at any time.
          </p>

          <label htmlFor="invite-code" className="mt-5 block text-xs font-semibold uppercase tracking-wider text-mute-400">
            Invitation link or code
          </label>
          <input
            id="invite-code"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="seoulstep.study/join/welcome-hangul-2026"
            autoComplete="off"
            className="mt-2 w-full rounded-xl border border-hanji-200/18 bg-ink-900 px-4 py-3 text-sm text-hanji-50 outline-none transition placeholder:text-mute-400/60 focus:border-celadon-500"
          />

          {error && (
            <p className="mt-3 rounded-xl border border-dancheong-500/40 bg-dancheong-500/10 px-3 py-2 text-sm text-dancheong-400">
              {error}
            </p>
          )}

          <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <Button type="button" variant="ghost" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" variant="gold" disabled={busy}>
              {busy ? "Checking…" : "Open my lesson"}
            </Button>
          </div>

          <p className="mt-4 text-[11.5px] leading-relaxed text-mute-400">
            Your camera and microphone stay <strong className="text-hanji-100">off</strong>. Opening
            a lesson never requests device permissions.
          </p>
        </div>
      </form>
    </div>
  );
}

export function SiteHeader({ variant = "landing" }: { variant?: "landing" | "app" }) {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState<string>("");
  const [menu, setMenu] = useState(false);
  const [join, setJoin] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (variant !== "landing") return;
    const sections = NAV.map((n) => document.getElementById(n.id)).filter(Boolean) as HTMLElement[];
    if (!sections.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActive(visible.target.id);
      },
      { rootMargin: "-45% 0px -45% 0px", threshold: [0, 0.2, 0.6] },
    );
    sections.forEach((s) => io.observe(s));
    return () => io.disconnect();
  }, [variant, pathname]);

  useEffect(() => setMenu(false), [pathname]);

  const isLanding = variant === "landing";

  return (
    <>
      <header
        className={cx(
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          scrolled
            ? "border-b border-hanji-200/10 bg-ink-950/85 backdrop-blur-xl shadow-[0_10px_40px_-24px_rgba(0,0,0,1)]"
            : "border-b border-transparent",
        )}
        style={{ minHeight: "var(--nav-h)" }}
      >
        <div className="mx-auto flex h-[66px] max-w-7xl items-center justify-between gap-3 px-4 sm:px-6 lg:px-8">
          <Logo />

          <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
            {isLanding ? (
              NAV.map((n) => (
                <a
                  key={n.id}
                  href={`#${n.id}`}
                  className={cx(
                    "relative rounded-full px-3.5 py-2 text-sm font-medium transition-colors",
                    active === n.id ? "text-hanji-50" : "text-mute-300 hover:text-hanji-50",
                  )}
                >
                  {n.label}
                  <span
                    className={cx(
                      "absolute inset-x-3 -bottom-0.5 h-px origin-left bg-[linear-gradient(90deg,#3ED6B0,#4C9BFF)] transition-transform duration-300",
                      active === n.id ? "scale-x-100" : "scale-x-0",
                    )}
                  />
                </a>
              ))
            ) : (
              <>
                <NavLink href="/learn" label="Dashboard" pathname={pathname} />
                <NavLink href="/learn/tracks" label="Lessons" pathname={pathname} />
                <NavLink href="/flashcards" label="Flashcards" pathname={pathname} />
                <NavLink href="/progress" label="Progress" pathname={pathname} />
                <NavLink href="/classroom" label="Live class" pathname={pathname} />
              </>
            )}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setJoin(true)}
              className="hidden rounded-full border border-gold-500/40 bg-gold-500/10 px-4 py-2 text-sm font-semibold text-gold-400 transition hover:bg-gold-500/20 sm:inline-flex"
            >
              Join a lesson
            </button>
            <Link
              href="/learn"
              className="hidden rounded-full bg-[linear-gradient(120deg,#3ED6B0,#1FAE8C_55%,#4C9BFF)] px-4 py-2 text-sm font-bold text-ink-950 shadow-[0_8px_26px_-10px_rgba(62,214,176,0.9)] transition hover:brightness-110 sm:inline-flex"
            >
              Start learning
            </Link>
            <Link
              href="/admin"
              className="hidden rounded-full border border-hanji-200/18 px-3 py-2 text-xs font-semibold text-mute-300 transition hover:border-hanbok-500/60 hover:text-hanbok-400 md:inline-flex"
              title="Instructor sign-in (MFA required)"
            >
              Instructor
            </Link>

            <button
              onClick={() => setMenu((m) => !m)}
              aria-label="Toggle navigation menu"
              aria-expanded={menu}
              className="grid h-10 w-10 place-items-center rounded-xl border border-hanji-200/15 text-hanji-100 transition hover:border-celadon-500/50 lg:hidden"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
                {menu ? <path d="M18 6 6 18M6 6l12 12" /> : <path d="M3 6h18M3 12h18M3 18h18" />}
              </svg>
            </button>
          </div>
        </div>

        {menu && (
          <div className="border-t border-hanji-200/10 bg-ink-950/97 px-4 pb-5 pt-3 backdrop-blur-xl lg:hidden">
            <div className="flex flex-col gap-1">
              {isLanding
                ? NAV.map((n) => (
                    <a
                      key={n.id}
                      href={`#${n.id}`}
                      onClick={() => setMenu(false)}
                      className="rounded-xl px-3 py-2.5 text-sm font-medium text-mute-300 transition hover:bg-ink-800 hover:text-hanji-50"
                    >
                      {n.label}
                    </a>
                  ))
                : [
                    ["/learn", "Dashboard"],
                    ["/learn/tracks", "Lessons"],
                    ["/flashcards", "Flashcards"],
                    ["/progress", "Progress"],
                    ["/classroom", "Live class"],
                  ].map(([href, label]) => (
                    <Link
                      key={href}
                      href={href}
                      className="rounded-xl px-3 py-2.5 text-sm font-medium text-mute-300 transition hover:bg-ink-800 hover:text-hanji-50"
                    >
                      {label}
                    </Link>
                  ))}
              <div className="mt-3 grid grid-cols-2 gap-2">
                <Button variant="gold" onClick={() => { setMenu(false); setJoin(true); }}>
                  Join a lesson
                </Button>
                <Link
                  href="/learn"
                  className="inline-flex items-center justify-center rounded-full bg-[linear-gradient(120deg,#3ED6B0,#4C9BFF)] px-5 py-2.5 text-sm font-bold text-ink-950"
                >
                  Start learning
                </Link>
              </div>
              <Link
                href="/admin"
                className="mt-2 rounded-xl px-3 py-2.5 text-center text-xs font-semibold text-mute-400 transition hover:text-hanbok-400"
              >
                Instructor sign-in · MFA required
              </Link>
            </div>
          </div>
        )}
      </header>
      <JoinDialog open={join} onClose={() => setJoin(false)} />
    </>
  );
}

function NavLink({ href, label, pathname }: { href: string; label: string; pathname: string }) {
  const active = pathname === href || pathname.startsWith(`${href}/`);
  return (
    <Link
      href={href}
      className={cx(
        "relative rounded-full px-3.5 py-2 text-sm font-medium transition-colors",
        active ? "text-hanji-50" : "text-mute-300 hover:text-hanji-50",
      )}
    >
      {label}
      <span
        className={cx(
          "absolute inset-x-3 -bottom-0.5 h-px origin-left bg-[linear-gradient(90deg,#3ED6B0,#4C9BFF)] transition-transform duration-300",
          active ? "scale-x-100" : "scale-x-0",
        )}
      />
    </Link>
  );
}

export function SiteFooter() {
  const [join, setJoin] = useState(false);
  return (
    <>
      <footer className="relative mt-24 border-t border-hanji-200/10 bg-ink-950">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.4fr_1fr_1fr_1fr] lg:px-8">
          <div>
            <Logo />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-mute-400">
              A calm, structured way to learn Korean — Hangul first, conversation soon after. Built
              privacy-first: your camera is always your choice.
            </p>
            <p className="mt-4 text-xs text-mute-400">
              Operated by SeoulStep Learning · Seoul &amp; remote
            </p>
          </div>

          <FooterCol
            title="Learn"
            links={[
              ["/learn", "Dashboard"],
              ["/learn/tracks", "All lessons"],
              ["/flashcards", "Flashcards"],
              ["/progress", "Progress & badges"],
            ]}
          />
          <FooterCol
            title="Classroom"
            links={[
              ["/classroom", "Live sessions"],
              ["/#classroom", "How consent works"],
              ["/admin", "Instructor sign-in"],
            ]}
          />
          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.22em] text-hanji-100">Trust</h4>
            <ul className="mt-4 space-y-2.5 text-sm">
              <li>
                <Link href="/privacy" className="text-mute-400 transition hover:text-celadon-400">
                  Privacy practices
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-mute-400 transition hover:text-celadon-400">
                  Contact the site owner
                </Link>
              </li>
              <li>
                <button
                  onClick={() => setJoin(true)}
                  className="text-mute-400 transition hover:text-celadon-400"
                >
                  Redeem an invitation
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="hairline" />
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-6 text-xs text-mute-400 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
          <p>© {new Date().getFullYear()} SeoulStep. Served over HTTPS; media never recorded.</p>
          <p className="font-display">천 리 길도 한 걸음부터 · A thousand-mile road begins with one step.</p>
        </div>
      </footer>
      <JoinDialog open={join} onClose={() => setJoin(false)} />
    </>
  );
}

function FooterCol({ title, links }: { title: string; links: [string, string][] }) {
  return (
    <div>
      <h4 className="text-xs font-bold uppercase tracking-[0.22em] text-hanji-100">{title}</h4>
      <ul className="mt-4 space-y-2.5 text-sm">
        {links.map(([href, label]) => (
          <li key={href + label}>
            <Link href={href} className="text-mute-400 transition hover:text-celadon-400">
              {label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}