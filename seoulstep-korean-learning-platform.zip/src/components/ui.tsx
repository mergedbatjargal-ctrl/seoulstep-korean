"use client";

import Link from "next/link";
import { useEffect, useRef, useState, type ReactNode } from "react";

export function cx(...parts: (string | false | null | undefined)[]) {
  return parts.filter(Boolean).join(" ");
}

/* ── Reveal on scroll ─────────────────────────────────────────── */
export function Reveal({
  children,
  delay = 0,
  className,
  as: Tag = "div",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: "div" | "section" | "li" | "article";
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    if (typeof IntersectionObserver === "undefined") {
      setVisible(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setVisible(true);
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" },
    );
    io.observe(node);
    return () => io.disconnect();
  }, []);

  return (
    <Tag
      ref={ref as never}
      className={cx("reveal", visible && "is-visible", className)}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}

/* ── Buttons ─────────────────────────────────────────────────── */
type BtnVariant = "primary" | "secondary" | "ghost" | "danger" | "gold";

const btnBase =
  "inline-flex items-center justify-center gap-2 rounded-full font-semibold tracking-tight transition-all duration-300 active:scale-[0.97] disabled:opacity-45 disabled:pointer-events-none select-none";

const btnVariants: Record<BtnVariant, string> = {
  primary:
    "bg-[linear-gradient(120deg,#3ED6B0,#1FAE8C_55%,#4C9BFF)] text-ink-950 shadow-[0_10px_34px_-12px_rgba(62,214,176,0.85)] hover:shadow-[0_16px_44px_-12px_rgba(62,214,176,1)] hover:brightness-110",
  secondary:
    "border border-hanji-200/25 bg-ink-800/70 text-hanji-100 hover:border-celadon-500/60 hover:bg-ink-700/80",
  ghost: "text-mute-300 hover:text-hanji-50 hover:bg-ink-800/70",
  danger:
    "bg-[linear-gradient(120deg,#FF4D5E,#E0293F)] text-white shadow-[0_10px_30px_-12px_rgba(255,77,94,0.9)] hover:brightness-110",
  gold: "bg-[linear-gradient(120deg,#FFD071,#F5B841_60%,#D3921C)] text-ink-950 shadow-[0_10px_30px_-12px_rgba(245,184,65,0.9)] hover:brightness-110",
};

const btnSizes = {
  sm: "px-3.5 py-1.5 text-[13px]",
  md: "px-5 py-2.5 text-sm",
  lg: "px-7 py-3.5 text-[15px]",
};

export function Button({
  children,
  variant = "primary",
  size = "md",
  className,
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: BtnVariant;
  size?: keyof typeof btnSizes;
}) {
  return (
    <button className={cx(btnBase, btnVariants[variant], btnSizes[size], className)} {...rest}>
      {children}
    </button>
  );
}

export function LinkButton({
  children,
  variant = "primary",
  size = "md",
  className,
  href,
  ...rest
}: React.AnchorHTMLAttributes<HTMLAnchorElement> & {
  href: string;
  variant?: BtnVariant;
  size?: keyof typeof btnSizes;
}) {
  return (
    <Link
      href={href}
      className={cx(btnBase, btnVariants[variant], btnSizes[size], className)}
      {...rest}
    >
      {children}
    </Link>
  );
}

/* ── Chips / panels ───────────────────────────────────────────── */
export function Chip({
  children,
  tone = "#3ED6B0",
  className,
}: {
  children: ReactNode;
  tone?: string;
  className?: string;
}) {
  return (
    <span
      className={cx(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.14em]",
        className,
      )}
      style={{ borderColor: `${tone}55`, color: tone, background: `${tone}14` }}
    >
      {children}
    </span>
  );
}

export function SectionLabel({ children, tone = "#3ED6B0" }: { children: ReactNode; tone?: string }) {
  return (
    <div className="mb-3 flex items-center gap-3">
      <span className="h-px w-8" style={{ background: tone }} />
      <span
        className="text-[11px] font-bold uppercase tracking-[0.28em]"
        style={{ color: tone }}
      >
        {children}
      </span>
    </div>
  );
}

export function ProgressRing({
  value,
  size = 68,
  stroke = 6,
  tone = "#3ED6B0",
  label,
}: {
  value: number;
  size?: number;
  stroke?: number;
  tone?: string;
  label?: string;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(100, value));
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#26314A" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={tone}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c - (clamped / 100) * c}
          style={{ transition: "stroke-dashoffset 0.9s cubic-bezier(0.2,0.7,0.2,1)" }}
        />
      </svg>
      <span className="absolute text-center font-display text-sm font-bold text-hanji-50">
        {label ?? `${clamped}%`}
      </span>
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  children,
  tone = "#3ED6B0",
  wide = false,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  tone?: string;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center p-0 sm:items-center sm:p-6">
      <div
        className="absolute inset-0 bg-ink-950/80 backdrop-blur-sm fade"
        onClick={onClose}
        aria-hidden
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={cx(
          "relative w-full overflow-hidden rounded-t-3xl border border-hanji-200/15 bg-ink-850 shadow-2xl pop sm:rounded-3xl",
          wide ? "sm:max-w-2xl" : "sm:max-w-md",
        )}
      >
        <div
          className="h-1 w-full"
          style={{ background: `linear-gradient(90deg, ${tone}, transparent)` }}
        />
        <div className="flex items-center justify-between gap-4 px-5 pt-4 sm:px-6">
          <h3 className="font-display text-lg font-bold text-hanji-50">{title}</h3>
          <button
            onClick={onClose}
            aria-label="Close dialog"
            className="rounded-full border border-hanji-200/15 p-1.5 text-mute-300 transition hover:border-dancheong-500/60 hover:text-dancheong-400"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="max-h-[76vh] overflow-y-auto px-5 pb-6 pt-3 sm:px-6">{children}</div>
      </div>
    </div>
  );
}

export function Toast({ message, tone = "#3ED6B0" }: { message: string; tone?: string }) {
  return (
    <div
      className="pointer-events-none fixed bottom-5 left-1/2 z-[120] -translate-x-1/2 rounded-full border px-5 py-2.5 text-sm font-semibold shadow-2xl pop"
      style={{ borderColor: `${tone}66`, background: "#0E1320F2", color: tone }}
      role="status"
    >
      {message}
    </div>
  );
}