import {
  pgTable,
  text,
  timestamp,
  uuid,
  integer,
  boolean,
  jsonb,
  real,
  bigserial,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

/**
 * SeoulStep stores the minimum necessary data:
 *  - an account handle (display name + optional email)
 *  - learning progress
 *  - classroom presence + explicit camera-consent timestamps
 *  - an append-only audit log for admin/classroom access
 * No media is ever recorded or persisted.
 */

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    email: text("email"),
    displayName: text("display_name").notNull(),
    role: text("role").notNull().default("learner"), // 'learner' | 'instructor'
    passwordHash: text("password_hash"),
    totpSecret: text("totp_secret"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("users_email_unique").on(t.email)],
);

export const authSessions = pgTable(
  "auth_sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    role: text("role").notNull().default("learner"),
    mfaPending: boolean("mfa_pending").notNull().default(false),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    ip: text("ip"),
    userAgent: text("user_agent"),
  },
  (t) => [uniqueIndex("auth_sessions_token_unique").on(t.tokenHash)],
);

export const invitations = pgTable(
  "invitations",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    token: text("token").notNull(),
    /** Invitations are ALWAYS learner-scoped. There is no admin scope by design. */
    scope: text("scope").notNull().default("learner"),
    label: text("label").notNull(),
    lessonId: text("lesson_id"),
    classId: uuid("class_id"),
    createdBy: uuid("created_by").references(() => users.id, { onDelete: "set null" }),
    maxUses: integer("max_uses").notNull().default(50),
    uses: integer("uses").notNull().default(0),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("invitations_token_unique").on(t.token)],
);

export const progress = pgTable(
  "progress",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    lessonId: text("lesson_id").notNull(),
    status: text("status").notNull().default("in_progress"), // in_progress | completed
    step: integer("step").notNull().default(0),
    score: integer("score").notNull().default(0),
    bestScore: integer("best_score").notNull().default(0),
    secondsSpent: integer("seconds_spent").notNull().default(0),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("progress_user_lesson_unique").on(t.userId, t.lessonId)],
);

export const earnedBadges = pgTable(
  "earned_badges",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    badgeId: text("badge_id").notNull(),
    earnedAt: timestamp("earned_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("earned_badges_unique").on(t.userId, t.badgeId)],
);

export const cardReviews = pgTable(
  "card_reviews",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    cardId: text("card_id").notNull(),
    ease: real("ease").notNull().default(2.5),
    intervalDays: real("interval_days").notNull().default(0),
    reps: integer("reps").notNull().default(0),
    lapses: integer("lapses").notNull().default(0),
    dueAt: timestamp("due_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("card_reviews_unique").on(t.userId, t.cardId)],
);

export const classes = pgTable("classes", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: text("code").notNull(),
  title: text("title").notNull(),
  titleKo: text("title_ko").notNull().default(""),
  instructorId: uuid("instructor_id").references(() => users.id, { onDelete: "set null" }),
  lessonId: text("lesson_id"),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull().defaultNow(),
  status: text("status").notNull().default("scheduled"), // scheduled | live | ended
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const attendance = pgTable(
  "attendance",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    classId: uuid("class_id")
      .notNull()
      .references(() => classes.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    displayName: text("display_name").notNull(),
    joinedAt: timestamp("joined_at", { withTimezone: true }).notNull().defaultNow(),
    leftAt: timestamp("left_at", { withTimezone: true }),
    /** Set only when the learner takes an explicit action to enable their camera. */
    cameraConsentAt: timestamp("camera_consent_at", { withTimezone: true }),
    cameraOn: boolean("camera_on").notNull().default(false),
    micOn: boolean("mic_on").notNull().default(false),
    handRaised: boolean("hand_raised").notNull().default(false),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("attendance_unique").on(t.classId, t.userId), index("attendance_class_idx").on(t.classId)],
);

/** Ephemeral WebRTC signalling relay rows. Purged as they are consumed. */
export const signals = pgTable(
  "signals",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    classId: uuid("class_id")
      .notNull()
      .references(() => classes.id, { onDelete: "cascade" }),
    fromId: uuid("from_id").notNull(),
    toId: uuid("to_id").notNull(),
    kind: text("kind").notNull(), // offer | answer | ice | bye
    payload: jsonb("payload").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("signals_inbox_idx").on(t.classId, t.toId)],
);

export const auditLog = pgTable(
  "audit_log",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    actorId: uuid("actor_id"),
    actorLabel: text("actor_label").notNull(),
    action: text("action").notNull(),
    target: text("target"),
    severity: text("severity").notNull().default("info"), // info | notice | warning
    ip: text("ip"),
    meta: jsonb("meta"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("audit_created_idx").on(t.createdAt)],
);

export type User = typeof users.$inferSelect;
export type Invitation = typeof invitations.$inferSelect;
export type ProgressRow = typeof progress.$inferSelect;
export type AttendanceRow = typeof attendance.$inferSelect;
export type ClassRow = typeof classes.$inferSelect;
export type AuditRow = typeof auditLog.$inferSelect;