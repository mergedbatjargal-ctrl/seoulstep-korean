import { db } from "@/db";
import { auditLog } from "@/db/schema";

export type AuditSeverity = "info" | "notice" | "warning";

export async function recordAudit(entry: {
  actorId?: string | null;
  actorLabel: string;
  action: string;
  target?: string | null;
  severity?: AuditSeverity;
  ip?: string | null;
  meta?: Record<string, unknown> | null;
}) {
  try {
    await db.insert(auditLog).values({
      actorId: entry.actorId ?? null,
      actorLabel: entry.actorLabel,
      action: entry.action,
      target: entry.target ?? null,
      severity: entry.severity ?? "info",
      ip: entry.ip ?? null,
      meta: entry.meta ?? null,
    });
  } catch {
    // Audit writes must never break the user-facing flow.
  }
}