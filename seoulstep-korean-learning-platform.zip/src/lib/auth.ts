import crypto from "node:crypto";
import { cookies } from "next/headers";
import { db } from "@/db";
import { authSessions, users } from "@/db/schema";
import { and, eq, gt } from "drizzle-orm";

export const LEARNER_COOKIE = "seoulstep_learner";
export const ADMIN_COOKIE = "seoulstep_admin";

export type Role = "learner" | "instructor";

export function hashPassword(password: string, salt = crypto.randomBytes(16).toString("hex")) {
  const derived = crypto.scryptSync(password, salt, 64).toString("hex");
  return `scrypt$${salt}$${derived}`;
}

export function verifyPassword(password: string, stored: string | null): boolean {
  if (!stored) return false;
  const [scheme, salt, digest] = stored.split("$");
  if (scheme !== "scrypt" || !salt || !digest) return false;
  const derived = crypto.scryptSync(password, salt, 64).toString("hex");
  const a = Buffer.from(derived, "hex");
  const b = Buffer.from(digest, "hex");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export function hashToken(token: string) {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export function newToken() {
  return crypto.randomBytes(32).toString("base64url");
}

export function clientIp(headers: Headers) {
  return (
    headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    headers.get("x-real-ip") ||
    "local"
  );
}

type SessionOpts = {
  cookieName: string;
  role: Role;
  mfaPending?: boolean;
  ip?: string | null;
  userAgent?: string | null;
  ttlMs?: number;
};

export async function createSession(userId: string, opts: SessionOpts) {
  const token = newToken();
  const ttl = opts.ttlMs ?? 1000 * 60 * 60 * 12;
  await db.insert(authSessions).values({
    userId,
    tokenHash: hashToken(token),
    role: opts.role,
    mfaPending: opts.mfaPending ?? false,
    expiresAt: new Date(Date.now() + ttl),
    ip: opts.ip ?? null,
    userAgent: (opts.userAgent ?? "").slice(0, 200) || null,
  });
  const jar = await cookies();
  jar.set(opts.cookieName, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: Math.floor(ttl / 1000),
  });
  return token;
}

export async function readSession(cookieName: string, requireRole?: Role) {
  const jar = await cookies();
  const token = jar.get(cookieName)?.value;
  if (!token) return null;
  const rows = await db
    .select({
      sessionId: authSessions.id,
      mfaPending: authSessions.mfaPending,
      sessionRole: authSessions.role,
      userId: users.id,
      displayName: users.displayName,
      email: users.email,
      role: users.role,
      createdAt: users.createdAt,
    })
    .from(authSessions)
    .innerJoin(users, eq(users.id, authSessions.userId))
    .where(
      and(eq(authSessions.tokenHash, hashToken(token)), gt(authSessions.expiresAt, new Date())),
    )
    .limit(1);
  const row = rows[0];
  if (!row) return null;
  // Role-based access control: the account role must match the required role.
  if (requireRole && row.role !== requireRole) return null;
  if (requireRole && row.sessionRole !== requireRole) return null;
  return row;
}

export async function destroySession(cookieName: string) {
  const jar = await cookies();
  const token = jar.get(cookieName)?.value;
  if (token) {
    await db.delete(authSessions).where(eq(authSessions.tokenHash, hashToken(token)));
  }
  jar.set(cookieName, "", { path: "/", maxAge: 0 });
}

export async function requireLearner() {
  return readSession(LEARNER_COOKIE, "learner");
}

/** Admin access requires a real instructor account AND a fully verified MFA session. */
export async function requireAdmin() {
  const session = await readSession(ADMIN_COOKIE, "instructor");
  if (!session || session.mfaPending) return null;
  return session;
}

export async function promoteSessionToVerified(cookieName: string) {
  const jar = await cookies();
  const token = jar.get(cookieName)?.value;
  if (!token) return false;
  const updated = await db
    .update(authSessions)
    .set({ mfaPending: false })
    .where(eq(authSessions.tokenHash, hashToken(token)))
    .returning({ id: authSessions.id });
  return updated.length > 0;
}