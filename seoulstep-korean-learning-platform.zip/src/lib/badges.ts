import { BADGES, LESSONS, lessonsByTrack } from "@/lib/curriculum";

export type BadgeContext = {
  completedLessonIds: string[];
  perfectLessonIds: string[];
  cardsReviewed: number;
  joinedClass: boolean;
};

export function evaluateBadges(ctx: BadgeContext): string[] {
  const earned: string[] = [];
  const done = new Set(ctx.completedLessonIds);
  const perfect = new Set(ctx.perfectLessonIds);

  if (done.size >= 1) earned.push("first-step");
  if (lessonsByTrack("hangul").every((l) => done.has(l.id))) earned.push("hangul-reader");
  if (lessonsByTrack("listening").some((l) => perfect.has(l.id))) earned.push("sharp-ear");
  if (perfect.size >= 1) earned.push("perfect-score");
  if (ctx.cardsReviewed >= 20) earned.push("reviewer");
  if (lessonsByTrack("conversation").every((l) => done.has(l.id))) earned.push("talker");
  if (ctx.joinedClass) earned.push("class-goer");
  if (done.size >= 6) earned.push("trailblazer");

  return earned.filter((id) => BADGES.some((b) => b.id === id));
}

export function overallPercent(completedLessonIds: string[]) {
  return Math.round((completedLessonIds.length / LESSONS.length) * 100);
}

export function formatRelative(date: Date | string | null | undefined) {
  if (!date) return "—";
  const d = typeof date === "string" ? new Date(date) : date;
  const diff = Date.now() - d.getTime();
  const abs = Math.abs(diff);
  const min = 60_000;
  const hr = 3_600_000;
  const day = 86_400_000;
  if (abs < min) return "just now";
  if (abs < hr) return `${Math.round(abs / min)}m ${diff > 0 ? "ago" : "from now"}`;
  if (abs < day) return `${Math.round(abs / hr)}h ${diff > 0 ? "ago" : "from now"}`;
  if (abs < day * 7) return `${Math.round(abs / day)}d ${diff > 0 ? "ago" : "from now"}`;
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}