export type TrackId =
  | "hangul"
  | "pronunciation"
  | "vocabulary"
  | "grammar"
  | "listening"
  | "conversation";

export type Track = {
  id: TrackId;
  name: string;
  nameKo: string;
  blurb: string;
  hue: string;
  glyph: string;
};

export type LessonBlock =
  | { kind: "note"; title: string; body: string }
  | { kind: "glyphs"; title: string; items: { char: string; roman: string; hint: string }[] }
  | { kind: "vocab"; title: string; items: { ko: string; roman: string; en: string }[] }
  | { kind: "dialogue"; title: string; lines: { who: string; ko: string; roman: string; en: string }[] }
  | { kind: "tip"; title: string; body: string };

export type QuizQuestion = {
  id: string;
  prompt: string;
  promptKo?: string;
  choices: string[];
  answer: number;
  explain: string;
};

export type Lesson = {
  id: string;
  track: TrackId;
  title: string;
  titleKo: string;
  level: "Starter" | "Beginner" | "Elementary";
  minutes: number;
  summary: string;
  blocks: LessonBlock[];
  quiz: QuizQuestion[];
};

export type Flashcard = {
  id: string;
  deck: string;
  front: string;
  roman: string;
  back: string;
  example: string;
  exampleEn: string;
};

export type Badge = {
  id: string;
  name: string;
  nameKo: string;
  desc: string;
  glyph: string;
  hue: string;
};

export const TRACKS: Track[] = [
  {
    id: "hangul",
    name: "Hangul",
    nameKo: "한글",
    blurb: "Read and write the Korean alphabet from the first stroke.",
    hue: "#3ED6B0",
    glyph: "ㅎ",
  },
  {
    id: "pronunciation",
    name: "Pronunciation",
    nameKo: "발음",
    blurb: "Sound rules, batchim, and the plain–aspirated–tense triad.",
    hue: "#FF4D5E",
    glyph: "ㅆ",
  },
  {
    id: "vocabulary",
    name: "Vocabulary",
    nameKo: "어휘",
    blurb: "High-frequency words grouped by where you'll actually use them.",
    hue: "#F5B841",
    glyph: "말",
  },
  {
    id: "grammar",
    name: "Grammar",
    nameKo: "문법",
    blurb: "Particles, verb endings, and polite sentence patterns.",
    hue: "#4C9BFF",
    glyph: "은",
  },
  {
    id: "listening",
    name: "Listening",
    nameKo: "듣기",
    blurb: "Train your ear with natural-speed audio and dictation.",
    hue: "#C77DFF",
    glyph: "듣",
  },
  {
    id: "conversation",
    name: "Conversation",
    nameKo: "회화",
    blurb: "Scripted dialogues you can reuse the moment you land in Seoul.",
    hue: "#FF3D9A",
    glyph: "회",
  },
];

export const LESSONS: Lesson[] = [
  {
    id: "hangul-vowels",
    track: "hangul",
    title: "The 10 basic vowels",
    titleKo: "기본 모음 10개",
    level: "Starter",
    minutes: 8,
    summary:
      "Hangul was designed in 1443 so that anyone could learn it in a morning. Start with the vowels — each one is a picture of sky, earth, and a human standing between them.",
    blocks: [
      {
        kind: "note",
        title: "Three strokes, three ideas",
        body: "Every Hangul vowel is built from three elements: a short vertical or horizontal stroke for the human (ㅣ), a stroke for the flat earth (ㅡ), and a dot for the sky (ㆍ). In modern writing the sky-dot became a short tick. Learn the shape as a picture and the sound follows.",
      },
      {
        kind: "glyphs",
        title: "Read these out loud",
        items: [
          { char: "ㅏ", roman: "a", hint: "father" },
          { char: "ㅑ", roman: "ya", hint: "yard" },
          { char: "ㅓ", roman: "eo", hint: "the 'u' in up" },
          { char: "ㅕ", roman: "yeo", hint: "young" },
          { char: "ㅗ", roman: "o", hint: "old" },
          { char: "ㅛ", roman: "yo", hint: "yoyo" },
          { char: "ㅜ", roman: "u", hint: "moon" },
          { char: "ㅠ", roman: "yu", hint: "you" },
          { char: "ㅡ", roman: "eu", hint: "no English match — flat lips" },
          { char: "ㅣ", roman: "i", hint: "see" },
        ],
      },
      {
        kind: "tip",
        title: "The tick points at the sound",
        body: "If the short tick points outward (ㅏ, ) the vowel is 'bright'. If it points inward (ㅓ, ㅜ) it is 'dark'. This bright/dark split later decides which verb ending you attach — so noticing it now saves you weeks.",
      },
      {
        kind: "vocab",
        title: "Vowels in real words",
        items: [
          { ko: "아이", roman: "a-i", en: "child" },
          { ko: "우유", roman: "u-yu", en: "milk" },
          { ko: "오이", roman: "o-i", en: "cucumber" },
          { ko: "여우", roman: "yeo-u", en: "fox" },
        ],
      },
    ],
    quiz: [
      {
        id: "hv1",
        prompt: "Which vowel is romanised as 'eo'?",
        choices: ["ㅏ", "ㅓ", "ㅗ", "ㅡ"],
        answer: 1,
        explain: "ㅓ is 'eo' — the tick points left, toward the inside, so it is a dark vowel.",
      },
      {
        id: "hv2",
        prompt: "What does 우유 mean?",
        promptKo: "우유",
        choices: ["fox", "child", "milk", "cucumber"],
        answer: 2,
        explain: "우유 (u-yu) is milk. 여우 (yeo-u) is fox — one tick changes everything.",
      },
      {
        id: "hv3",
        prompt: "Which pair are both 'bright' vowels?",
        choices: ["ㅓ and ㅜ", "ㅏ and ㅗ", "ㅡ and ㅣ", "ㅕ and ㅠ"],
        answer: 1,
        explain: "ㅏ and ㅗ both have the tick pointing outward, making them bright vowels.",
      },
      {
        id: "hv4",
        prompt: "The three design elements of Hangul vowels represent…",
        choices: [
          "sun, moon, star",
          "sky, earth, human",
          "water, fire, wood",
          "past, present, future",
        ],
        answer: 1,
        explain: "Sky (dot), earth (flat stroke), and human (upright stroke) — the core of Hunminjeongeum.",
      },
    ],
  },
  {
    id: "hangul-consonants",
    track: "hangul",
    title: "Consonants shaped like your mouth",
    titleKo: "자음의 모양",
    level: "Starter",
    minutes: 10,
    summary:
      "Korean consonants are diagrams. ㄱ is the back of the tongue blocking the throat, ㅁ is the outline of the lips, ㅅ is the teeth. Once you see it, you cannot unsee it.",
    blocks: [
      {
        kind: "glyphs",
        title: "The 14 basic consonants",
        items: [
          { char: "ㄱ", roman: "g / k", hint: "tongue root blocks throat" },
          { char: "ㄴ", roman: "n", hint: "tongue touches the ridge" },
          { char: "ㅁ", roman: "m", hint: "shape of the mouth" },
          { char: "ㅅ", roman: "s", hint: "shape of a tooth" },
          { char: "ㅇ", roman: "ng / silent", hint: "shape of the throat" },
          { char: "ㅈ", roman: "j", hint: "ㄴ + the sky dot" },
          { char: "ㅊ", roman: "ch", hint: "ㅈ with extra aspiration" },
          { char: "ㅋ", roman: "k", hint: "ㄱ with extra aspiration" },
          { char: "ㅌ", roman: "t", hint: "ㄷ with extra aspiration" },
          { char: "ㅍ", roman: "p", hint: "ㅂ with extra aspiration" },
          { char: "ㅎ", roman: "h", hint: "a hat, a throat, open air" },
          { char: "ㄷ", roman: "d / t", hint: "ㄴ with one more stroke" },
          { char: "ㄹ", roman: "r / l", hint: "the tongue curling" },
          { char: "ㅂ", roman: "b / p", hint: "ㅁ with a stroke on top" },
        ],
      },
      {
        kind: "note",
        title: "Syllables are stacked blocks",
        body: "Hangul is not written in a line of letters — it is packed into square syllable blocks. 가 = ㄱ + ㅏ. 한 = ㅎ + ㅏ + . The final consonant at the bottom is called batchim (받침), literally 'supporting floor'.",
      },
      {
        kind: "vocab",
        title: "Build your first words",
        items: [
          { ko: "나", roman: "na", en: "I / me" },
          { ko: "너", roman: "neo", en: "you (casual)" },
          { ko: "물", roman: "mul", en: "water" },
          { ko: "사람", roman: "sa-ram", en: "person" },
          { ko: "한국", roman: "han-guk", en: "Korea" },
        ],
      },
    ],
    quiz: [
      {
        id: "hc1",
        prompt: "Which consonant is drawn as the shape of the mouth?",
        choices: ["ㅇ", "ㅁ", "ㅅ", "ㅎ"],
        answer: 1,
        explain: "ㅁ is the outline of the lips. ㅇ is the throat.",
      },
      {
        id: "hc2",
        prompt: "What is the final consonant of a syllable block called?",
        choices: ["Jamo", "Batchim", "Ssang", "Jaeum"],
        answer: 1,
        explain: "받침 batchim — literally 'supporting floor'.",
      },
      {
        id: "hc3",
        prompt: "How is 한국 romanised?",
        promptKo: "한국",
        choices: ["han-guk", "kan-kuk", "han-kuk", "hang-ook"],
        answer: 0,
        explain: "한국 = han-guk. The ㄱ between vowels voices to a 'g'.",
      },
    ],
  },
  {
    id: "hangul-batchim",
    track: "hangul",
    title: "Batchim and double consonants",
    titleKo: "받침과 쌍자음",
    level: "Beginner",
    minutes: 12,
    summary:
      "Final consonants change their sound at the bottom of a block, and the five tense consonants (ㄲ ㄸ ㅃ ㅆ ㅉ) sit in a register English does not have.",
    blocks: [
      {
        kind: "note",
        title: "Seven sounds only",
        body: "Although many consonants can sit in batchim position, only seven sounds survive there: ㄱ, , ㄷ, ㄹ, ㅁ, , ㅇ. So 옷, 옫, 옺 all end as an unreleased [t].",
      },
      {
        kind: "glyphs",
        title: "The five tense consonants",
        items: [
          { char: "ㄲ", roman: "kk", hint: "tight, no puff of air" },
          { char: "ㄸ", roman: "tt", hint: "tight t" },
          { char: "ㅃ", roman: "pp", hint: "tight p" },
          { char: "ㅆ", roman: "ss", hint: "tight s" },
          { char: "ㅉ", roman: "jj", hint: "tight j" },
        ],
      },
      {
        kind: "vocab",
        title: "Minimal pairs — listen for the tension",
        items: [
          { ko: "달", roman: "dal", en: "moon" },
          { ko: "딸", roman: "ttal", en: "daughter" },
          { ko: "탈", roman: "tal", en: "mask" },
          { ko: "불", roman: "bul", en: "fire" },
          { ko: "뿔", roman: "ppul", en: "horn" },
        ],
      },
      {
        kind: "tip",
        title: "Hold your breath, then release",
        body: "For tense consonants, tighten your throat a beat before the sound and let it out with zero airflow. Native speakers hear 달 / 딸 / 탈 as three completely different words.",
      },
    ],
    quiz: [
      {
        id: "hb1",
        prompt: "How many distinct sounds can appear in batchim position?",
        choices: ["5", "7", "14", "19"],
        answer: 1,
        explain: "Seven: ㄱ ㄴ ㄷ ㄹ ㅁ ㅂ ㅇ.",
      },
      {
        id: "hb2",
        prompt: "딸 means…",
        promptKo: "딸",
        choices: ["moon", "mask", "daughter", "fire"],
        answer: 2,
        explain: "딸 (ttal) = daughter. 달 = moon, 탈 = mask.",
      },
      {
        id: "hb3",
        prompt: "Tense consonants are produced with…",
        choices: [
          "a strong puff of air",
          "a tightened throat and no airflow",
          "a longer vowel",
          "nasal resonance",
        ],
        answer: 1,
        explain: "No aspiration at all — just tension.",
      },
    ],
  },
  {
    id: "pron-triad",
    track: "pronunciation",
    title: "Plain, aspirated, tense",
    titleKo: "예사소리·거센소리·된소리",
    level: "Beginner",
    minutes: 9,
    summary:
      "Korean splits stops three ways where English splits them two. This one distinction unlocks most of the accent problems beginners have.",
    blocks: [
      {
        kind: "note",
        title: "The three-way split",
        body: "Plain (ㄱ ㄷ ㅂ ㅈ) is soft and voices between vowels. Aspirated (ㅋ ㅌ ㅍ ㅊ) carries a strong puff of air. Tense (ㄲ  ㅃ ㅉ) is clipped and tight. Hold a tissue in front of your mouth: it should barely move for plain, jump for aspirated, and stay still for tense.",
      },
      {
        kind: "vocab",
        title: "Drill the triad",
        items: [
          { ko: "자다", roman: "ja-da", en: "to sleep" },
          { ko: "차다", roman: "cha-da", en: "to kick / to be cold" },
          { ko: "짜다", roman: "jja-da", en: "to be salty" },
          { ko: "팔", roman: "pal", en: "arm" },
          { ko: "빨", roman: "ppal", en: "(root of) to suck" },
        ],
      },
      {
        kind: "tip",
        title: "Pitch is the hidden cue",
        body: "In Seoul Korean, plain consonants start on a lower pitch and aspirated ones start higher. Many learners are understood because of pitch, not airflow. Try saying 차다 with a rising start.",
      },
    ],
    quiz: [
      {
        id: "pt1",
        prompt: "Which set is aspirated?",
        choices: ["ㄱ ㄷ ㅂ", "ㅋ ㅌ ㅍ", "ㄲ ㄸ ㅃ", "ㅁ ㄴ ㅇ"],
        answer: 1,
        explain: "ㅋ ㅌ ㅍ ㅊ carry the strong puff of air.",
      },
      {
        id: "pt2",
        prompt: "짜다 means…",
        promptKo: "짜다",
        choices: ["to sleep", "to kick", "to be salty", "to write"],
        answer: 2,
        explain: "짜다 = salty. 자다 = sleep, 차다 = kick.",
      },
      {
        id: "pt3",
        prompt: "A quick physical test for aspiration is…",
        choices: [
          "hold a tissue in front of the mouth",
          "hum the syllable",
          "whisper it",
          "clap on the beat",
        ],
        answer: 0,
        explain: "The tissue jumps for aspirated sounds and stays still for tense ones.",
      },
    ],
  },
  {
    id: "pron-rules",
    track: "pronunciation",
    title: "Sound-change rules that matter",
    titleKo: "음운 규칙",
    level: "Elementary",
    minutes: 11,
    summary:
      "Korean spelling is stable but speech flows. Four rules — linking, nasalisation, tensification, and ㅎ-weakening — cover the vast majority of surprises.",
    blocks: [
      {
        kind: "note",
        title: "1. Linking (연음)",
        body: "When a batchim is followed by a syllable starting with ㅇ, the consonant slides over. 음악 → [으막]. 있어요 → [이써요].",
      },
      {
        kind: "note",
        title: "2. Nasalisation (비음화)",
        body: "Stops meeting ㄴ or ㅁ turn nasal. 감사합니다 → [감사함니다]. 국물 → [궁물].",
      },
      {
        kind: "note",
        title: "3. Tensification (경음화)",
        body: "After a stop batchim, a following plain consonant hardens. 학교 → [학꾜]. 식당 → [식땅].",
      },
      {
        kind: "dialogue",
        title: "Hear it in a sentence",
        lines: [
          { who: "A", ko: "한국 음식 좋아하세요?", roman: "han-guk eum-sik jo-a-ha-se-yo?", en: "Do you like Korean food?" },
          { who: "B", ko: "네, 특히 김치찌개요.", roman: "ne, teu-ki gim-chi-jji-gae-yo.", en: "Yes, especially kimchi stew." },
        ],
      },
    ],
    quiz: [
      {
        id: "pr1",
        prompt: "감사합니다 is actually pronounced…",
        promptKo: "감사합니다",
        choices: ["[감사합니다]", "[감사함니다]", "[감사함니따]", "[감사암니다]"],
        answer: 1,
        explain: "ㅂ before ㄴ nasalises to ㅁ → [감사함니다].",
      },
      {
        id: "pr2",
        prompt: "학교 → [학꾜] is an example of…",
        choices: ["linking", "nasalisation", "tensification", "ㅎ-weakening"],
        answer: 2,
        explain: "The ㄱ batchim hardens the following ㄱ into .",
      },
      {
        id: "pr3",
        prompt: "있어요 is pronounced…",
        promptKo: "있어요",
        choices: ["[읻서요]", "[이써요]", "[이써여]", "[읻어요]"],
        answer: 1,
        explain: "Linking moves ㅆ over, then ㅓ+ㅆ tenses → [이써요].",
      },
    ],
  },
  {
    id: "vocab-cafe",
    track: "vocabulary",
    title: "Café & ordering",
    titleKo: "카페에서 주문하기",
    level: "Beginner",
    minutes: 7,
    summary:
      "Korea has roughly 100,000 cafés. These twenty words cover almost every transaction you'll have in one.",
    blocks: [
      {
        kind: "vocab",
        title: "Order words",
        items: [
          { ko: "아메리카노", roman: "a-me-ri-ka-no", en: "americano" },
          { ko: "라떼", roman: "ra-tte", en: "latte" },
          { ko: "주세요", roman: "ju-se-yo", en: "please give me" },
          { ko: "포장이요", roman: "po-jang-i-yo", en: "to go, please" },
          { ko: "여기요", roman: "yeo-gi-yo", en: "excuse me (over here)" },
          { ko: "얼마예요?", roman: "eol-ma-ye-yo?", en: "how much is it?" },
          { ko: "영수증", roman: "yeong-su-jeung", en: "receipt" },
          { ko: "빨대", roman: "ppal-dae", en: "straw" },
        ],
      },
      {
        kind: "dialogue",
        title: "At the counter",
        lines: [
          { who: "직원", ko: "어서 오세요! 주문하시겠어요?", roman: "eo-seo o-se-yo! ju-mun-ha-si-ge-sseo-yo?", en: "Welcome! Would you like to order?" },
          { who: "나", ko: "아이스 아메리카노 한 잔 주세요.", roman: "a-i-seu a-me-ri-ka-no han jan ju-se-yo.", en: "One iced americano, please." },
          { who: "직원", ko: "매장에서 드시나요, 포장이신가요?", roman: "mae-jang-e-seo deu-si-na-yo, po-jang-i-sin-ga-yo?", en: "For here or to go?" },
          { who: "나", ko: "포장이요. 감사합니다!", roman: "po-jang-i-yo. gam-sa-ham-ni-da!", en: "To go. Thank you!" },
        ],
      },
      {
        kind: "tip",
        title: "Counters change with the cup",
        body: "한 잔 (one glass/cup), 두 잔 (two cups). 잔 is the counter for drinks; 개 is the general counter. Saying 한 개 for coffee is understood but sounds off.",
      },
    ],
    quiz: [
      {
        id: "vc1",
        prompt: "How do you say 'to go, please'?",
        choices: ["여기요", "포장이요", "주세요", "영수증"],
        answer: 1,
        explain: "포장이요 = to go. 매장이요 = for here.",
      },
      {
        id: "vc2",
        prompt: "한 잔 means…",
        choices: ["one cup", "one person", "one won", "one o'clock"],
        answer: 0,
        explain: "잔 is the counter for cups and glasses.",
      },
      {
        id: "vc3",
        prompt: "Which word gets a staff member's attention?",
        choices: ["영수증", "빨대", "여기요", "라떼"],
        answer: 2,
        explain: "여기요 — literally 'over here'.",
      },
    ],
  },
  {
    id: "vocab-numbers",
    track: "vocabulary",
    title: "Two number systems",
    titleKo: "숫자 두 가지",
    level: "Beginner",
    minutes: 10,
    summary:
      "Korean counts with two sets of numbers. Native Korean for things and ages, Sino-Korean for money, dates, and minutes.",
    blocks: [
      {
        kind: "note",
        title: "Which one, when?",
        body: "Use native (하나, 둘, 셋…) for counting objects, people, and your age. Use Sino (일, 이, 삼…) for money, phone numbers, minutes, months, and floors. Hours use native, minutes use Sino — 세 시 삼십 분 (3:30).",
      },
      {
        kind: "glyphs",
        title: "Native Korean 1–10",
        items: [
          { char: "하나", roman: "ha-na", hint: "1 — becomes 한 before a counter" },
          { char: "둘", roman: "dul", hint: "2 — 두" },
          { char: "셋", roman: "set", hint: "3 — 세" },
          { char: "넷", roman: "net", hint: "4 — 네" },
          { char: "다섯", roman: "da-seot", hint: "5" },
          { char: "여섯", roman: "yeo-seot", hint: "6" },
          { char: "일곱", roman: "il-gop", hint: "7" },
          { char: "여덟", roman: "yeo-deol", hint: "8" },
          { char: "아홉", roman: "a-hop", hint: "9" },
          { char: "열", roman: "yeol", hint: "10" },
        ],
      },
      {
        kind: "vocab",
        title: "Sino-Korean 1–10",
        items: [
          { ko: "일", roman: "il", en: "1" },
          { ko: "이", roman: "i", en: "2" },
          { ko: "삼", roman: "sam", en: "3" },
          { ko: "사", roman: "sa", en: "4" },
          { ko: "오", roman: "o", en: "5" },
          { ko: "육", roman: "yuk", en: "6" },
          { ko: "칠", roman: "chil", en: "7" },
          { ko: "팔", roman: "pal", en: "8" },
          { ko: "구", roman: "gu", en: "9" },
          { ko: "십", roman: "sip", en: "10" },
        ],
      },
    ],
    quiz: [
      {
        id: "vn1",
        prompt: "Which system do you use for your age?",
        choices: ["Sino-Korean", "Native Korean", "Either", "Neither"],
        answer: 1,
        explain: "스무 살 — native Korean with the counter 살.",
      },
      {
        id: "vn2",
        prompt: "3:30 is read as…",
        choices: ["삼 시 셋십 분", "세 시 삼십 분", "셋 시 서른 분", "삼 시 서른 분"],
        answer: 1,
        explain: "Hours native (세 시), minutes Sino (삼십 분).",
      },
      {
        id: "vn3",
        prompt: "하나 becomes what before a counter?",
        choices: ["하", "한", "햇", "할"],
        answer: 1,
        explain: "하나 → 한, 둘 → 두, 셋 → 세, 넷 → 네, 스물 → 스무.",
      },
    ],
  },
  {
    id: "grammar-particles",
    track: "grammar",
    title: "Topic and subject particles",
    titleKo: "은/는 그리고 이/가",
    level: "Beginner",
    minutes: 12,
    summary:
      "The single most confusing pair for English speakers. 는 marks what you're talking about; 가 marks who or what does it.",
    blocks: [
      {
        kind: "note",
        title: "은/는 — the topic marker",
        body: "Use 은 after a consonant, 는 after a vowel. It sets the stage: 'As for X…'. It often carries contrast. 저는 학생이에요 = 'As for me, I'm a student.'",
      },
      {
        kind: "note",
        title: "이/가 — the subject marker",
        body: "Use 이 after a consonant, 가 after a vowel. It spotlights new information or the doer. 비가 와요 = 'Rain is falling' (news, not contrast).",
      },
      {
        kind: "dialogue",
        title: "Feel the difference",
        lines: [
          { who: "A", ko: "누가 왔어요?", roman: "nu-ga wa-sseo-yo?", en: "Who came?" },
          { who: "B", ko: "민수가 왔어요.", roman: "min-su-ga wa-sseo-yo.", en: "Minsu came." },
          { who: "A", ko: "민수는 언제 와요?", roman: "min-su-neun eon-je wa-yo?", en: "And as for Minsu, when is he coming?" },
        ],
      },
      {
        kind: "tip",
        title: "A rule of thumb that survives contact",
        body: "First mention → 이/가. Second mention, or a contrast → 은/는. 'A cat came in. The cat was black.' → 고양이가 들어왔어요. 고양이는 검은색이었어요.",
      },
    ],
    quiz: [
      {
        id: "gp1",
        prompt: "저___ 학생이에요.",
        promptKo: "저___ 학생이에요.",
        choices: ["가", "는", "이", "를"],
        answer: 1,
        explain: "저 ends in a vowel → 는. Topic marker for 'as for me'.",
      },
      {
        id: "gp2",
        prompt: "Which sentence introduces new information?",
        choices: ["비가 와요", "비는 와요", "비은 와요", "비을 와요"],
        answer: 0,
        explain: "New information takes 이/가 → 비가 와요.",
      },
      {
        id: "gp3",
        prompt: "After a word ending in a consonant you attach…",
        choices: ["는 and 가", "은 and 이", "은 and 가", "는 and 이"],
        answer: 1,
        explain: "은 / 이 follow consonants; 는 / 가 follow vowels.",
      },
    ],
  },
  {
    id: "grammar-polite",
    track: "grammar",
    title: "Polite present tense -아요/어요",
    titleKo: "해요체 현재형",
    level: "Beginner",
    minutes: 10,
    summary:
      "One ending covers almost every everyday sentence. Learn the bright/dark vowel rule and you can conjugate any verb you meet.",
    blocks: [
      {
        kind: "note",
        title: "The rule",
        body: "Drop 다 from the dictionary form. If the last stem vowel is ㅏ or ㅗ, add 아요. Otherwise add 어요. Verbs ending in 하 always become 해요.",
      },
      {
        kind: "vocab",
        title: "Conjugate along",
        items: [
          { ko: "가다 → 가요", roman: "ga-da → ga-yo", en: "to go → go" },
          { ko: "오다 → 와요", roman: "o-da → wa-yo", en: "to come → come" },
          { ko: "먹다 → 먹어요", roman: "meok-da → meo-geo-yo", en: "to eat → eat" },
          { ko: "마시다 → 마셔요", roman: "ma-si-da → ma-syeo-yo", en: "to drink → drink" },
          { ko: "공부하다 → 공부해요", roman: "gong-bu-ha-da → gong-bu-hae-yo", en: "to study → study" },
          { ko: "좋다 → 좋아요", roman: "jo-ta → jo-a-yo", en: "to be good → is good" },
        ],
      },
      {
        kind: "tip",
        title: "Past tense is the same move",
        body: "Swap 요 for ㅆ어요/았어요: 갔어요, 먹었어요, 공부했어요. Learn the present and the past comes free.",
      },
    ],
    quiz: [
      {
        id: "gq1",
        prompt: "먹다 in polite present is…",
        promptKo: "먹다",
        choices: ["먹아요", "먹어요", "먹해요", "먹고요"],
        answer: 1,
        explain: "The stem vowel ㅓ is dark → 어요.",
      },
      {
        id: "gq2",
        prompt: "공부하다 becomes…",
        choices: ["공부하아요", "공부해요", "공부허요", "공부하고요"],
        answer: 1,
        explain: "하 + 여요 contracts to 해요, always.",
      },
      {
        id: "gq3",
        prompt: "Past tense of 가요 is…",
        choices: ["가었어요", "갔어요", "가했어요", "가고요"],
        answer: 1,
        explain: "가 + 았어요 contracts to 갔어요.",
      },
    ],
  },
  {
    id: "listen-dictation",
    track: "listening",
    title: "Dictation: subway announcements",
    titleKo: "지하철 안내 방송",
    level: "Elementary",
    minutes: 9,
    summary:
      "Announcements use a fixed vocabulary. Learn fifteen phrases and you'll navigate any line in Seoul.",
    blocks: [
      {
        kind: "note",
        title: "Listen before you read",
        body: "Tap play on each line and try to catch it before revealing the romanisation. Your ear improves fastest when it works before your eyes.",
      },
      {
        kind: "dialogue",
        title: "Line 2, eastbound",
        lines: [
          { who: "방송", ko: "이번 역은 강남, 강남역입니다.", roman: "i-beon yeo-geun gang-nam, gang-nam-yeo-gim-ni-da.", en: "This station is Gangnam, Gangnam Station." },
          { who: "방송", ko: "내리실 문은 오른쪽입니다.", roman: "nae-ri-sil mu-neun o-reun-jjo-gim-ni-da.", en: "The doors will open on the right." },
          { who: "방송", ko: "다음 역은 역삼역입니다.", roman: "da-eum yeo-geun yeok-sam-yeo-gim-ni-da.", en: "The next station is Yeoksam." },
          { who: "방송", ko: "출입문을 조심하십시오.", roman: "chu-rim-mu-neun jo-sim-ha-sip-si-o.", en: "Please be careful of the doors." },
        ],
      },
      {
        kind: "vocab",
        title: "Announcement vocabulary",
        items: [
          { ko: "이번 역", roman: "i-beon yeok", en: "this station" },
          { ko: "다음 역", roman: "da-eum yeok", en: "next station" },
          { ko: "오른쪽 / 왼쪽", roman: "o-reun-jjok / oen-jjok", en: "right / left" },
          { ko: "환승", roman: "hwan-seung", en: "transfer" },
          { ko: "출구", roman: "chul-gu", en: "exit" },
        ],
      },
    ],
    quiz: [
      {
        id: "ld1",
        prompt: "내리실 문은 오른쪽입니다 tells you…",
        choices: [
          "the next station",
          "the doors open on the right",
          "please transfer here",
          "mind the gap",
        ],
        answer: 1,
        explain: "오른쪽 = right-hand side.",
      },
      {
        id: "ld2",
        prompt: "환승 means…",
        promptKo: "환승",
        choices: ["exit", "transfer", "platform", "fare"],
        answer: 1,
        explain: "환승 = transfer between lines.",
      },
      {
        id: "ld3",
        prompt: "'다음 역' refers to…",
        choices: ["this station", "the last station", "the next station", "the terminal"],
        answer: 2,
        explain: "다음 = next.",
      },
    ],
  },
  {
    id: "conv-introductions",
    track: "conversation",
    title: "Introducing yourself",
    titleKo: "자기소개",
    level: "Starter",
    minutes: 8,
    summary:
      "Four sentences that open every first conversation: greeting, name, origin, and a polite closer.",
    blocks: [
      {
        kind: "dialogue",
        title: "First meeting",
        lines: [
          { who: "지은", ko: "안녕하세요! 처음 뵙겠습니다.", roman: "an-nyeong-ha-se-yo! cheo-eum boep-get-seum-ni-da.", en: "Hello! Nice to meet you (first time)." },
          { who: "나", ko: "안녕하세요. 저는 알렉스예요.", roman: "an-nyeong-ha-se-yo. jeo-neun al-lek-seu-ye-yo.", en: "Hello. I'm Alex." },
          { who: "지은", ko: "어디에서 오셨어요?", roman: "eo-di-e-seo o-syeo-sseo-yo?", en: "Where are you from?" },
          { who: "나", ko: "미국에서 왔어요. 잘 부탁드립니다!", roman: "mi-gu-ge-seo wa-sseo-yo. jal bu-tak-deu-rim-ni-da!", en: "I'm from the US. Please treat me well!" },
        ],
      },
      {
        kind: "vocab",
        title: "Countries",
        items: [
          { ko: "한국", roman: "han-guk", en: "Korea" },
          { ko: "미국", roman: "mi-guk", en: "USA" },
          { ko: "영국", roman: "yeong-guk", en: "UK" },
          { ko: "일본", roman: "il-bon", en: "Japan" },
          { ko: "중국", roman: "jung-guk", en: "China" },
          { ko: "프랑스", roman: "peu-rang-seu", en: "France" },
        ],
      },
      {
        kind: "tip",
        title: "잘 부탁드립니다 has no English equivalent",
        body: "Literally 'I ask you to look after me well'. Use it at the end of any first meeting — it lands as warmth and humility, and Koreans use it constantly.",
      },
    ],
    quiz: [
      {
        id: "ci1",
        prompt: "처음 뵙겠습니다 is used…",
        choices: [
          "when leaving",
          "at a first meeting",
          "when apologising",
          "when ordering food",
        ],
        answer: 1,
        explain: "It is the formal 'nice to meet you' for a first encounter.",
      },
      {
        id: "ci2",
        prompt: "'Where are you from?' is…",
        choices: [
          "이름이 뭐예요?",
          "어디에서 오셨어요?",
          "몇 살이에요?",
          "뭐 하세요?",
        ],
        answer: 1,
        explain: "어디에서 오셨어요? — literally 'from where did you come?'",
      },
      {
        id: "ci3",
        prompt: "잘 부탁드립니다 expresses…",
        choices: ["a complaint", "goodwill and humility", "a question", "a refusal"],
        answer: 1,
        explain: "It's a warm, humble closer with no direct English translation.",
      },
    ],
  },
  {
    id: "conv-directions",
    track: "conversation",
    title: "Asking for directions",
    titleKo: "길 묻기",
    level: "Elementary",
    minutes: 9,
    summary:
      "Get unstuck anywhere in Korea with one question pattern and eight direction words.",
    blocks: [
      {
        kind: "note",
        title: "The pattern",
        body: "[Place] 어디에 있어요? — 'Where is [place]?' Add 실례하지만 ('excuse me, but…') in front to soften it with strangers.",
      },
      {
        kind: "dialogue",
        title: "On the street",
        lines: [
          { who: "나", ko: "실례하지만, 화장실 어디에 있어요?", roman: "sil-lye-ha-ji-man, hwa-jang-sil eo-di-e i-sseo-yo?", en: "Excuse me, where is the bathroom?" },
          { who: "행인", ko: "저쪽으로 가시면 오른쪽에 있어요.", roman: "jeo-jjo-geu-ro ga-si-myeon o-reun-jjo-ge i-sseo-yo.", en: "Go that way and it's on the right." },
          { who: "나", ko: "걸어서 얼마나 걸려요?", roman: "geo-reo-seo eol-ma-na geol-ryeo-yo?", en: "How long does it take on foot?" },
          { who: "행인", ko: "오 분쯤 걸려요.", roman: "o bun-jjeum geol-ryeo-yo.", en: "About five minutes." },
        ],
      },
      {
        kind: "vocab",
        title: "Direction words",
        items: [
          { ko: "똑바로", roman: "ttok-ba-ro", en: "straight" },
          { ko: "쭉", roman: "jjuk", en: "all the way" },
          { ko: "건너편", roman: "geon-neo-pyeon", en: "across the street" },
          { ko: "근처", roman: "geun-cheo", en: "nearby" },
          { ko: "모퉁이", roman: "mo-tung-i", en: "corner" },
          { ko: "걸어서", roman: "geo-reo-seo", en: "on foot" },
        ],
      },
    ],
    quiz: [
      {
        id: "cd1",
        prompt: "화장실 어디에 있어요? asks for…",
        choices: ["the station", "the bathroom", "a taxi", "the menu"],
        answer: 1,
        explain: "화장실 = bathroom / restroom.",
      },
      {
        id: "cd2",
        prompt: "똑바로 means…",
        promptKo: "똑바로",
        choices: ["turn", "straight", "nearby", "behind"],
        answer: 1,
        explain: "똑바로 가세요 = go straight.",
      },
      {
        id: "cd3",
        prompt: "'How long does it take on foot?'",
        choices: [
          "걸어서 얼마나 걸려요?",
          "얼마예요?",
          "몇 시예요?",
          "어디 가세요?",
        ],
        answer: 0,
        explain: "걸어서 = on foot, 얼마나 걸려요 = how long does it take.",
      },
    ],
  },
];

export const FLASHCARDS: Flashcard[] = [
  { id: "fc-01", deck: "Everyday", front: "안녕하세요", roman: "an-nyeong-ha-se-yo", back: "hello / good day", example: "안녕하세요, 반갑습니다.", exampleEn: "Hello, nice to meet you." },
  { id: "fc-02", deck: "Everyday", front: "감사합니다", roman: "gam-sa-ham-ni-da", back: "thank you", example: "도와주셔서 감사합니다.", exampleEn: "Thank you for helping me." },
  { id: "fc-03", deck: "Everyday", front: "죄송합니다", roman: "joe-song-ham-ni-da", back: "I'm sorry", example: "늦어서 죄송합니다.", exampleEn: "Sorry for being late." },
  { id: "fc-04", deck: "Everyday", front: "네 / 아니요", roman: "ne / a-ni-yo", back: "yes / no", example: "네, 맞아요.", exampleEn: "Yes, that's right." },
  { id: "fc-05", deck: "Everyday", front: "괜찮아요", roman: "gwaen-cha-na-yo", back: "it's okay / no thanks", example: "괜찮아요, 걱정하지 마세요.", exampleEn: "It's okay, don't worry." },
  { id: "fc-06", deck: "Café", front: "주세요", roman: "ju-se-yo", back: "please give me", example: "물 좀 주세요.", exampleEn: "Some water, please." },
  { id: "fc-07", deck: "Café", front: "얼마예요?", roman: "eol-ma-ye-yo?", back: "how much is it?", example: "이거 얼마예요?", exampleEn: "How much is this?" },
  { id: "fc-08", deck: "Café", front: "포장", roman: "po-jang", back: "takeaway", example: "포장해 주세요.", exampleEn: "To go, please." },
  { id: "fc-09", deck: "Café", front: "맛있어요", roman: "ma-si-sseo-yo", back: "it's delicious", example: "정말 맛있어요!", exampleEn: "It's really delicious!" },
  { id: "fc-10", deck: "Travel", front: "어디", roman: "eo-di", back: "where", example: "화장실이 어디예요?", exampleEn: "Where is the bathroom?" },
  { id: "fc-11", deck: "Travel", front: "지하철", roman: "ji-ha-cheol", back: "subway", example: "지하철로 갈게요.", exampleEn: "I'll go by subway." },
  { id: "fc-12", deck: "Travel", front: "환승", roman: "hwan-seung", back: "transfer", example: "여기서 환승하세요.", exampleEn: "Transfer here." },
  { id: "fc-13", deck: "Travel", front: "출구", roman: "chul-gu", back: "exit", example: "3번 출구로 나오세요.", exampleEn: "Come out of exit 3." },
  { id: "fc-14", deck: "People", front: "친구", roman: "chin-gu", back: "friend", example: "친구를 만나요.", exampleEn: "I'm meeting a friend." },
  { id: "fc-15", deck: "People", front: "가족", roman: "ga-jok", back: "family", example: "가족이 네 명이에요.", exampleEn: "There are four in my family." },
  { id: "fc-16", deck: "People", front: "이름", roman: "i-reum", back: "name", example: "이름이 뭐예요?", exampleEn: "What's your name?" },
  { id: "fc-17", deck: "Verbs", front: "가다", roman: "ga-da", back: "to go", example: "학교에 가요.", exampleEn: "I go to school." },
  { id: "fc-18", deck: "Verbs", front: "먹다", roman: "meok-da", back: "to eat", example: "밥을 먹어요.", exampleEn: "I eat rice." },
  { id: "fc-19", deck: "Verbs", front: "보다", roman: "bo-da", back: "to see / watch", example: "영화를 봐요.", exampleEn: "I watch a movie." },
  { id: "fc-20", deck: "Verbs", front: "공부하다", roman: "gong-bu-ha-da", back: "to study", example: "한국어를 공부해요.", exampleEn: "I study Korean." },
  { id: "fc-21", deck: "Verbs", front: "마시다", roman: "ma-si-da", back: "to drink", example: "커피를 마셔요.", exampleEn: "I drink coffee." },
  { id: "fc-22", deck: "Time", front: "오늘", roman: "o-neul", back: "today", example: "오늘 날씨가 좋아요.", exampleEn: "The weather is nice today." },
  { id: "fc-23", deck: "Time", front: "내일", roman: "nae-il", back: "tomorrow", example: "내일 봐요!", exampleEn: "See you tomorrow!" },
  { id: "fc-24", deck: "Time", front: "지금", roman: "ji-geum", back: "now", example: "지금 뭐 해요?", exampleEn: "What are you doing now?" },
];

export const BADGES: Badge[] = [
  { id: "first-step", name: "First Step", nameKo: "첫걸음", desc: "Complete your very first lesson.", glyph: "🌱", hue: "#3ED6B0" },
  { id: "hangul-reader", name: "Hangul Reader", nameKo: "한글 읽기", desc: "Finish all three Hangul lessons.", glyph: "ㅎ", hue: "#4C9BFF" },
  { id: "sharp-ear", name: "Sharp Ear", nameKo: "듣기 왕", desc: "Score 100% on a listening quiz.", glyph: "👂", hue: "#C77DFF" },
  { id: "perfect-score", name: "Perfect Score", nameKo: "만점", desc: "Answer every question in a quiz correctly.", glyph: "💯", hue: "#F5B841" },
  { id: "reviewer", name: "Card Shark", nameKo: "복습왕", desc: "Review 20 flashcards.", glyph: "🃏", hue: "#FF3D9A" },
  { id: "talker", name: "Conversation Starter", nameKo: "회화 입문", desc: "Complete both conversation lessons.", glyph: "💬", hue: "#FF4D5E" },
  { id: "class-goer", name: "In the Room", nameKo: "수업 참여", desc: "Join a live classroom session.", glyph: "🎥", hue: "#4C9BFF" },
  { id: "trailblazer", name: "Trailblazer", nameKo: "성실함", desc: "Complete six lessons in total.", glyph: "🏔️", hue: "#3ED6B0" },
];

export const LESSON_ORDER = LESSONS.map((l) => l.id);

export function getLesson(id: string) {
  return LESSONS.find((l) => l.id === id);
}

export function lessonsByTrack(track: TrackId) {
  return LESSONS.filter((l) => l.track === track);
}

export function nextLessonAfter(id: string) {
  const i = LESSON_ORDER.indexOf(id);
  if (i < 0 || i >= LESSON_ORDER.length - 1) return null;
  return getLesson(LESSON_ORDER[i + 1]) ?? null;
}

export const TOTAL_QUIZ_QUESTIONS = LESSONS.reduce((n, l) => n + l.quiz.length, 0);