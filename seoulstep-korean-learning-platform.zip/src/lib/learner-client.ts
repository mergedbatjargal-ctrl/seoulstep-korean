"use client";

import { useCallback, useEffect, useState } from "react";

export type Learner = { id: string; displayName: string };

export type LessonProgress = {
  lessonId: string;
  status: string;
  step: number;
  score: number;
  bestScore: number;
  secondsSpent: number;
  completedAt: string | null;
  updatedAt: string;
};

export type ProgressPayload = {
  learner: Learner;
  progress: LessonProgress[];
  badges: { badgeId: string; earnedAt: string }[];
  stats: {
    totalLessons: number;
    completed: number;
    minutes: number;
    cardsSeen: number;
    cardsDue: number;
    averageScore: number;
  };
  resume: { lessonId: string; step: number; title: string; updatedAt: string } | null;
};

let inflight: Promise<Learner | null> | null = null;

export async function ensureLearner(): Promise<Learner | null> {
  if (inflight) return inflight;
  inflight = (async () => {
    try {
      const probe = await fetch("/api/auth/learner", { cache: "no-store" });
      if (probe.ok) {
        const data = await probe.json();
        if (data?.learner) return data.learner as Learner;
      }
      const created = await fetch("/api/auth/learner", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = await created.json();
      return data?.learner ?? null;
    } catch {
      return null;
    } finally {
      inflight = null;
    }
  })();
  return inflight;
}

export function useLearner() {
  const [learner, setLearner] = useState<Learner | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const l = await ensureLearner();
    if (!l) setError("We couldn't reach the server. Check your connection and refresh.");
    setLearner(l);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return { learner, setLearner, loading, error, reload: load };
}

export function useProgress() {
  const [data, setData] = useState<ProgressPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      await ensureLearner();
      const res = await fetch("/api/progress", { cache: "no-store" });
      if (!res.ok) throw new Error("bad status");
      const json = (await res.json()) as ProgressPayload;
      setData(json);
      setError(null);
    } catch {
      setError("Progress couldn't be loaded. Refresh to try again.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  return { data, loading, error, refresh };
}