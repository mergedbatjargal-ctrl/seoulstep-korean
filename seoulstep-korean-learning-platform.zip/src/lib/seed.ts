import { db } from "@/db";
import { attendance, auditLog, classes, invitations, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "@/lib/auth";
import { generateTotpSecret } from "@/lib/totp";

export type DemoCredentials = {
  email: string;
  password: string;
  totpSecret: string;
  isDemo: boolean;
};

let cached: { at: number; value: DemoCredentials } | null = null;
let seedPromise: Promise<DemoCredentials> | null = null;

/**
 * Ensures an instructor account and a live class exist.
 * Credentials come from the environment; the fallbacks below exist only so the
 * sandbox preview is reviewable and are clearly surfaced as demo credentials.
 * Nothing here is ever shipped to the browser bundle.
 */
async function runSeed(): Promise<DemoCredentials> {
  const email = (process.env.ADMIN_EMAIL || "instructor@seoulstep.study").toLowerCase();
  const usingDemoPassword = !process.env.ADMIN_PASSWORD;
  const password = process.env.ADMIN_PASSWORD || "Seoul-Step-2026!";
  const totpSecret = process.env.ADMIN_TOTP_SECRET || generateTotpSecret();

  const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
  let instructorId: string;
  let effectiveSecret = totpSecret;

  if (existing[0]) {
    instructorId = existing[0].id;
    effectiveSecret = existing[0].totpSecret || totpSecret;
    if (!existing[0].passwordHash || !existing[0].totpSecret) {
      await db
        .update(users)
        .set({
          passwordHash: existing[0].passwordHash ?? hashPassword(password),
          totpSecret: effectiveSecret,
          role: "instructor",
        })
        .where(eq(users.id, instructorId));
    }
  } else {
    const inserted = await db
      .insert(users)
      .values({
        email,
        displayName: "Han Ji-woo",
        role: "instructor",
        passwordHash: hashPassword(password),
        totpSecret,
      })
      .returning({ id: users.id });
    instructorId = inserted[0].id;
    await db.insert(auditLog).values({
      actorId: instructorId,
      actorLabel: email,
      action: "admin.account.provisioned",
      target: "instructor",
      severity: "notice",
      meta: { mfa: "totp-enrolled" },
    });
  }

  const existingClasses = await db.select().from(classes).limit(1);
  if (existingClasses.length === 0) {
    const now = Date.now();
    const insertedClasses = await db
      .insert(classes)
      .values([
        {
          code: "SEOUL-A1",
          title: "Hangul Foundations · Live Drill",
          titleKo: "한글 기초 라이브",
          instructorId,
          lessonId: "hangul-vowels",
          startsAt: new Date(now - 1000 * 60 * 5),
          status: "live",
        },
        {
          code: "SEOUL-B2",
          title: "Café Korean · Conversation Lab",
          titleKo: "카페 한국어 회화",
          instructorId,
          lessonId: "vocab-cafe",
          startsAt: new Date(now + 1000 * 60 * 90),
          status: "scheduled",
        },
        {
          code: "SEOUL-C3",
          title: "Pronunciation Clinic",
          titleKo: "발음 클리닉",
          instructorId,
          lessonId: "pron-triad",
          startsAt: new Date(now + 1000 * 60 * 60 * 26),
          status: "scheduled",
        },
      ])
      .returning({ id: classes.id, code: classes.code });

    const liveClass = insertedClasses.find((c) => c.code === "SEOUL-A1");
    const labClass = insertedClasses.find((c) => c.code === "SEOUL-B2");
    if (liveClass) {
      const existingInvites = await db.select().from(invitations).limit(1);
      if (existingInvites.length === 0) {
        await db.insert(invitations).values([
          {
            token: "welcome-hangul-2026",
            scope: "learner",
            label: "Public welcome link · Hangul Foundations",
            lessonId: "hangul-vowels",
            classId: liveClass.id,
            createdBy: instructorId,
            maxUses: 200,
            expiresAt: new Date(now + 1000 * 60 * 60 * 24 * 30),
          },
          {
            token: "cafe-lab-week3",
            scope: "learner",
            label: "Conversation Lab · week 3 cohort",
            lessonId: "vocab-cafe",
            classId: labClass?.id ?? null,
            createdBy: instructorId,
            maxUses: 12,
            expiresAt: new Date(now + 1000 * 60 * 60 * 24 * 5),
          },
        ]);
      }

      // Believable roster for the live session. Cameras are OFF — a learner can only
      // ever change that themselves, from their own device.
      const existingAttendance = await db.select().from(attendance).limit(1);
      if (existingAttendance.length === 0) {
        const learners = await db
          .insert(users)
          .values([
            { displayName: "Priya N.", role: "learner" },
            { displayName: "Tomás R.", role: "learner" },
            { displayName: "Amara O.", role: "learner" },
            { displayName: "Kenji S.", role: "learner" },
          ])
          .returning({ id: users.id, displayName: users.displayName });

        await db.insert(attendance).values([
          {
            classId: liveClass.id,
            userId: learners[0].id,
            displayName: learners[0].displayName,
            joinedAt: new Date(now - 1000 * 60 * 12),
            cameraOn: false,
          },
          {
            classId: liveClass.id,
            userId: learners[1].id,
            displayName: learners[1].displayName,
            joinedAt: new Date(now - 1000 * 60 * 9),
            cameraOn: false,
            handRaised: true,
          },
          {
            classId: liveClass.id,
            userId: learners[2].id,
            displayName: learners[2].displayName,
            joinedAt: new Date(now - 1000 * 60 * 7),
            // Consented earlier in the class, then switched off again.
            cameraConsentAt: new Date(now - 1000 * 60 * 6),
            cameraOn: false,
          },
          {
            classId: liveClass.id,
            userId: learners[3].id,
            displayName: learners[3].displayName,
            joinedAt: new Date(now - 1000 * 60 * 20),
            leftAt: new Date(now - 1000 * 60 * 4),
            cameraOn: false,
          },
        ]);
      }
    }
  }

  return { email, password, totpSecret: effectiveSecret, isDemo: usingDemoPassword };
}

export async function ensureSeed(): Promise<DemoCredentials> {
  if (cached && Date.now() - cached.at < 60_000) return cached.value;
  if (!seedPromise) {
    seedPromise = runSeed()
      .then((value) => {
        cached = { at: Date.now(), value };
        return value;
      })
      .catch((err) => {
        seedPromise = null;
        throw err;
      });
  }
  return seedPromise;
}