"use client";

/** Browser text-to-speech for Korean, with graceful degradation. */
let cachedVoice: SpeechSynthesisVoice | null | undefined;

export function speechSupported() {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

function pickKoreanVoice(): SpeechSynthesisVoice | null {
  if (cachedVoice !== undefined) return cachedVoice ?? null;
  const voices = window.speechSynthesis.getVoices();
  if (!voices.length) return null;
  cachedVoice =
    voices.find((v) => v.lang?.toLowerCase().startsWith("ko")) ??
    voices.find((v) => /korean|한국/i.test(v.name)) ??
    null;
  return cachedVoice ?? null;
}

export function speakKorean(text: string, rate = 0.85): boolean {
  if (!speechSupported()) return false;
  try {
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = "ko-KR";
    utter.rate = rate;
    utter.pitch = 1;
    const voice = pickKoreanVoice();
    if (voice) utter.voice = voice;
    window.speechSynthesis.speak(utter);
    return true;
  } catch {
    return false;
  }
}

export function primeVoices() {
  if (!speechSupported()) return;
  window.speechSynthesis.getVoices();
  window.speechSynthesis.onvoiceschanged = () => {
    cachedVoice = undefined;
    pickKoreanVoice();
  };
}