export type Grade = "again" | "hard" | "good" | "easy";

export type SrsState = {
  ease: number;
  intervalDays: number;
  reps: number;
  lapses: number;
  dueAt: Date;
};

export const GRADE_LABELS: Record<Grade, { label: string; hint: string; tone: string }> = {
  again: { label: "Again", hint: "< 1 min", tone: "#FF4D5E" },
  hard: { label: "Hard", hint: "short interval", tone: "#F5B841" },
  good: { label: "Good", hint: "normal", tone: "#3ED6B0" },
  easy: { label: "Easy", hint: "longer", tone: "#4C9BFF" },
};

/** SM-2, trimmed and clamped for short study sessions. */
export function schedule(state: SrsState | null, grade: Grade): SrsState {
  const base: SrsState = state ?? {
    ease: 2.5,
    intervalDays: 0,
    reps: 0,
    lapses: 0,
    dueAt: new Date(),
  };
  let { ease, intervalDays, reps, lapses } = base;

  if (grade === "again") {
    lapses += 1;
    reps = 0;
    ease = Math.max(1.3, ease - 0.2);
    intervalDays = 1 / 144; // ~10 minutes
  } else {
    if (grade === "hard") {
      ease = Math.max(1.3, ease - 0.15);
      intervalDays = reps === 0 ? 0.4 : Math.max(0.4, intervalDays * 1.2);
    } else if (grade === "good") {
      intervalDays = reps === 0 ? 1 : reps === 1 ? 3 : intervalDays * ease;
    } else {
      ease = Math.min(3.2, ease + 0.15);
      intervalDays = reps === 0 ? 3 : intervalDays * ease * 1.3;
    }
    reps += 1;
  }

  intervalDays = Math.min(intervalDays, 365);
  return {
    ease,
    intervalDays,
    reps,
    lapses,
    dueAt: new Date(Date.now() + intervalDays * 86_400_000),
  };
}

export function previewInterval(state: SrsState | null, grade: Grade): string {
  const next = schedule(state, grade);
  const minutes = next.intervalDays * 1440;
  if (minutes < 60) return `${Math.max(1, Math.round(minutes))}m`;
  if (minutes < 1440) return `${Math.round(minutes / 60)}h`;
  if (next.intervalDays < 30) return `${Math.round(next.intervalDays)}d`;
  return `${Math.round(next.intervalDays / 30)}mo`;
}